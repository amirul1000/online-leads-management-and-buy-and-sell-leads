<?php

namespace Workforce\VisualComposer;

use Workforce\Annotation\Action;

class ProjectVisualComposer {
	/**
	 * @Action(name="vc_before_init")
	 */
	public static function handle() {
		vc_map( [
		   'name'			=> esc_html__( 'Projects', 'workforce' ),
		   'category'		=> esc_html__( 'Workforce', 'workforce' ),
		   'description'	=> esc_html__( 'Show projects.', 'workforce' ),
		   'base'			=> 'workforce_projects',
		   'params'			=> [
				[
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Count', 'workforce' ),
					'param_name' 	=> 'count',
					'std'			=> '5'
				],	
				[
					'type' 			=> 'checkbox',
					'param_name' 	=> 'show_create_button',
					'value'			=> [ esc_html__( 'Show create button', 'workforce' )  => '1', ],
					'std'			=> ''
				],
				[
					'type' 			=> 'checkbox',
					'param_name' 	=> 'show_all_button',
					'value'			=> [ esc_html__( 'Show all button', 'workforce' )  => '1', ],
					'std'			=> ''
				],				
		   		[
		            'type' 			=> 'css_editor',
		            'heading' 		=> esc_html__( 'CSS', 'workforce' ),
		            'param_name' 	=> 'css',
		            'group' 		=> esc_html__( 'Design options', 'workforce' ),
		        ],
		    ]
		] );
	}
}