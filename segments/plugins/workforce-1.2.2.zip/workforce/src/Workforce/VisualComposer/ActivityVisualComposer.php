<?php

namespace Workforce\VisualComposer;

use Workforce\Annotation\Action;

class ActivityVisualComposer {
	/**
	 * @Action(name="vc_before_init")
	 */
	public static function handle() {
		vc_map( [
		   'name'			=> esc_html__( 'Activity', 'workforce' ),
		   'category'		=> esc_html__( 'Workforce', 'workforce' ),
		   'description'	=> esc_html__( 'Show activity.', 'workforce' ),
		   'base'			=> 'workforce_activity',
		   'params'			=> [
				[
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Count', 'workforce' ),
					'param_name' 	=> 'count',
					'std'			=> '5'
				],		   	   		     		
		   		[
		            'type' 			=> 'css_editor',
		            'heading' 		=> esc_html__( 'CSS', 'workforce' ),
		            'param_name' 	=> 'css',
		            'group' 		=> esc_html__( 'Design options', 'workforce' ),
		        ],
		    ]
		] );
	}
}