<?php

namespace Workforce\VisualComposer;

use Workforce\Annotation\Action;

class StatsMoneyVisualComposer {
	/**
	 * @Action(name="vc_before_init")
	 */
	public static function handle() {
		vc_map( [
		   'name'			=> esc_html__( 'Stats Money', 'workforce' ),
		   'category'		=> esc_html__( 'Workforce', 'workforce' ),
		   'description'	=> esc_html__( 'Show money stats.', 'workforce' ),
		   'base'			=> 'workforce_stats_money',
		   'params'			=> [		
		   		[
		            'type' 			=> 'css_editor',
		            'heading' 		=> esc_html__( 'CSS', 'workforce' ),
		            'param_name' 	=> 'css',
		            'group' 		=> esc_html__( 'Design options', 'workforce' ),
		        ],
		    ]
		] );
	}
}