<?php

namespace Workforce\VisualComposer;

use Workforce\Annotation\Action;

class CalendarVisualComposer {
	/**
	 * @Action(name="vc_before_init")
	 */
	public static function handle() {
		vc_map( [
		   'name'			=> esc_html__( 'Calendar', 'workforce' ),
		   'category'		=> esc_html__( 'Workforce', 'workforce' ),
		   'description'	=> esc_html__( 'Show calendar.', 'workforce' ),
		   'base'			=> 'workforce_calendar',
		   'params'			=> [
		   		[
		            'type' 			=> 'css_editor',
		            'heading' 		=> esc_html__( 'CSS', 'workforce' ),
		            'param_name' 	=> 'css',
		            'group' 		=> esc_html__( 'Design options', 'workforce' ),
		        ],
		    ]
		] );
	}
}