<?php

namespace Workforce;

use Symfony\Component\ClassLoader\ClassMapGenerator;

use Workforce\Annotation\Action;
use Workforce\Annotation\Handler\ActionHandler;
use Workforce\Annotation\Handler\FilterHandler;
use Workforce\Api\EventsApi;
use Workforce\Api\SelectApi;

class Bootstrap {
	public $dir;

	public function bootstrap( $dir ) {
		$this->dir = $dir;
		$this->constants();
		$this->annotations();

		load_plugin_textdomain( 'workforce', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
	}

	public function constants() {
		define( 'WORKFORCE_DIR', $this->dir );
		define( 'WORKFORCE_TEMPLATES_DIR', 'workforce' );

		define( 'WORKFORCE_COMPANY_PREFIX', 'company_' );
		define( 'WORKFORCE_CUSTOMER_PREFIX', 'customer_' );
		define( 'WORKFORCE_ESTIMATE_PREFIX', 'estimate_' );
		define( 'WORKFORCE_EXPENSE_PREFIX', 'expense_' );
		define( 'WORKFORCE_INVOICE_PREFIX', 'invoice_' );
		define( 'WORKFORCE_LEAD_PREFIX', 'lead_' );
		define( 'WORKFORCE_LEAD_FORM_PREFIX', 'lead_form_' );
		define( 'WORKFORCE_PERSON_PREFIX', 'person_' );
		define( 'WORKFORCE_PROJECT_PREFIX', 'project_' );
		define( 'WORKFORCE_TASK_PREFIX', 'task_' );
		define( 'WORKFORCE_TOUCHPOINT_PREFIX', 'touchpoint_' );
		define( 'WORKFORCE_USER_PREFIX', 'user_' );
	}

	public static function capabilities() {
		$result = [];
		$post_types = apply_filters( 'workforce_crud_post_types', [] );

		if ( ! empty( $post_types ) ) {
			foreach ( $post_types as $post_type ) {
				$post_type_obj = get_post_type_object( $post_type );
				$result[ 'workforce_' . $post_type ] = $post_type_obj->labels->name;
			}
		}

		return $result;
	}

	/**
	 * @Action(name="init")
	 */
	public static function roles() {
		add_role( 'employee', esc_html__( 'Employee', 'workforce' ), [ 'read' => true, 'level_0' => true ] );
		add_role( 'client', esc_html__( 'Client', 'workforce' ), [ 'read' => true, 'level_0' => true ] );
	}

	/**
	 * @Action(name="widgets_init")
	 */
	public static function widgets() {
		register_widget( 'Workforce\Widget\ActivityWidget' );
		register_widget( 'Workforce\Widget\CalendarWidget' );
		register_widget( 'Workforce\Widget\OverviewWidget' );
		register_widget( 'Workforce\Widget\ProjectWidget' );
		register_widget( 'Workforce\Widget\StatsMoneyWidget' );
		register_widget( 'Workforce\Widget\TaskWidget' );
		register_widget( 'Workforce\Widget\TouchpointWidget' );
	}

	/**
	 * @Action(name="wp_enqueue_scripts")
	 */
	public static function scripts() {
		wp_enqueue_script( 'chartist', plugins_url( '/workforce/assets/js/chartist.min.js' ), [] );
		wp_enqueue_script( 'prism', plugins_url( '/workforce/assets/js/prism.js' ), [] );
		wp_enqueue_script( 'moment', plugins_url( '/workforce/assets/js/moment.min.js' ), [ 'jquery' ] );		
		wp_enqueue_script( 'fullcalendar', plugins_url( '/workforce/assets/js/fullcalendar.min.js' ), [ 'jquery', 'moment' ] );

		wp_enqueue_script( 'workforce.api', plugins_url( '/workforce/assets/js/workforce.api.js' ) );
		wp_enqueue_script( 'workforce.charts', plugins_url( '/workforce/assets/js/workforce.charts.js' ), [ 'chartist' ], false, true );
		wp_enqueue_script( 'workforce', plugins_url( '/workforce/assets/js/workforce.js' ), [ 'jquery', 'jquery-ui-datepicker', 'workforce.api' ] );

		wp_localize_script( 'workforce.api', 'workforceApiSettings', [
			'root'  => esc_url_raw( rest_url() ),
			'nonce' => wp_create_nonce( 'wp_rest' ),
		] );

		wp_enqueue_style( 'prism', plugins_url( '/workforce/assets/css/prism.css' ) );
		wp_enqueue_style( 'fullcalendar', plugins_url( '/workforce/assets/css/fullcalendar.min.css' ) );
		wp_enqueue_style( 'chartist', plugins_url( '/workforce/assets/css/chartist.min.css' ) );
	}

	/**
	 * @Action(name="workforce_content_loop_before", priority=10)
	 */
	public static function show_breadcrumb() {
		echo do_shortcode( '[workforce_breadcrumb]' );
	}

	/**
	 * @Action(name="workforce_content_loop_before", priority=20)
	 */
	public static function show_messages() {
		echo do_shortcode( '[workforce_messages]' );
	}

	/**
	 * @Action(name="workforce_content_loop_before", priority=30)
	 */
	public static function show_filter() {
		echo do_shortcode( '[workforce_filter]' );
	}

	/**
	 * @Action(name="rest_api_init")
	 */
	public static function api() {
		new SelectApi();
		new EventsApi();
	}

	/**
	 * @Action(name="after_setup_theme")
	 */
	public static function admin_bar() {
		if ( current_user_can( 'employee' ) || current_user_can( 'client' ) ) {
			show_admin_bar( false );
		}
	}

	public function annotations() {
		$classes = ClassMapGenerator::createMap( WORKFORCE_DIR . '/src' );

		foreach ( $classes as $class_name => $class_file ) {
			$action_handler = new ActionHandler();
			$action_handler->handle( $class_name );

			$filter_handler = new FilterHandler();
			$filter_handler->handle( $class_name );
		}
	}
}
