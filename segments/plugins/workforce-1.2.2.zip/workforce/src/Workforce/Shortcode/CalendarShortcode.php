<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;
use Workforce\Helper\TemplateHelper;

class CalendarShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_calendar', [ 'Workforce\Shortcode\CalendarShortcode', 'execute' ] );
	}

	public static function execute() {
		if ( ! is_user_logged_in() ) {
			echo TemplateHelper::load( 'helpers/login-required' );
			return;
		}

		return TemplateHelper::load( 'shortcodes/calendar', [] );
	}
}
