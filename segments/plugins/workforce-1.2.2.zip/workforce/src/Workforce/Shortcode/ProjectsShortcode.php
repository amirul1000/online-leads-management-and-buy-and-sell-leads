<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;
use Workforce\Helper\TemplateHelper;
use WP_Query;

class ProjectsShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_projects', [ 'Workforce\Shortcode\ProjectsShortcode', 'execute' ] );
	}

	public static function execute( $atts ) {
		if ( ! is_user_logged_in() ) {
			echo TemplateHelper::load( 'helpers/login-required' );
			return;
		}

		if ( ! current_user_can( 'workforce_project' ) ) {
			echo TemplateHelper::load( 'helpers/not-allowed' );
			return;
		}

		$atts = shortcode_atts( [
			'count'                 => 5,
			'show_create_button'    => false,
			'show_all_button'       => false,
            'hide_empty'            => false,
		], $atts, 'workforce_projects' );

        $args = [
            'post_type'         => 'project',
            'post_status'       => 'publish',
            'posts_per_page'    => $atts['count'],
        ];

        if ( ! empty( $atts['hide_empty'] ) ) {
            $project_ids = [0];

            $tasks = new WP_Query( [
                'post_type'         => 'task',
                'post_status'       => 'publish',
                'posts_per_page'    => -1,
                'meta_query'        => [
                    [
                        'key'       => WORKFORCE_TASK_PREFIX . 'project_id',
                        'compare'   => 'EXISTS',
                    ],
                ]
            ] );

            foreach ( $tasks->posts as $task ) {
                $project_id = get_post_meta( $task->ID, WORKFORCE_TASK_PREFIX . 'project_id', true );

                if ( ! empty( $project_id ) ) {
                    $project_ids[] = $project_id;
                }
            }

            $args['post__in'] = array_unique( $project_ids );
        }

		query_posts( $args );
        ob_start();
		echo TemplateHelper::load( 'shortcodes/projects', $atts );
		wp_reset_query();
		$result = ob_get_contents();
		ob_end_clean();
		return $result;
	}
}
