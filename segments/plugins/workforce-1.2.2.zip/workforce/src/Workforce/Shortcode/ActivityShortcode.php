<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;
use Workforce\Helper\MessageHelper;
use Workforce\Helper\TemplateHelper;

class ActivityShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_activity', [ 'Workforce\Shortcode\ActivityShortcode', 'execute' ] );
	}

	public static function execute( $atts ) {
		if ( ! is_user_logged_in() ) {
			echo TemplateHelper::load( 'helpers/login-required' );
			return;
		}

		$atts = shortcode_atts( [
			'count'                 => 5,
			'show_create_button'    => false,
			'show_all_button'       => false,
		], $atts, 'workforce_activity' );

		ob_start();
		$post_types = [];

		foreach ( apply_filters( 'workforce_crud_post_types', [] ) as $post_type ) {
			$post_types[] = current_user_can( 'workforce_' . $post_type ) ? $post_type : '';
		}

		query_posts( [
			'post_type'         => $post_types,
			'post_status'       => 'publish',
			'posts_per_page'    => $atts['count'],
			'orderby'           => 'modified',
			'order'             => 'desc',
		] );

		echo TemplateHelper::load( 'shortcodes/activity', $atts );
		wp_reset_query();
		$result = ob_get_contents();
		ob_end_clean();
		return $result;
	}
}
