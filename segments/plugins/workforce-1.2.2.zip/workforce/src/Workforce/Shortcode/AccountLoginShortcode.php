<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;
use Workforce\Helper\TemplateHelper;

class AccountLoginShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_account_login', [ 'Workforce\Shortcode\AccountLoginShortcode', 'execute' ] );
	}

	public static function execute() {
		return TemplateHelper::load( 'accounts/login' );
	}
}
