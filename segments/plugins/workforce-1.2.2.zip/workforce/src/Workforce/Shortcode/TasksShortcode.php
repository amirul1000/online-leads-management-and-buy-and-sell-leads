<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;
use Workforce\Helper\TemplateHelper;
use Workforce\Type\TaskType;

class TasksShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_tasks', [ 'Workforce\Shortcode\TasksShortcode', 'execute' ] );
	}

	public static function execute( $atts ) {
		if ( ! is_user_logged_in() ) {
			echo TemplateHelper::load( 'helpers/login-required' );
			return;
		}

		if ( ! current_user_can( 'workforce_task' ) ) {
			echo TemplateHelper::load( 'helpers/not-allowed' );
			return;
		}

		$atts = shortcode_atts( [
			'count'                 => 5,
			'show_create_button'    => false,
			'show_all_button'       => false,
		], $atts, 'workforce_tasks' );

		query_posts( [
			'post_type'         => 'task',
			'posts_per_page'    => $atts['count'],
			'order'             => 'ASC',
			'orderby'           => 'meta_value_num',
			'meta_key'          => WORKFORCE_TASK_PREFIX . 'due',
			'meta_query'        => [
				[
					'key'       => WORKFORCE_TASK_PREFIX . 'due',
					'value'     => strtotime( 'now' ),
					'compare'   => '>=',
					'type'      => 'NUMERIC',
				],
				[
					'key'       => WORKFORCE_TASK_PREFIX . 'status',
					'value'     => TaskType::TASK_STATUS_OPEN,
					'compare'   => '=',
				],
			],
		] );

		ob_start();
		echo TemplateHelper::load( 'shortcodes/tasks', $atts );
		wp_reset_query();
		$result = ob_get_contents();
		ob_end_clean();
		return $result;
	}
}
