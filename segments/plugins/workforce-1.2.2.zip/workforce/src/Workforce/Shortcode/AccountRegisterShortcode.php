<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;
use Workforce\Helper\TemplateHelper;

class AccountRegisterShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_account_register', [ 'Workforce\Shortcode\AccountRegisterShortcode', 'execute' ] );
	}

	public static function execute() {
		return TemplateHelper::load( 'accounts/register' );
	}
}
