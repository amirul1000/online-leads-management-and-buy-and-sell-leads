<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;
use Workforce\Helper\MessageHelper;
use Workforce\Helper\TemplateHelper;

class FilterShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_filter', [ 'Workforce\Shortcode\FilterShortcode', 'execute' ] );
	}

	public static function execute( $atts ) {
		global $wp_query;

		if ( ! is_archive() || ! empty( get_query_var( 'workforce-action' ) ) ) {
			return;
		}

		if ( empty( $atts['post_type'] ) ) {
			if ( empty( $wp_query->query['post_type'] ) ) {
				return;
			}

			$atts['post_type'] = $wp_query->query['post_type'];
		}

		$filters = apply_filters( 'workforce_filters', [] );

		if ( ! empty( $filters[ $atts['post_type'] ] ) ) {
			return TemplateHelper::load( 'shortcodes/filter', [
				'filters' => $filters,
			] );
		}
	}
}
