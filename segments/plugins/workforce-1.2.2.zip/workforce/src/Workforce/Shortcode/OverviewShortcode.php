<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;
use Workforce\Helper\MessageHelper;
use Workforce\Helper\TemplateHelper;

class OverviewShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_overview', [ 'Workforce\Shortcode\OverviewShortcode', 'execute' ] );
	}

	public static function execute( $atts ) {
		if ( ! is_user_logged_in() ) {
			echo TemplateHelper::load( 'helpers/login-required' );
			return;
		}

		return TemplateHelper::load( 'shortcodes/overview', $atts );		
	}
}
