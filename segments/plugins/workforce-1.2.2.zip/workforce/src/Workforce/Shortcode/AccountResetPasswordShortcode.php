<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;
use Workforce\Helper\TemplateHelper;

class AccountResetPasswordShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_account_reset_password', [ 'Workforce\Shortcode\AccountResetPasswordShortcode', 'execute' ] );
	}

	public static function execute() {
		return TemplateHelper::load( 'accounts/reset-password' );
	}
}
