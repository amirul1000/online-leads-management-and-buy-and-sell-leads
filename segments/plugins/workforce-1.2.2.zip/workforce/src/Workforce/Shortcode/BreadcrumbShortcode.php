<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;
use Workforce\Helper\TemplateHelper;

class BreadcrumbShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_breadcrumb', [ 'Workforce\Shortcode\BreadcrumbShortcode', 'execute' ] );
	}

	public static function execute() {
		return TemplateHelper::load( 'shortcodes/breadcrumb' );
	}
}
