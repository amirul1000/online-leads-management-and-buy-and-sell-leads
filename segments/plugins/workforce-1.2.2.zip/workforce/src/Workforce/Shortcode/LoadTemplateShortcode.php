<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;

class LoadTemplateShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_load_template', [ 'Workforce\Shortcode\LoadTemplateShortcode', 'execute' ] );
	}

	public static function execute( $atts = [] ) {
		if ( ! empty( $atts['path'] ) ) {
			ob_start();
			get_template_part( $atts['path'] );
			return ob_get_clean();
		}
	}
}
