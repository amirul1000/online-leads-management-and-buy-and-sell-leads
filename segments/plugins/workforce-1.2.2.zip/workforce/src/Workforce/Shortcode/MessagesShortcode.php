<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;
use Workforce\Helper\MessageHelper;
use Workforce\Helper\TemplateHelper;

class MessagesShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_messages', [ 'Workforce\Shortcode\MessagesShortcode', 'execute' ] );
	}

	public static function execute() {
		return TemplateHelper::load( 'shortcodes/messages', [
			'messages' => MessageHelper::get(),
		] );
	}
}
