<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;

class AccountLogoutShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_account_logout', [ 'Workforce\Shortcode\AccountLogoutShortcode', 'execute' ] );
	}

	public static function execute() {}
}
