<?php

namespace Workforce\Shortcode;

use Workforce\Annotation\Action;
use Workforce\Helper\TemplateHelper;

class TouchpointsShortcode {
	/**
	 * @Action(name="init")
	 */
	public static function initialize() {
		add_shortcode( 'workforce_touchpoints', [ 'Workforce\Shortcode\TouchpointsShortcode', 'execute' ] );
	}

	public static function execute( $atts ) {
		if ( ! is_user_logged_in() ) {
			echo TemplateHelper::load( 'helpers/login-required' );
			return;
		}

		if ( ! current_user_can( 'workforce_touchpoint' ) ) {
			echo TemplateHelper::load( 'helpers/not-allowed' );
			return;
		}

		$atts = shortcode_atts( [
			'count'                 => 5,
			'show_create_button'    => false,
			'show_all_button'       => false,
		], $atts, 'workforce_touchpoints' );

		query_posts( [
			'post_type'         => 'touchpoint',
			'posts_per_page'    => $atts['count'],
			'post_status'       => 'publish',
			'order'             => 'ASC',
			'orderby'           => 'meta_value_num',
			'meta_key'          => WORKFORCE_TOUCHPOINT_PREFIX . 'date_start',
			'meta_query'        => [
				[
					'key'       => WORKFORCE_TOUCHPOINT_PREFIX . 'date_start',
					'value'     => strtotime( 'now' ),
					'compare'   => '>=',
					'type'      => 'NUMERIC',
				],
			],
		] );

		ob_start();
		echo TemplateHelper::load( 'shortcodes/touchpoints', $atts );
		wp_reset_query();
		$result = ob_get_contents();
		ob_end_clean();
		return $result;
	}
}
