<?php

namespace Workforce\Customization;

use Workforce\Annotation\Action;
use WP_Customize_Manager;

class GeneralCustomization {
	/**
	 * @Action(name="customize_register");
	 */
	public static function customizations( WP_Customize_Manager $wp_customize ) {
		$pages = [];
		$pages[] = esc_attr__( 'Not set', 'workforce' );

		foreach ( get_pages() as $page ) {
			$pages[ $page->ID ] = $page->post_title;
		}

		$wp_customize->add_section( 'workforce_general', [
			'title'     => esc_attr__( 'Workforce General', 'workforce' ),
		] );

        // Private site
        $wp_customize->add_setting( 'workforce_general_private_site', [
            'default'           => null,
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ] );

        $wp_customize->add_control( 'workforce_general_private_site', [
            'type'          => 'checkbox',
            'label'         => esc_attr__( 'Private site', 'workforce' ),
            'section'       => 'workforce_general',
            'settings'      => 'workforce_general_private_site',
        ] );

		// Login after registration
		$wp_customize->add_setting( 'workforce_general_login_after_registration', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_general_login_after_registration', [
			'type'          => 'checkbox',
			'label'         => esc_attr__( 'Automatically log user in after registration', 'workforce' ),
			'section'       => 'workforce_general',
			'settings'      => 'workforce_general_login_after_registration',
		] );
	}
}
