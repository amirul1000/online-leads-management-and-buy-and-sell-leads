<?php

namespace Workforce\Customization;

use Workforce\Annotation\Action;
use WP_Customize_Manager;

class InvoicesCustomization {
	/**
	 * @Action(name="customize_register");
	 */
	public static function customizations( WP_Customize_Manager $wp_customize ) {
		$wp_customize->add_section( 'workforce_invoices', [
			'title'     => esc_html__( 'Workforce Invoices', 'workforce' ),
		] );

		// Payment term
		$wp_customize->add_setting( 'workforce_invoices_payment_term', [
			'default'           => 15,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_invoices_payment_term', [
			'label'         => esc_html__( 'Payment term', 'workforce' ),
			'section'       => 'workforce_invoices',
			'settings'      => 'workforce_invoices_payment_term',
			'description'   => esc_html__( 'In days', 'workforce' ),
		] );

		// Tax rate
		$wp_customize->add_setting( 'workforce_invoices_tax_rate', [
			'default'           => 0,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_invoices_tax_rate', [
			'label'         => esc_html__( 'Tax rate', 'workforce' ),
			'section'       => 'workforce_invoices',
			'settings'      => 'workforce_invoices_tax_rate',
			'description'   => esc_html__( 'In %', 'workforce' ),
		] );

		// Billing name
		$wp_customize->add_setting( 'workforce_invoices_billing_name', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_invoices_billing_name', [
			'label'         => esc_html__( 'Billing name', 'workforce' ),
			'section'       => 'workforce_invoices',
			'settings'      => 'workforce_invoices_billing_name',
		] );

		// Currency code
		$wp_customize->add_setting( 'workforce_invoices_currency_code', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_invoices_currency_code', [
			'label'         => esc_html__( 'Currency code', 'workforce' ),
			'section'       => 'workforce_invoices',
			'settings'      => 'workforce_invoices_currency_code',
		] );

		// Billing registration number
		$wp_customize->add_setting( 'workforce_invoices_billing_registration_number', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_invoices_billing_registration_number', [
			'label'         => esc_html__( 'Reg. No.', 'workforce' ),
			'section'       => 'workforce_invoices',
			'settings'      => 'workforce_invoices_billing_registration_number',
		] );

		// Billing VAT number
		$wp_customize->add_setting( 'workforce_invoices_billing_vat_number', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_invoices_billing_vat_number', [
			'label'         => esc_html__( 'VAT No.', 'workforce-invoices' ),
			'section'       => 'workforce_invoices',
			'settings'      => 'workforce_invoices_billing_vat_number',
		] );

		// Billing details
		$wp_customize->add_setting( 'workforce_invoices_billing_details', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_invoices_billing_details', [
			'label'         => esc_html__( 'Billing details', 'workforce' ),
			'section'       => 'workforce_invoices',
			'settings'      => 'workforce_invoices_billing_details',
			'type'          => 'textarea',
		] );
	}
}
