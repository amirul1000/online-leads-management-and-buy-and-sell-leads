<?php

namespace Workforce\Customization;

use Workforce\Annotation\Action;
use WP_Customize_Manager;

class PagesCustomization {
	/**
	 * @Action(name="customize_register");
	 */
	public static function customizations( WP_Customize_Manager $wp_customize ) {
		$pages = [];
		$pages[] = esc_attr__( 'Not set', 'workforce' );

		foreach ( get_pages() as $page ) {
			$pages[ $page->ID ] = $page->post_title;
		}

		$wp_customize->add_section( 'workforce_pages', [
			'title'     => esc_attr__( 'Workforce Pages', 'workforce' ),
		] );

		// Dashboard
		$wp_customize->add_setting( 'workforce_pages_dashboard', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_pages_dashboard', [
			'type'      	=> 'select',
			'label'     	=> esc_attr__( 'Dashboard', 'workforce' ),
			'section'   	=> 'workforce_pages',
			'settings'  	=> 'workforce_pages_dashboard',
			'choices'   	=> $pages,
		] );

		// Profile
		$wp_customize->add_setting( 'workforce_pages_profile', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_pages_profile', [
			'type'          => 'select',
			'label'         => esc_attr__( 'Profile', 'workforce' ),
			'section'       => 'workforce_pages',
			'settings'      => 'workforce_pages_profile',
			'choices'       => $pages,
			'description'   => esc_attr__( 'Use [workforce_account_profile] shortcode in page content.', 'workforce' ),
		] );

		// Login
		$wp_customize->add_setting( 'workforce_pages_login', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_pages_login', [
			'type'      => 'select',
			'label'     => esc_attr__( 'Login', 'workforce' ),
			'section'   => 'workforce_pages',
			'settings'  => 'workforce_pages_login',
			'choices'   => $pages,
			'description' => esc_attr__( 'Use [workforce_account_login] shortcode in page content.', 'workforce' ),
		] );

		// Login after
		$wp_customize->add_setting( 'workforce_pages_login_after', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_pages_login_after', [
			'type'          => 'select',
			'label'         => esc_attr__( 'Login after', 'workforce' ),
			'section'       => 'workforce_pages',
			'settings'      => 'workforce_pages_login_after',
			'choices'       => $pages,
			'description'   => esc_attr__( 'Page displayed after user login.', 'workforce' ),
		] );

		// Register
		$wp_customize->add_setting( 'workforce_pages_register', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_pages_register', [
			'type'      => 'select',
			'label'     => esc_attr__( 'Register', 'workforce' ),
			'section'   => 'workforce_pages',
			'settings'  => 'workforce_pages_register',
			'choices'   => $pages,
			'description' => esc_attr__( 'Use [workforce_account_register] shortcode in page content.', 'workforce' ),
		] );

		// Register after
		$wp_customize->add_setting( 'workforce_pages_register_after', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_pages_register_after', [
			'type'          => 'select',
			'label'         => esc_attr__( 'Register after', 'workforce' ),
			'section'       => 'workforce_pages',
			'settings'      => 'workforce_pages_register_after',
			'choices'       => $pages,
			'description'   => esc_attr__( 'Page displayed after user register.', 'workforce' ),
		] );

		// Logout
		$wp_customize->add_setting( 'workforce_pages_logout', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_pages_logout', [
			'type'      	=> 'select',
			'label'     	=> esc_attr__( 'Logout', 'workforce' ),
			'section'   	=> 'workforce_pages',
			'settings'  	=> 'workforce_pages_logout',
			'choices'   	=> $pages,
			'description' 	=> esc_attr__( 'Use [workforce_account_logout] shortcode in page content.', 'workforce' ),
		] );

		// Change password
		$wp_customize->add_setting( 'workforce_pages_change_password', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_pages_change_password', [
			'type'      	=> 'select',
			'label'     	=> esc_attr__( 'Change password', 'workforce' ),
			'section'   	=> 'workforce_pages',
			'settings'  	=> 'workforce_pages_change_password',
			'choices'   	=> $pages,
			'description' 	=> esc_attr__( 'Use [workforce_account_change_password] shortcode in page content.', 'workforce' ),
		] );

		// Reset password
		$wp_customize->add_setting( 'workforce_pages_reset_password', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_pages_reset_password', [
			'type'      	=> 'select',
			'label'     	=> esc_attr__( 'Reset password', 'workforce' ),
			'section'   	=> 'workforce_pages',
			'settings'  	=> 'workforce_pages_reset_password',
			'choices'   	=> $pages,
			'description' 	=> esc_attr__( 'Use [workforce_account_reset_password] shortcode in page content.', 'workforce' ),
		] );

		// Terms and conditions
		$wp_customize->add_setting( 'workforce_pages_tos', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_pages_tos', [
			'type'      	=> 'select',
			'label'     	=> esc_attr__( 'Terms & Conditions', 'workforce' ),
			'section'   	=> 'workforce_pages',
			'settings'  	=> 'workforce_pages_tos',
			'choices'   	=> $pages,
			'description' 	=> esc_attr__( 'Page displayed when user is creating new account.', 'workforce' ),
		] );
	}
}
