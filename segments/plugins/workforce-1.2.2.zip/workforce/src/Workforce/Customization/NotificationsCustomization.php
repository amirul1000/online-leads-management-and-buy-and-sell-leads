<?php

namespace Workforce\Customization;

use Workforce\Annotation\Action;
use WP_Customize_Manager;

class NotificationsCustomization {
	/**
	 * @Action(name="customize_register");
	 */
	public static function customizations( WP_Customize_Manager $wp_customize ) {
		$wp_customize->add_section( 'workforce_notifications', [
			'title'     => esc_attr__( 'Workforce Notifications', 'workforce' ),
		] );

		// Allow
		$wp_customize->add_setting( 'workforce_notifications_allow', [
			'default'           => null,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_notifications_allow', [
			'type'          => 'checkbox',
			'label'         => esc_attr__( 'Allow notifications', 'workforce' ),
			'section'       => 'workforce_notifications',
			'settings'      => 'workforce_notifications_allow',
		] );

		$wp_customize->add_setting( 'workforce_notifications_minutes', [
			'default'           => 60,
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field',
		] );

		$wp_customize->add_control( 'workforce_notifications_minutes', [
			'label'         => esc_html__( 'Notify before', 'workforce' ),
			'section'       => 'workforce_notifications',
			'settings'      => 'workforce_notifications_minutes',
			'description'   => esc_html__( 'In minutes', 'workforce' ),
		] );
	}
}
