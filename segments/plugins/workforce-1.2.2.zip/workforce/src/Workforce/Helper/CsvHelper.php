<?php

namespace Workforce\Helper;

use Workforce\Annotation\Action;

class CsvHelper {
	/**
	 * @Action(name="pre_get_posts")
	 */
	public static function change_posts_per_page( $query ) {
		if ( $query->is_main_query() && ! is_admin() && ! empty( $_GET['export'] ) && 'csv' === $_GET['export'] ) {
			$query->set( 'posts_per_page', -1 );
		}

		return $query;
	}

	/**
	 * @Action(name="wp")
	 */
	public static function export( $query ) {
		global $wp_query;

        if ( is_admin() ) {
            return;
        }
        
		if ( ! empty( $wp_query->posts ) && ! empty( $_GET['export'] ) && 'csv' === $_GET['export'] ) {
			$filename = sprintf( '%s-%s-%s-%s.csv', date( 'Y' ), date( 'm' ), date( 'd' ), $wp_query->query['post_type'] );

			header( 'Pragma: public' );
			header( 'Expires: 0' );
			header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
			header( 'Cache-Control: private', false );

			header( 'Content-Type: application/octet-stream' );
			header( 'Content-Disposition: attachment; filename=' . $filename );
			header( 'Content-Transfer-Encoding: binary' );

			$cmb = cmb2_get_metabox( $wp_query->query['post_type'] );
			$fields = $cmb->meta_box['fields'];

			$header = '';
			$i = 0;

			foreach ( $fields as $field ) {
				$header .= $field['id'];

				if ( $i + 1 < count( $fields ) ) {
					$header .= ';';
				}

				$i++;
			}

			echo esc_html( $header ) . "\r\n";

			foreach ( $wp_query->posts as $post ) {
				$i = 0;
				$row = '';

				foreach ( $fields as $field ) {
					if ( 'group' === $field['type'] ) {
						continue;
					}

					$value = get_post_meta( $post->ID, $field['id'], true );

					if ( is_array( $value ) ) {
						$row .= implode( '::', $value );
					} else {
						$row .= $value;
					}

					if ( $i + 1 < count( $fields ) ) {
						$row .= ';';
					}

					$i++;
				}

				echo esc_html( trim( preg_replace( '/\s+/', ' ', $row ) ) ) . "\r\n";
			}

			exit();
		}
	}
}
