<?php

namespace Workforce\Helper;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;

class CrudHelper {
    const ACTION_CREATE = 'CREATE';

    const ACTION_UPDATE = 'UPDATE';

    const ACTION_DELETE = 'DELETE';

    /**
     * @Filter(name="document_title_parts")
     */
    public static function title( $page_title ) {
        $action = get_query_var( 'workforce-action' );  

        if ( ! empty( $action ) ) {
            $post_type = get_query_var( 'workforce-post-type' );
            $post_type_obj = get_post_type_object( $post_type );

            if ( self::ACTION_CREATE === $action ) {                
                $page_title[] = esc_attr__( 'Create', 'workforce' ) . ' ' . $post_type_obj->labels->singular_name;
            } elseif ( self::ACTION_UPDATE === $action ) {
                $page_title[] = esc_attr__( 'Update', 'workforce' ) . ' ' . $post_type_obj->labels->singular_name;
            }
        }

        return $page_title;
    }

    /**
     * @Action(name="init", priority=100)
     */
    public static function crud_rewrites() {
        add_rewrite_tag( '%workforce-id%', '([^/]*)' );

        foreach ( apply_filters( 'workforce_crud_post_types', [] ) as $post_type ) {
            $rewrites = self::get_post_type_rewrites( get_post_type_object( $post_type ) );

            foreach( $rewrites as $rewrite ) {
                add_rewrite_rule( $rewrite['uri'], $rewrite['replace'], 'top' );
            }
        }
    }

    /**
     * @param \WP_Post_Type $obj
     * @return array
     */
    private static function get_post_type_rewrites( $obj ) {
        $rewrites = [];

        $rewrites['update'] = [
            'uri'       => sprintf( '^%s/%s/%s/?$', $obj->rewrite['slug'], esc_attr__( 'update', 'workforce' ), '([0-9]+)' ),
            'replace'   => sprintf( 'index.php?workforce-post-type=%s&workforce-action=%s&workforce-id=$matches[1]', $obj->name, self::ACTION_UPDATE ),
        ];

        $rewrites['delete'] = [
            'uri'       => sprintf( '^%s/%s/%s/?$', $obj->rewrite['slug'], esc_attr__( 'delete', 'workforce' ), '([0-9]+)' ),
            'replace'   => sprintf( 'index.php?workforce-post-type=%s&workforce-action=%s&workforce-id=$matches[1]', $obj->name, self::ACTION_DELETE ),
        ];

        $rewrites['create'] = [
            'uri'       => sprintf( '^%s/%s/?$', $obj->rewrite['slug'], esc_attr__( 'create', 'workforce' ) ),
            'replace'   => sprintf( 'index.php?workforce-post-type=%s&workforce-action=%s', $obj->name, self::ACTION_CREATE ),
        ];

        return $rewrites;
    }

    /**
     * @param string $post_type
     * @param string $action
     * @param int $post_id
     * @return string|null
     */
    public static function get_action_uri( $post_type, $action, $post_id = 0) {        
        $obj = get_post_type_object( $post_type );

        switch ( $action ) {
            case self::ACTION_CREATE:
                return site_url() . '/' . sprintf('%s/%s/', $obj->rewrite['slug'], esc_attr__( 'create', 'workforce' ) );
            case self::ACTION_UPDATE:
                return site_url() . '/' . sprintf('%s/%s/%s/', $obj->rewrite['slug'], esc_attr__( 'update', 'workforce' ), $post_id );
            case self::ACTION_DELETE:
                return site_url() . '/' . sprintf('%s/%s/%s/', $obj->rewrite['slug'], esc_attr__( 'delete', 'workforce' ), $post_id );
        }

        return null;
    }

    /**
     * @Filter(name="query_vars")
     */
    public static function crud_params( $vars ) {
        $vars[] = 'workforce-post-type';
        $vars[] = 'workforce-action';
        return $vars;
    }

    /**
     * @Filter(name="document_title_parts")
     */
    public static function head_title( $title ) {
        if ( get_query_var( 'workforce-post-type' ) && get_query_var( 'workforce-action' ) ) {
            if ( self::ACTION_CREATE === get_query_var( 'workforce-action' ) ) {
                $post_type_obj = get_post_type_object( get_query_var( 'workforce-post-type' ) );
                $title['title'] = sprintf( esc_html__( 'Create %s', 'workforce' ), $post_type_obj->labels->singular_name );
            }
        }

        return $title;
    }

    /**
     * @Action(name="wp")
     */
    public static function delete() {
        if ( is_admin() ) {
            return;
        }
        
        if ( self::ACTION_DELETE === get_query_var( 'workforce-action') && get_query_var( 'workforce-id' ) && get_query_var( 'workforce-post-type' ) ) {
            wp_delete_post( get_query_var( 'workforce-id' ) );
            $post_type_object = get_post_type_object( get_query_var( 'workforce-post-type' ) );

            MessageHelper::add(
                sprintf(
                    esc_html__( '%s has been successfully deleted.', 'workforce' ),
                    $post_type_object->labels->singular_name
                ),
                MessageHelper::STATUS_SUCCESS
            );
            wp_redirect( get_post_type_archive_link( get_query_var( 'workforce-post-type' )) );
            exit();
        }
    }

    /**
     * @Action(name="cmb2_init", priority=9999)
     */
    public static function save_process() {
        if ( empty( $_POST['submit-cmb'] ) || empty( $_POST['post_type'] ) ) {
            return;
        }

        $post_id = $_POST['object_id'];
        $post_type = $_POST['post_type'];
        $post_types = apply_filters( 'workforce_crud_post_types', [] );

        if ( ! in_array( $post_type, $post_types ) ) {
            return;
        }

        $post_type_object = get_post_type_object( $post_type );

        // Create new post
        if ( empty( $post_id ) || 'fake-id' === $post_id ) {
            $data = [
                'post_title'    => ! empty( $values['post_title'] ) ? $values['post_title'] : '',
                'post_content'  => ! empty( $values['post_content'] ) ? $values['post_content'] : '',
                'post_author'   => get_current_user_id(),
                'post_status'   => 'publish',
                'post_type'     => $post_type,
            ];

            $post_id = wp_insert_post( $data, true );
        }

        // Save who edit the post
        update_post_meta( $post_id, '_edit_last', get_current_user_id() );

        // Save post object
        if ( ! is_wp_error( $post_id ) ) {
            // Important for saving meta fields of new post
            $_POST['object_id'] = $post_id;

            $cmb = cmb2_get_metabox( $post_type, $post_id );
            $cmb->save_fields( $post_id, $cmb->object_type(), $_POST );
            $values = $cmb->get_sanitized_values( $_POST );

            $values['object_id'] = $_POST['object_id'];
            $values = apply_filters( 'workforce_before_save', $values, $post_type );

            if ( ! empty( $values['post_title'] ) ) {
                $result = wp_update_post( [
                    'ID'            => $post_id,
                    'post_title'    => $values['post_title'],
                ], true );

                if ( is_wp_error( $result ) ) {
                    MessageHelper::add(
                        esc_html__( 'An error occurred when updating post title.', 'workforce' ),
                        MessageHelper::STATUS_DANGER
                    );
                }
            }

            if ( ! empty( $values['post_content'] ) ) {
                $result = wp_update_post( [
                    'ID'            => $post_id,
                    'post_content'  => $values['post_content'],
                ], true );

                if ( is_wp_error( $result ) ) {
                    MessageHelper::add(
                        esc_html__( 'An error occurred when updating post title.', 'workforce' ),
                        MessageHelper::STATUS_DANGER
                    );
                }
            }            
            MessageHelper::add(
                sprintf(
                    esc_html__( '%s has been successfully saved.', 'workforce' ),
                    $post_type_object->labels->singular_name
                ), MessageHelper::STATUS_SUCCESS );
        } else {
            MessageHelper::add(
                sprintf(
                    esc_html__( 'An error occurred when saving %s.', 'workforce' ),
                $post_type_object->labels->singular_name
            ), MessageHelper::STATUS_DANGER );
        }

        wp_redirect( get_post_type_archive_link( $_POST['post_type'] ) );
        exit();
    }
}