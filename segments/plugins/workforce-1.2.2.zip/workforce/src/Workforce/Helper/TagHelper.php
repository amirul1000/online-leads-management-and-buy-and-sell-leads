<?php

namespace Workforce\Helper;

class TagHelper {
	/**
	 * @param string $key
	 * @return mixed
	 */
	public static function get_color( $key ) {
		$colors = apply_filters( 'workforce_tag_colors', [] );

		if ( empty( $colors ) ) {
			return null;
		}

		$combinations = get_option( 'workforce_tag_colors', [] );

		if ( ! empty( $combinations[ $key ] ) ) {
			return $combinations[ $key ];
		}

		$color = $colors[ array_rand( $colors ) ];
		$combinations[ $key ] = $color;

		update_option( 'workforce_tag_colors', $combinations );

		return $color;
	}
}
