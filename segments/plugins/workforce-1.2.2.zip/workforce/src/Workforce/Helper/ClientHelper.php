<?php

namespace Workforce\Helper;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;

class ClientHelper {	
    /**
     * @Action(name="init", priority=110)
     */
    public static function crud_rewrites() {
        $uri = sprintf( '^%s/?$', esc_attr__( 'client-zone', 'workforce' ) );
        $replace = 'index.php?workforce-client-zone=1';
		add_rewrite_rule( $uri, $replace, 'top' );
    }

    /**
     * @Filter(name="query_vars")
     */
    public static function crud_params( $vars ) {
        $vars[] = 'workforce-client-zone';
        return $vars;
    }    

    /**
     * @Filter(name="document_title_parts")
     */
    public static function head_title( $title ) {
        if ( get_query_var( 'workforce-client-zone' ) ) {
            $post_type_obj = get_post_type_object( get_query_var( 'workforce-post-type' ) );
            $title['title'] = esc_html__( 'Client Zone', 'workforce' );
        }

        return $title;
    }    
}