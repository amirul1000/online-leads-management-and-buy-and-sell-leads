<?php

namespace Workforce\Helper;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;
use Workforce\Type\UserType;

use Exception;

class TemplateHelper {
	/**
	 * @Filter(name="template_include")
	 */
	public static function templates( $template ) {
		global $wp_query;

		$workforce_post_type = get_query_var( 'workforce-post-type' );
		$workforce_action = get_query_var( 'workforce-action' );
		$workforce_id = get_query_var( 'workforce-id' );
		$workforce_client_zone = get_query_var( 'workforce-client-zone' );		
		
		if ( ! empty( $workforce_client_zone ) ) {			
			$user = wp_get_current_user(); 

			if ( in_array( 'client', (array) $user->roles ) ) {				
				return self::locate( 'client' );
			}			
		}

		if ( ! empty( $workforce_id ) ) {
			$post = get_post( $workforce_id );

			if ( empty( $post ) ) {
				return self::locate( '404' );
			}
		}

		if ( $workforce_post_type && $workforce_action ) {
			if ( CrudHelper::ACTION_CREATE === $workforce_action ) {
				return self::locate( 'crud/create' );
			}

			if ( $workforce_id ) {
				if ( CrudHelper::ACTION_UPDATE === $workforce_action ) {
					return self::locate( 'crud/update' );
				}
			}
		}

		// Author
		if ( is_author() ) {
			return self::locate( 'author' );
		}

		// Archive
		$obj = get_queried_object();
		$post_types = apply_filters( 'workforce_crud_post_types', [] );

		if ( ! empty( $obj ) && is_post_type_archive( $obj->name )  ) {
			try {
				return self::locate( 'archive-' . $wp_query->query['post_type'] );
			} catch ( Exception $e ) {
				try {
					return self::locate( 'archive' );
				} catch ( Exception $e ) {
					return self::locate( 'index' );
				}
			}
		}

		// Single
		if ( is_singular( $post_types ) ) {
			return self::locate( 'single-' . $wp_query->query['post_type'] );
		}

		return $template;
	}

	/**
	 * Get full path to template
	 *
	 * @param string $name
	 * @param string $plugin_dir
	 * @return string
	 * @throws \Exception
	 */
	public static function locate( $name, $plugin_dir = WORKFORCE_DIR ) {
		$template = '';

		// Current theme base dir
		if ( ! empty( $name ) ) {
			$template = locate_template( "{$name}.php" );
		}

		// Child theme
		if ( ! $template && ! empty( $name ) && file_exists( get_stylesheet_directory() . '/' . WORKFORCE_TEMPLATES_DIR . "/{$name}.php" ) ) {
			$template = get_stylesheet_directory() . "/templates/{$name}.php";
		}

		// Original theme
		if ( ! $template && ! empty( $name ) && file_exists( get_template_directory() . '/' . WORKFORCE_TEMPLATES_DIR . "/{$name}.php" ) ) {
			$template = get_template_directory() . "/templates/{$name}.php";
		}

		// Current Plugin
		if ( ! $template && ! empty( $name ) && file_exists( $plugin_dir . "/templates/{$name}.php" ) ) {
			$template = $plugin_dir . "/templates/{$name}.php";
		}

		// Nothing found
		if ( empty( $template ) ) {
			throw new Exception( "Template {$name}.php in plugin dir {$plugin_dir} not found." );
		}

		return $template;
	}

	/**
	 * Load template by a name
	 *
	 * @param string $name
	 * @param array $args
	 * @param string $plugin_dir
	 * @return string
	 */
	public static function load( $name, $args_for_extract = [], $plugin_dir = WORKFORCE_DIR ) {
		if ( is_array( $args_for_extract ) && count( $args_for_extract ) > 0 ) {
			extract( $args_for_extract, EXTR_SKIP );
		}

		$path = self::locate( $name, $plugin_dir );
		ob_start();
		include $path;
		$result = ob_get_contents();
		ob_end_clean();
		return $result;
	}

	/**
	 * @param int $id
	 * @return string
	 */
	public static function get_monogram( $id, $user = false ) {
		if ( $user ) {
			$title = UserType::get_name( $id );
		} else {
			$title = get_the_title( $id );
		}

		$parts = explode( ',', $title );
		$result = '';

		foreach ( $parts as $part ) {
			$result .= substr( trim( $part ), 0, 1 );
		}

		return $result;
	}

	/**
	 * @param string $key
	 * @return mixed
	 */
	public static function get_monogram_color( $key ) {
		$combinations = get_option( 'workforce_monogram_colors', [] );

		if ( ! empty( $combinations[ $key ] ) ) {
			return $combinations[ $key ];
		}

		$colors = apply_filters( 'workforce_monogram_colors', [] );

		if ( empty( $colors ) ) {
			return null;
		}

		$color = $colors[ array_rand( $colors ) ];
		$combinations[ $key ] = $color;

		update_option( 'workforce_monogram_colors', $combinations );

		return $color;
	}

	public static function get_avatar( $id, $meta_key, $class = null, $user = false ) {
		if ( 'CURRENT' === $id ) {
			$name = get_theme_mod( 'workforce_invoices_billing_name', 'CURRENT COMPANY' );
			$monogram = substr( $name, 0, 1 );	
		} else {
			$monogram = self::get_monogram( $id, $user );
		}		

		$args = [
			'title'     => get_the_title( $id ),
			'link'      => get_permalink( $id ),
			'monogram'  => $monogram,
			'class'     => $class,
			'color'     => self::get_monogram_color( $monogram ),
			'image'     => ( 'CURRENT' !== $id ) ? get_post_meta( $id, $meta_key, true ) : '',
		];

		if ( $user ) {
			$args['title'] = UserType::get_name( $id );
			$args['image'] = get_user_meta( $id, $meta_key, true );
		}

		return TemplateHelper::load( 'helpers/avatar', $args );
	}

	/**
	 * @Action(name="workforce_page_header_after")
	 */
	public static function actions() {
		include self::locate( 'helpers/page-header-actions' );
	}

	public static function build_shortcode_atts( $instance ) {
		$result = '';

		foreach ( $instance as $key => $value ) {
			if ( is_array( $value ) ) {
				// Don't pass arrays
			} else {
				$result .= sprintf( ' %s="%s"', $key, $value );
			}
		}

		return $result;
	}
}
