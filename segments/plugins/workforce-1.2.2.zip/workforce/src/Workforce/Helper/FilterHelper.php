<?php

namespace Workforce\Helper;

use WP_Query;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;

class FilterHelper {
    /**
     * @Action(name="pre_get_posts")
     */
    public static function archive( $query ) {
        if ( $query->is_main_query() && ! is_admin() ) {
            return self::filter( $query );
        }

        return $query;
    }

    /**
     * Prepare filter query
     *
     * @param null $query
     * @param null $params
     * @return WP_Query
     */
    public static function filter( $query = null, $params = null) {
        global $wpdb;
        global $wp_query;

        if ( empty( $query) ) {
            $query = $wp_query;
        }

        if ( empty( $params ) ) {
            $params = $_GET;
        }

        if ( ! empty( $params['posts_per_page'] ) ) {
            $query->set( 'posts_per_page', $params['posts_per_page'] );
        }

        if ( ! empty( $params['sort'] ) ) {
            $query->set( 'order', $params['sort'] );
        }

        if ( ! empty( $params['order'] ) ) {
            if ( 'title' == $params['order'] ) {
                $query->set( 'orderby', $params['order'] );
            } else {
                $query->set( 'orderby', 'meta_value_num' );
                $query->set( 'meta_key', $params['order'] );
            }
        }

        $meta_query = [];
        $tax_query = [];
        $ids = '';

        $filters = apply_filters( 'workforce_filters', [] );

        if ( ! empty( $filters ) && ! empty( $params['posttype'] ) && ! empty( $filters[ $params['posttype'] ] ) ) {
            foreach( $filters[ $params['posttype'] ] as $filter ) {
                $input_name = ! empty( $filter['input_name'] ) ? $filter['input_name'] : $filter['key'];

                if ( empty( $params[ $input_name ] ) ) {
                    continue;
                }

                if ( 'keyword' === $input_name ) {
                    $ids = $wpdb->get_col(
                        $wpdb->prepare( "SELECT DISTINCT ID FROM {$wpdb->posts} WHERE post_type = '%s' AND post_status = \"publish\" AND post_content LIKE '%s' OR post_title LIKE '%s'",
                        $params['posttype'], '%' . $params[ $filter['key'] ] . '%',  '%' . $params[ $filter['key'] ] . '%' ) );
                } elseif ( 'postauthor' === $input_name ) {
                    $query->set( 'author', $params[ $input_name ] );
                } elseif ( 'taxonomy' === $input_name ) {
                    $tax_query[] = [
                        'taxonomy'  	=> $filter['taxonomy'],
                        'field'     	=> 'slug',
                        'terms'     	=> [ $params[ $filter['key'] ], ],
                    ];
                } else {
                    $args = [
                        'key'       => $filter['key'],
                        'value'     => $params[ $input_name ],
                        'compare'   => $filter['compare'],
                    ];

                    // If the string contains "_date" we can convert value to timestamp
                    if ( strpos( $input_name, '_date' ) ) {
                        $args['value'] = strtotime( $params[ $input_name ] );
                    }

                    // If custom type is defines
                    if ( ! empty( $filter['type'] ) ) {
                        $args['type'] = $filter['type'];
                    }

                    $meta_query[] = $args;
                }
            }
        }

        if ( is_array( $ids ) ) {
            if ( count( $ids ) > 0 ) {
                $query->set( 'post__in', $ids );
            } else {
                $query->set( 'post__in', [ 0 ] );
            }
        }

        $meta_query = apply_filters( 'workforce_filters_meta_query', $meta_query );

        $tax_query = apply_filters( 'workforce_filters_tax_query', $tax_query );

        $query->set( 'meta_query', $meta_query );

        $query->set( 'tax_query', $tax_query );

        return $query;
    }

    /**
     * Build URI query
     *
     * @param array $new
     * @param bool $toggle
     * @return string
     */
    public static function get_uri_arguments( $new = [], $toggle = false ) {
        $args = ! empty( $_GET ) ? $_GET : [];
        $result = [];

        // Parse arguments into array
        foreach ( $args as $key => $value ) {
            if ( ! empty( $value ) ) {
                $result[ $key ] = $value;
            }
        }

        // Check if we can toggle query
        if ( $toggle ) {
            $can_toggle = true;

            // Try to find out if it is possible to toggle
            foreach( $new as $key => $value ) {
                if ( empty( $result[ $key ] ) || $result[ $key ] != $value ) {
                    $can_toggle = false;
                    break;
                }
            }

            // Toggle query arguments
            if ( $can_toggle ) {
                foreach ( $new as $key => $value ) {
                    unset( $result[ $key ] );
                }

                return http_build_query( $result );
            }
        }

        // Join new values with already existing query
        if ( is_array( $new ) && count( $new ) > 0 ) {
            $result = array_merge( $result, $new );
        }

        return http_build_query( $result );
    }

    public static function is_active_order( $order, $active_class = 'active', $inactive_class = '' ) {
        if ( is_array( $order ) ) {
            $is_active = true;

            foreach ( $order as $key => $value ) {
                if ( empty( $_GET[ $key ] ) || $_GET[ $key ] != $value ) {
                    $is_active = false;
                    break;
                }
            }

            if ( $is_active ) {
                return $active_class;
            }

            return $inactive_class;
        }

        if ( ! empty( $_GET['order'] ) && $_GET['order'] == $order ) {
            return $active_class;
        }

        return $inactive_class;
    }
}