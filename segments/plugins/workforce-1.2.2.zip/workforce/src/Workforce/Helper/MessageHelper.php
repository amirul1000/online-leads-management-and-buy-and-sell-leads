<?php

namespace Workforce\Helper;

use Workforce\Annotation\Action;

class MessageHelper {
	const STATUS_SUCCESS = 'SUCCESS';

	const STATUS_INFO = 'INFO';

	const STATUS_WARNING = 'WARNING';

	const STATUS_DANGER = 'DANGER';

	/**
	 * @Action(name="init", priority=1)
	 */
	public static function initialize() {
		if ( ! session_id() ) {
			session_start();
		}
	}

	public static function add( $message, $status = self::STATUS_INFO ) {
		if ( empty( $_SESSION['messages'] ) ) {
			$_SESSION['messages'] = [];
		}

		$_SESSION['messages'][] = [
			'message'   => $message,
			'status'    => $status,
		];
	}

	public static function get() {
		if ( ! empty( $_SESSION['messages'] ) ) {
			$messages = $_SESSION['messages'];
			unset( $_SESSION['messages'] );
			return $messages;
		}

		return null;
	}
}
