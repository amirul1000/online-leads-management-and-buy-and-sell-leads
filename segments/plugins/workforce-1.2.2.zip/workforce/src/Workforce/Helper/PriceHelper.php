<?php 

namespace Workforce\Helper;

class PriceHelper {
	public static function format( $price, $currency_code ) {
		if ( class_exists( 'NumberFormatter' ) ) {
			$fmnt = new \NumberFormatter( get_locale(), \NumberFormatter::CURRENCY );
			return $fmnt->formatCurrency( $price, $currency_code );
		}

		return sprintf( '%s %s', $price, $currency_code );
	}
}