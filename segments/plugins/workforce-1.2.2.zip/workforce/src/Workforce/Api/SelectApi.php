<?php

namespace Workforce\Api;

use WP_REST_Response;

use Workforce\Type\PersonType;

class SelectApi {
	const PATH = 'wp/v1/workforce/select/';

	public function __construct() {
		$namespace = self::PATH;

		register_rest_route( $namespace, 'get', [
			'methods'               => 'GET',
			'callback'              => [ $this, 'get' ],
			'permission_callback'   => function() {
				return is_user_logged_in();
			},
		] );

		register_rest_route( $namespace, 'get-company', [
			'methods'   => 'GET',
			'callback'  => [ $this, 'get_company' ],
			'permission_callback'   => function() {
				return is_user_logged_in();
			},
		] );
	}

	public function get( $object ) {
		$type = ! empty( $_GET['type'] ) ? $_GET['type'] : null;
		$id = ! empty( $_GET['id'] ) ? $_GET['id'] : null;
		$class = '\WorkForce\Type\\' . $type . 'Type';

		if ( class_exists( $class ) ) {
			$obj = new $class();

			if ( method_exists( $obj, 'get_all' ) ) {
				$result = $class::get_all( $id );
				$result = array_merge( $result );
				return new WP_REST_Response( $result, 200 );
			}
		}
	}

	public function get_company( $object ) {
		$id = ! empty( $_GET['id'] ) ? $_GET['id'] : null;

		return new WP_REST_Response( [
			'name'          => get_post_meta( $id, WORKFORCE_COMPANY_PREFIX . 'billing_name', true ),
			'vat_number'    => get_post_meta( $id, WORKFORCE_COMPANY_PREFIX . 'billing_vat_number', true ),
			'registration_number'    => get_post_meta( $id, WORKFORCE_COMPANY_PREFIX . 'billing_registration_number', true ),
		], 200 );
	}
}
