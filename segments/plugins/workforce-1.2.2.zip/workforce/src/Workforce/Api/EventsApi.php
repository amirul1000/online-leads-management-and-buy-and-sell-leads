<?php

namespace Workforce\Api;

use WP_Error;
use WP_Query;
use WP_REST_Response;

use Workforce\Helper\CrudHelper;
use Workforce\Type\PersonType;

class EventsApi {
	const PATH = 'wp/v1/workforce/events/';

	public function __construct() {
		$namespace = self::PATH;

		register_rest_route( $namespace, 'get', [
			'methods'   => 'GET',
			'callback'  => [ $this, 'get' ],
			'permission_callback'   => function() {
				return is_user_logged_in();
			},
		] );
	}

	public function get( $object ) {
		$results = array_merge( self::touchpoints( $_GET['start'], $_GET['end'] ), self::tasks( $_GET['start'], $_GET['end'] ) );
		return new WP_REST_Response( $results, 200 );
	}

	public static function touchpoints( $start, $end ) {
		if ( ! current_user_can( 'workforce_touchpoint' ) ) {
			return [];
		}

		$results = [];

		$query = new WP_Query( [
			'post_type'             => 'touchpoint',
			'posts_per_page'        => -1,
			'post_status'           => 'publish',
			'meta_query'            => [
				'relation'          => 'OR',
				[
					'key'           => WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable',
					'value'         => 'on',
					'compare'       => '=',
				],
				[
					[
						'key'       => WORKFORCE_TOUCHPOINT_PREFIX . 'due',
						'value'     => strtotime( $start ),
						'compare'   => '>=',
						'type'      => 'NUMERIC',
					],
					[
						'key'       => WORKFORCE_TOUCHPOINT_PREFIX . 'due',
						'value'     => strtotime( $end ),
						'compare'   => '<=',
						'type'      => 'NUMERIC',
					],
				]
			],
		] );

		foreach ( $query->posts as $touchpoint ) {
			$date_start = get_post_meta( $touchpoint->ID, WORKFORCE_TOUCHPOINT_PREFIX . 'date_start', true );
			$repeatable = get_post_meta( $touchpoint->ID, WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable', true );

			$event = [
				'id'                => $touchpoint->ID,
				'title'             => $touchpoint->post_title,
				'url'               => CrudHelper::get_action_uri( 'touchpoint', CrudHelper::ACTION_UPDATE, $touchpoint->ID ),
				'className'         => 'touchpoint',
			];

			if ( ! empty( $repeatable ) ) {
				$event['start'] = get_post_meta( $touchpoint->ID, WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable_time', true );
				$event['dow'] = array_values( get_post_meta( $touchpoint->ID, WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable_weekdays', true ) );
				$results[] = $event;
			} elseif ( ! empty( $date_start ) ) {
				$event['start'] = date( 'c', $date_start );

				// Date end
				$date_end = get_post_meta( $touchpoint->ID, WORKFORCE_TOUCHPOINT_PREFIX . 'date_end', true );
				if ( ! empty( $date_end ) ) {
					$event['end'] = date( 'c', $date_end );
				}

				$results[] = $event;
			}
		}

		return $results;
	}

	public static function tasks( $start, $end ) {
		if ( ! current_user_can( 'workforce_task' ) ) {
			return [];
		}

		$results = [];

		$query = new WP_Query( [
			'post_type'             => 'task',
			'posts_per_page'        => -1,
			'post_status'           => 'publish',
			'meta_query'            => [
				'relation'          => 'OR',
				[
					'key'           => WORKFORCE_TASK_PREFIX . 'repeatable',
					'value'         => 'on',
					'compare'       => '=',
				],
				[
					[
						'key'       => WORKFORCE_TASK_PREFIX . 'due',
						'value'     => strtotime( $start ),
						'compare'   => '>=',
						'type'      => 'NUMERIC',
					],
					[
						'key'       => WORKFORCE_TASK_PREFIX . 'due',
						'value'     => strtotime( $end ),
						'compare'   => '<=',
						'type'      => 'NUMERIC',
					],
				]
			],
		] );

		foreach ( $query->posts as $task ) {
			$due = get_post_meta( $task->ID, WORKFORCE_TASK_PREFIX . 'due', true );
			$repeatable = get_post_meta( $task->ID, WORKFORCE_TASK_PREFIX . 'repeatable', true );

			$event = [
				'id'                => $task->ID,
				'title'             => $task->post_title,
				'url'               => CrudHelper::get_action_uri( 'task', CrudHelper::ACTION_UPDATE, $task->ID ),
				'className'         => 'task',
			];

			if ( ! empty( $repeatable ) ) {
				$event['start'] = get_post_meta( $task->ID, WORKFORCE_TASK_PREFIX . 'repeatable_time', true );
				$event['dow'] = array_values( get_post_meta( $task->ID, WORKFORCE_TASK_PREFIX . 'repeatable_weekdays', true ) );
				$results[] = $event;
			} elseif ( ! empty( $due ) ) {
				$event['start'] = date( 'c', $due );
				$results[] = $event;
			}
		}

		return $results;
	}
}
