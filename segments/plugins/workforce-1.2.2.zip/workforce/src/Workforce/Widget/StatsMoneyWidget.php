<?php

namespace Workforce\Widget;

use Workforce\Helper\TemplateHelper;
use WP_Widget;

class StatsMoneyWidget extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'stats-money',
			esc_html__( 'Workforce: Stats Money', 'workforce' ),
			[ 'description' => esc_html__( 'Display money chart.', 'workforce' ) ]
		);
	}

	/**
	 * Frontend
	 *
	 * @access public
	 * @param array $args
	 * @param array $instance
	 * @return void
	 */
	function widget( $args, $instance ) {
		if ( is_user_logged_in() ) {
			echo TemplateHelper::load( 'widgets/stats-money-front', [
				'args'      => $args,
				'instance'  => $instance,
			] );
		} else {
			echo TemplateHelper::load( 'helpers/login-required' );
		}
	}

	/**
	 * Update
	 *
	 * @access public
	 * @param array $new_instance
	 * @param array $old_instance
	 * @return array
	 */
	function update( $new_instance, $old_instance ) {
		return $new_instance;
	}

	/**
	 * Backend
	 *
	 * @access public
	 * @param array $instance
	 * @return void
	 */
	function form( $instance ) {
		echo TemplateHelper::load( 'widgets/stats-money-form', [
			'widget' 	=> $this,
			'instance' 	=> $instance,
		] );
	}
}
