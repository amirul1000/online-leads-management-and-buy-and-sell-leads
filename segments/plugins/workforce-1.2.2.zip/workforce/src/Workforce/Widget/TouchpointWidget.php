<?php

namespace Workforce\Widget;

use Workforce\Helper\TemplateHelper;
use WP_Widget;

class TouchpointWidget extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'touchpoints',
			esc_html__( 'Workforce: Touchpoints', 'workforce' ),
			[ 'description' => esc_html__( 'Display touchpoints.', 'workforce' ) ]
		);
	}

	/**
	 * Frontend
	 *
	 * @access public
	 * @param array $args
	 * @param array $instance
	 * @return void
	 */
	function widget( $args, $instance ) {
		if ( is_user_logged_in() ) {
			echo TemplateHelper::load( 'widgets/touchpoints-front', [
				'args'      => $args,
				'instance'  => $instance,
			] );
		} else {
			echo TemplateHelper::load( 'helpers/login-required' );
		}
	}

	/**
	 * Update
	 *
	 * @access public
	 * @param array $new_instance
	 * @param array $old_instance
	 * @return array
	 */
	function update( $new_instance, $old_instance ) {
		return $new_instance;
	}

	/**
	 * Backend
	 *
	 * @access public
	 * @param array $instance
	 * @return void
	 */
	function form( $instance ) {
		echo TemplateHelper::load( 'widgets/touchpoints-form', [
			'widget' 	=> $this,
			'instance' 	=> $instance,
		] );
	}
}
