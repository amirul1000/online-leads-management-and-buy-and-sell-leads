<?php

namespace Workforce\Admin\AdminBar;

use Workforce\Annotation\Action;

use WP_User_Query;

class ActionsAdminBar {
    /**
     * @Action(name="admin_bar_menu", priority=1000)
     */
    public static function add_actions() {
        global $wp_admin_bar;

        if ( ! is_super_admin() ) {
            return;
        }

        $menu_id = 'workforce';

        $wp_admin_bar->add_menu( [
            'id'        => $menu_id,
            'title'     => esc_html__( 'Workforce', 'workforce' ),
            'href'      => '' ] );

        $wp_admin_bar->add_menu( [
            'parent'    => $menu_id,
            'title'     => esc_html__( 'View Capabilities', 'workforce' ),
            'id'        => 'workforce-view-capabilities',
            'href'      => get_admin_url() . 'users.php?page=user-permissions',
        ] );

        $wp_admin_bar->add_menu( [
            'parent'    => $menu_id,
            'title'     => esc_html__( 'Reset Capabilities', 'workforce' ),
            'id'        => 'workforce-reset-capabilities',
            'href'      => '?workforce-reset-capabilities=1',
        ] );
    }

    /**
     * @Action(name="wp")
     */
    public static function reset_capabilities() {
        if ( ! is_super_admin() || empty( $_GET[ 'workforce-reset-capabilities' ] ) ) {
            return;
        }


        $user_query = new WP_User_Query( [ 'role__in' => ['employee', 'administrator', ], 'number' => -1 ] );

        if ( ! empty( $user_query->results ) ) {
            foreach ( $user_query->results as $user ) {
                if ( empty( $has_default_capabilities ) ) {
                    $caps = \Workforce\Bootstrap::capabilities();

                    foreach ( $caps as $cap_key => $cap_value ) {
                        $user->add_cap( $cap_key );
                    }
                }
            }
        }

        wp_redirect( wp_get_referer() );
        exit();
    }
}