<?php

namespace Workforce\Admin\Page;

use Workforce\Annotation\Action;

class CapabilityPage {
	/**
	 * @Action(name="admin_menu")
	 */
	public static function menu() {
		add_users_page(
		esc_html__( 'Capabilities', 'workforce' ), esc_html__( 'Capabilities', 'workforce' ), 'manage_options', 'user-permissions', [ 'Workforce\Admin\Page\CapabilityPage', 'page' ]);
	}

	/**
	 * @Action(name="admin_init")
	 */
	public static function save() {
		if ( empty( $_POST['workforce-capabilities-submit'] ) ) {
			return;
		}

		$capabilities = $_POST['workforce_capabilities'];

		if ( ! empty( $capabilities ) && is_array( $capabilities ) ) {
			foreach ( $capabilities as $user_id => $caps ) {
				$user = get_user_by( 'id', $user_id );
				foreach ( \Workforce\Bootstrap::capabilities() as $cap_key => $cap_value ) {
					$user->remove_cap( $cap_key );
				}

				foreach ( $caps as $cap_key => $cap_value ) {
					if ( ! empty( $cap_value ) ) {
						$user->add_cap( $cap_key );
					}
				}
			}
		}
	}

	public static function page() {
		echo \Workforce\Helper\TemplateHelper::load( 'admin/capabilities' );
	}
}
