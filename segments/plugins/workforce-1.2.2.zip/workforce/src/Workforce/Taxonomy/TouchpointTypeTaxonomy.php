<?php

namespace Workforce\Taxonomy;

use Workforce\Annotation\Action;

class TouchpointTypeTaxonomy {
	/**
	 * @Action(name="init")
	 */
	public static function definition() {
		$labels = [
			'name'              => esc_html__( 'Touchpoint Types', 'workforce' ),
			'singular_name'     => esc_html__( 'Touchpoint Type', 'workforce' ),
			'search_items'      => esc_html__( 'Search Touchpoint Type', 'workforce' ),
			'all_items'         => esc_html__( 'All Touchpoint Types', 'workforce' ),
			'parent_item'       => esc_html__( 'Parent Touchpoint Type', 'workforce' ),
			'parent_item_colon' => esc_html__( 'Parent Touchpoint Type:', 'workforce' ),
			'edit_item'         => esc_html__( 'Edit Touchpoint Type', 'workforce' ),
			'update_item'        => esc_html__( 'Update Touchpoint Type', 'workforce' ),
			'add_new_item'      => esc_html__( 'Add New Touchpoint Type', 'workforce' ),
			'new_item_name'     => esc_html__( 'New Touchpoint Type', 'workforce' ),
			'menu_name'         => esc_html__( 'Touchpoint Types', 'workforce' ),
			'not_found'         => esc_html__( 'No touchpoint types found.', 'workforce' ),
		];

		register_taxonomy( 'touchpoint_type', 'touchpoint', [
			'labels'            => $labels,
			'hierarchical'      => true,
			'query_var'         => true,
			'rewrite'           => [ 'slug' => esc_html__( 'touchpoint-type', 'workforce' ) ],
			'public'            => true,
			'show_ui'           => true,
		] );
	}
}
