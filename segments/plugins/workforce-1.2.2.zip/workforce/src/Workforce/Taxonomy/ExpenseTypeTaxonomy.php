<?php

namespace Workforce\Taxonomy;

use Workforce\Annotation\Action;

class ExpenseTypeTaxonomy {
	/**
	 * @Action(name="init")
	 */
	public static function definition() {
		$labels = [
			'name'              => esc_html__( 'Expense Types', 'workforce' ),
			'singular_name'     => esc_html__( 'Expense Type', 'workforce' ),
			'search_items'      => esc_html__( 'Search Expense Type', 'workforce' ),
			'all_items'         => esc_html__( 'All Expense Types', 'workforce' ),
			'parent_item'       => esc_html__( 'Parent Expense Type', 'workforce' ),
			'parent_item_colon' => esc_html__( 'Parent Expense Type:', 'workforce' ),
			'edit_item'         => esc_html__( 'Edit Expense Type', 'workforce' ),
			'update_item'       => esc_html__( 'Update Expense Type', 'workforce' ),
			'add_new_item'      => esc_html__( 'Add New Expense Type', 'workforce' ),
			'new_item_name'     => esc_html__( 'New Expense Type', 'workforce' ),
			'menu_name'         => esc_html__( 'Expense Types', 'workforce' ),
			'not_found'         => esc_html__( 'No expense types found.', 'workforce' ),
		];

		register_taxonomy( 'expense_type', 'expense', [
			'labels'            => $labels,
			'hierarchical'      => true,
			'query_var'         => true,
			'rewrite'           => [ 'slug' => esc_html__( 'expense-type', 'workforce' ) ],
			'public'            => true,
			'show_ui'           => true,
		] );
	}
}
