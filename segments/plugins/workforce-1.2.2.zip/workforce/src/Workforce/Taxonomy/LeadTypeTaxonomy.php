<?php

namespace Workforce\Taxonomy;

use Workforce\Annotation\Action;

class LeadTypeTaxonomy {
	/**
	 * @Action(name="init")
	 */
	public static function definition() {
		$labels = [
			'name'              => esc_html__( 'Lead Types', 'workforce' ),
			'singular_name'     => esc_html__( 'Lead Type', 'workforce' ),
			'search_items'      => esc_html__( 'Search Lead Type', 'workforce' ),
			'all_items'         => esc_html__( 'All Lead Types', 'workforce' ),
			'parent_item'       => esc_html__( 'Parent Lead Type', 'workforce' ),
			'parent_item_colon' => esc_html__( 'Parent Lead Type:', 'workforce' ),
			'edit_item'         => esc_html__( 'Edit Lead Type', 'workforce' ),
			'update_item'       => esc_html__( 'Update Lead Type', 'workforce' ),
			'add_new_item'      => esc_html__( 'Add New Lead Type', 'workforce' ),
			'new_item_name'     => esc_html__( 'New Lead Type', 'workforce' ),
			'menu_name'         => esc_html__( 'Lead Types', 'workforce' ),
			'not_found'         => esc_html__( 'No lead types found.', 'workforce' ),
		];

		register_taxonomy( 'lead_type', 'lead', [
			'labels'            => $labels,
			'hierarchical'      => true,
			'query_var'         => true,
			'rewrite'           => [ 'slug' => esc_html__( 'lead-type', 'workforce' ) ],
			'public'            => true,
			'show_ui'           => true,
		] );
	}
}
