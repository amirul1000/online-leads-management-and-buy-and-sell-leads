<?php

namespace Workforce\Type;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;
use Workforce\Api\SelectApi;
use WP_Query;

function tags_default( $field_args, $field ) {
	echo 'asdasd'; die;
	return [ 'coaching' ];
}

class TouchpointType {
	/**
	 * @Action(name="init")
	 */
	public static function register() {
		$labels = [
			'name'                  => esc_html__( 'Touchpoints', 'workforce' ),
			'singular_name'         => esc_html__( 'Touchpoint', 'workforce' ),
			'add_new'               => esc_html__( 'Add New Touchpoint', 'workforce' ),
			'add_new_item'          => esc_html__( 'Add New Touchpoint', 'workforce' ),
			'edit_item'             => esc_html__( 'Edit Touchpoint', 'workforce' ),
			'new_item'              => esc_html__( 'New Touchpoint', 'workforce' ),
			'all_items'             => esc_html__( 'Touchpoints', 'workforce' ),
			'view_item'             => esc_html__( 'View Touchpoint', 'workforce' ),
			'search_items'          => esc_html__( 'Search Touchpoint', 'workforce' ),
			'not_found'             => esc_html__( 'No Touchpoint found', 'workforce' ),
			'not_found_in_trash'    => esc_html__( 'No Touchpoints Found in Trash', 'workforce' ),
			'parent_item_colon'     => '',
			'menu_name'             => esc_html__( 'Touchpoints', 'workforce' ),
		];

		register_post_type( 'touchpoint', [
			'labels'              => $labels,
			'supports'            => [ 'title', 'author' ],
			'public'              => true,
			'has_archive'         => true,
			'show_ui'             => true,
			'exclude_from_search' => true,
			'rewrite'       	  => [ 'slug' => esc_attr__( 'touchpoints', 'workforce' ) ],
		] );
	}

	/**
	 * @Filter(name="workforce_crud_post_types")
	 */
	public static function enable_crud( $post_types ) {
		$post_types[] = 'touchpoint';

		return $post_types;
	}

	/**
	 * @Action(name="cmb2_init")
	 */
	public static function fields() {
		$cmb = new_cmb2_box( [
			'id'           => 'touchpoint',
			'title'        => esc_html__( 'Touchpoint', 'workforce' ),
			'object_types' => [ 'touchpoint' ],
		] );

		$cmb->add_field( [
			'id'        => 'post_type',
			'type'      => 'hidden',
			'default'   => 'touchpoint',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_TOUCHPOINT_PREFIX . 'general_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'General Information', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Name', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text',
			'id'            => 'post_title',
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Content', 'workforce' ),
			'type'                  => 'wysiwyg',
			'options'               => [
				'media_buttons'     => false,
			],
			'id'            => 'post_content',
			'attributes'    => [
				'rows'      => 5,
			],
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Assign to', 'workforce' ),
			'type'              => 'select',
			'show_option_none'  => true,
			'id'                => WORKFORCE_TOUCHPOINT_PREFIX . 'user_id',
			'options'           => UserType::get_all_formatted(),
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Company', 'workforce' ),
			'type'              => 'select',
			'show_option_none'  => true,
			'id'                => WORKFORCE_TOUCHPOINT_PREFIX . 'company_id',
			'options'           => CompanyType::get_all_formatted(),
		] );

		$cmb->add_field( [
			'name'                      => esc_html__( 'Person', 'workforce' ),
			'type'                      => 'select',
			'show_option_none'          => true,
			'id'                        => WORKFORCE_TOUCHPOINT_PREFIX . 'person_id',
			'options'                   => PersonType::get_all_formatted(),
			'attributes'                => [
				'data-workforce-ajax-url'       => home_url( '/' ) . 'wp-json/' . SelectApi::PATH . 'get/',
				'data-workforce-ajax-type'      => 'Person',
				'data-workforce-ajax-id'        => WORKFORCE_TOUCHPOINT_PREFIX . 'company_id',
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_TOUCHPOINT_PREFIX . 'general_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_TOUCHPOINT_PREFIX . 'duration_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Date Duration', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Start Date', 'workforce' ),
			'type'              => 'text_datetime_timestamp',
			'id'                => WORKFORCE_TOUCHPOINT_PREFIX . 'date_start',
			'time_format'       => 'H:i',
			'attributes'        => [
				'placeholder'   => esc_attr( 'Datetime', 'workforce' ),
			],
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'End Date', 'workforce' ),
			'type'              => 'text_datetime_timestamp',
			'id'                => WORKFORCE_TOUCHPOINT_PREFIX . 'date_end',
			'time_format'       => 'H:i',
			'attributes'        => [
				'placeholder'   => esc_attr( 'Datetime', 'workforce' ),
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_TOUCHPOINT_PREFIX . 'duration_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Repeatable Touchpoint', 'workforce' ) . ' </legend>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_TOUCHPOINT_PREFIX . 'duration_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Repeatable', 'workforce' ),
			'type'              => 'checkbox',
			'id'                => WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable',
			'description'       => esc_html__( 'By checking repeatable you can repeat tasks on weekly basis. Start and end dates above will be ignored.', 'workforce' ),
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Time', 'workforce' ),
			'type'              => 'text_time',
			'id'                => WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable_time',
			'time_format'       => 'H:i',
			'attributes'        => [
				'placeholder'   => esc_attr__( 'Select time', 'workforce' ),
			],
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Repeat weekdays', 'workforce' ),
			'type'              => 'multicheck',
			'id'                => WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable_weekdays',
			'select_all_button' => false,
			'options'           => [
				1 => esc_html__( 'Monday', 'workforce' ),
				2 => esc_html__( 'Tuesday', 'workforce' ),
				3 => esc_html__( 'Wednesday', 'workforce' ),
				4 => esc_html__( 'Thursday', 'workforce' ),
				5 => esc_html__( 'Friday', 'workforce' ),
				6 => esc_html__( 'Saturday', 'workforce' ),
				7 => esc_html__( 'Sunday', 'workforce' ),
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_TOUCHPOINT_PREFIX . 'custom_fields_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Custom Fields', 'workforce' ) . ' </legend>';
            },
        ] );

		$group = $cmb->add_field( [
			'id'            => WORKFORCE_TOUCHPOINT_PREFIX . 'custom_field',
			'type'          => 'group',
			'post_type'     => 'company',
			'repeatable'    => true,
			'options'       => [
				'group_title'   => esc_html__( 'Record', 'workforce' ),
				'add_button'    => esc_html__( 'Add Another Custom Field', 'workforce' ),
				'remove_button' => esc_html__( 'Remove Custom Field', 'workforce' ),
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_TOUCHPOINT_PREFIX . 'custom_field_key',
			'name'          => esc_html__( 'Key', 'workforce' ),
			'type'          => 'text',
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_TOUCHPOINT_PREFIX . 'custom_field_value',
			'name'          => esc_html__( 'Value', 'workforce' ),
			'type'          => 'text',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_TOUCHPOINT_PREFIX . 'custom_fields_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_TOUCHPOINT_PREFIX . 'tags_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Tags', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Touchpoint Type', 'workforce' ),
			'type'              => 'taxonomy_select',
			'id'                => WORKFORCE_TOUCHPOINT_PREFIX . 'type',
			'taxonomy'          => 'touchpoint_type',
			'select_all_button' => false,
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Tags', 'workforce' ),
			'type'              => 'taxonomy_multicheck',
			'id'                => WORKFORCE_TOUCHPOINT_PREFIX . 'tags',
			'taxonomy'          => 'post_tag',
			'select_all_button' => false,
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_TOUCHPOINT_PREFIX . 'tags_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );
	}

	/**
	 * @Filter(name="workforce_filters")
	 */
	public static function filters( $filters ) {
		$filters['touchpoint'] = [
			[
				'input_type'    => 'text',
				'value'         => ! empty( $_GET['keyword'] ) ? $_GET['keyword'] : null,
				'placeholder'   => esc_attr__( 'Search for string', 'workforce' ),
				'label'         => esc_html__( 'Keyword', 'workforce' ),
				'key'           => 'keyword',
				'compare'       => '>=',
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'options'       => CompanyType::get_all_formatted(),
				'value'         => ! empty( $_GET[ WORKFORCE_TOUCHPOINT_PREFIX . 'company_id' ] ) ? $_GET[ WORKFORCE_TOUCHPOINT_PREFIX . 'company_id' ] : null,
				'placeholder'   => esc_attr( 'Select company', 'workforce' ),
				'label'         => esc_html__( 'Company', 'workforce' ),
				'key'           => WORKFORCE_TOUCHPOINT_PREFIX . 'company_id',
				'compare'       => '=',
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'options'       => PersonType::get_all_formatted(),
				'value'         => ! empty( $_GET[ WORKFORCE_TOUCHPOINT_PREFIX . 'person_id' ] ) ? $_GET[ WORKFORCE_TOUCHPOINT_PREFIX . 'person_id' ] : null,
				'placeholder'   => esc_attr( 'Select person', 'workforce' ),
				'label'         => esc_html__( 'Person', 'workforce' ),
				'key'           => WORKFORCE_TOUCHPOINT_PREFIX . 'person_id',
				'compare'       => '=',
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'text',
				'class'         => 'has-datepicker',
				'value'         => ! empty( $_GET[ WORKFORCE_TOUCHPOINT_PREFIX . 'date_start' ] ) ? $_GET[ WORKFORCE_TOUCHPOINT_PREFIX . 'date_start' ] : null,
				'placeholder'   => esc_attr__( 'Start date', 'workforce' ),
				'label'         => esc_html__( 'Starts', 'workforce' ),
				'key'           => WORKFORCE_TOUCHPOINT_PREFIX . 'date_start',
				'compare'       => '>=',
				'type'          => 'NUMERIC',
			],
		];

		return $filters;
	}

	public static function get_date( $touchpoint_id ) {
		$repeatable = get_post_meta( $touchpoint_id, WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable' );

		if ( ! empty( $repeatable ) ) {
			$result = '';
			$weekdays = get_post_meta( $touchpoint_id, WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable_weekdays', true );
			$time = get_post_meta( $touchpoint_id, WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable_time', true );

			if ( ! empty( $weekdays ) ) {
				$i = 0;

				foreach ( $weekdays as $key => $value ) {
					$result .= date( 'l', strtotime( "Sunday + $value Days" ) );

					if ( $i + 1 < count( $weekdays ) ) {
						$result .= ', ';
					}

					$i++;
				}
			}

			if ( ! empty( $time ) ) {
				$result .= ' ' . esc_html__( 'at', 'workforce' ) . ' ' . $time;
			}

			return $result;
		}

		$start_date = get_post_meta( $touchpoint_id, WORKFORCE_TOUCHPOINT_PREFIX . 'date_start', true );

		if ( ! empty( $start_date ) ) {
			$result = '<span class="date">' . date( get_option( 'date_format' ), $start_date ) . '</span>';

			$time = date( get_option( 'time_format' ), $start_date );
			if ( '00:00' != $time ) {
				$result .= ' ' . esc_html__( 'at', 'workforce' ) . ' ' . '<span class="time">' . $time . '</span>';
			}

			return $result;
		}
	}

	public static function get_by_user( $user_id, $count = 5 ) {
		$query = new WP_Query( [
			'post_type'         => 'touchpoint',
			'posts_per_page'    => $count,
			'meta_query'        => [
				[
					'key'       => WORKFORCE_TOUCHPOINT_PREFIX . 'user_id',
					'value'     => $user_id,
					'type'      => 'NUMERIC',
				],
			],
		] );

		return $query->posts;
	}

	public static function get_by_person( $user_id, $count = 5 ) {
		$query = new WP_Query( [
			'post_type'         => 'touchpoint',
			'posts_per_page'    => $count,
			'orderby'			=> 'meta_value_num',
			'meta_key'			=> WORKFORCE_TOUCHPOINT_PREFIX . 'date_start',
			'order'				=> 'DESC',			
			'meta_query'        => [
				[
					'key'       => WORKFORCE_TOUCHPOINT_PREFIX . 'person_id',
					'value'     => $user_id,
					'type'      => 'NUMERIC',
				],
			],
		] );

		return $query->posts;
	}

	public static function get_by_company( $user_id, $count = 5 ) {
		$query = new WP_Query( [
			'post_type'         => 'touchpoint',
			'posts_per_page'    => $count,
			'meta_query'        => [
				[
					'key'       => WORKFORCE_TOUCHPOINT_PREFIX . 'company_id',
					'value'     => $user_id,
					'type'      => 'NUMERIC',
				],
			],
		] );

		return $query->posts;
	}
}
