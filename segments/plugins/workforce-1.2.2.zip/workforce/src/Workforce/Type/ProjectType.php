<?php

namespace Workforce\Type;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;
use WP_Query;

class ProjectType {
	const PROJECT_BILLING_FIXED = 'FIXED';

	const PROJECT_BILLING_HOURS = 'HOURS';

	/**
	 * @Action(name="init")
	 */
	public static function register() {
		$labels = [
			'name'                  => esc_html__( 'Projects', 'workforce' ),
			'singular_name'         => esc_html__( 'Project', 'workforce' ),
			'add_new'               => esc_html__( 'Add New Project', 'workforce' ),
			'add_new_item'          => esc_html__( 'Add New Project', 'workforce' ),
			'edit_item'             => esc_html__( 'Edit Project', 'workforce' ),
			'new_item'              => esc_html__( 'New Project', 'workforce' ),
			'all_items'             => esc_html__( 'Projects', 'workforce' ),
			'view_item'             => esc_html__( 'View Project', 'workforce' ),
			'search_items'          => esc_html__( 'Search Project', 'workforce' ),
			'not_found'             => esc_html__( 'No Project found', 'workforce' ),
			'not_found_in_trash'    => esc_html__( 'No Projects Found in Trash', 'workforce' ),
			'parent_item_colon'     => '',
			'menu_name'             => esc_html__( 'Projects', 'workforce' ),
		];

		register_post_type( 'project', [
			'labels'              => $labels,
			'supports'            => [ 'title', 'editor', 'author' ],
			'public'              => true,
			'has_archive'         => true,
			'show_ui'             => true,
			'exclude_from_search' => true,
			'rewrite'       	  => [ 'slug' => esc_attr__( 'projects', 'workforce' ) ],
		] );
	}

	/**
	 * @Filter(name="workforce_crud_post_types")
	 */
	public static function enable_crud( $post_types ) {
		$post_types[] = 'project';
		return $post_types;
	}

	/**
	 * Get display name for status
	 *
	 * @param string $status
	 * @return null|string
	 */
	public static function get_status_display_name( $status ) {
		if ( self::PROJECT_BILLING_FIXED === $status ) {
			return esc_html__( 'Fixed', 'workforce' );
		} elseif ( self::PROJECT_BILLING_HOURS === $status ) {
			return esc_html__( 'Hours', 'workforce' );
		}

		return null;
	}

	/**
	 * @Action(name="cmb2_init")
	 */
	public static function fields() {
		$cmb = new_cmb2_box( [
			'id'            => 'project',
			'title'         => esc_html__( 'Project', 'workforce' ),
			'object_types'  => [ 'project' ],
		]);

		$cmb->add_field( [
			'id'        => 'post_type',
			'type'      => 'hidden',
			'default'   => 'project',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_PROJECT_PREFIX . 'general_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'General Information', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Title', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text',
			'id'            => 'post_title',
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Files', 'workforce' ) ,
			'type' 			=> 'file_list',
			'id'            => WORKFORCE_PROJECT_PREFIX . 'files',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_PROJECT_PREFIX . 'general_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_PROJECT_PREFIX . 'billing_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Billing', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Company', 'workforce' ) . '<span class="required">*</span>',
			'type'              => 'select',
			'show_option_none'  => true,
			'id'                => WORKFORCE_PROJECT_PREFIX . 'company_id',
			'options'           => CompanyType::get_all_formatted(),
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Type', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'select',
			'id'            => WORKFORCE_PROJECT_PREFIX . 'billing_type',
			'options'       => [
				self::PROJECT_BILLING_FIXED      => esc_attr__( 'Fixed', 'workforce' ),
				self::PROJECT_BILLING_HOURS      => esc_attr__( 'Hours', 'workforce' ),
			],
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Price', 'workforce' ) . '<span class="required">*</span>',
			'type'              => 'text',
			'id'                => WORKFORCE_PROJECT_PREFIX . 'price',
			'description'       => esc_html__( 'If the project billing is fixed please write total price. Hours type requires price per hour.', 'workforce' ),
			'attributes'        => [
				'required'      => 'required',
			],
		] );

		$currency_code = get_theme_mod( 'workforce_invoices_currency_code', 'USD' );
		$cmb->add_field( [
			'name'          => esc_html__( 'Currency code', 'workforce' ) . '<span class="required">*</span>',
			'id'            => WORKFORCE_PROJECT_PREFIX . 'currency_code',
			'type'          => 'text_small',
			'default'       => $currency_code,
			'attributes'    => [
				'required'  => 'required',
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_PROJECT_PREFIX . 'billing_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_PROJECT_PREFIX . 'custom_fields_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Custom Fields', 'workforce' ) . ' </legend>';
            },
        ] );

		$group = $cmb->add_field( [
			'id'            => WORKFORCE_PROJECT_PREFIX . 'custom_field',
			'type'          => 'group',
			'post_type'     => 'company',
			'repeatable'    => true,
			'options'       => [
				'group_title'   => esc_html__( 'Record', 'workforce' ),
				'add_button'    => esc_html__( 'Add Another Custom Field', 'workforce' ),
				'remove_button' => esc_html__( 'Remove Custom Field', 'workforce' ),
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_PROJECT_PREFIX . 'custom_field_key',
			'name'          => esc_html__( 'Key', 'workforce' ),
			'type'          => 'text',
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_PROJECT_PREFIX . 'custom_field_value',
			'name'          => esc_html__( 'Value', 'workforce' ),
			'type'          => 'text',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_PROJECT_PREFIX . 'custom_fields_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_PROJECT_PREFIX . 'tags_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Tags', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Tags', 'workforce' ),
			'type'              => 'taxonomy_multicheck',
			'id'                => WORKFORCE_PROJECT_PREFIX . 'tags',
			'taxonomy'          => 'post_tag',
			'select_all_button' => false,
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_PROJECT_PREFIX . 'tags_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );
	}

	/**
	 * @return array
	 */
	public static function get_all() {
		$query = new WP_Query([
			'post_type'         => 'project',
			'post_status'       => 'publish',
			'posts_per_page'    => -1,
		]);

		return $query->posts;
	}

	/**
	 * @return array
	 */
	public static function get_all_formatted() {
		$results = [];
		$objects = self::get_all();

		foreach ( $objects as $object ) {
			$results[ $object->ID ] = $object->post_title;
		}

		return $results;
	}

	/**
	 * @Filter(name="workforce_filters")
	 */
	public static function filters( $filters ) {
		$filters['project'] = [
			[
				'input_type'    => 'text',
				'value'         => ! empty( $_GET['keyword'] ) ? $_GET['keyword'] : null,
				'placeholder'   => esc_attr__( 'Search for string', 'workforce' ),
				'label'         => esc_html__( 'Keyword', 'workforce' ),
				'key'           => 'keyword',
				'compare'       => '>=',
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET[ WORKFORCE_PROJECT_PREFIX . 'billint_type' ] ) ? $_GET[ WORKFORCE_PROJECT_PREFIX . 'billing_type' ] : null,
				'placeholder'   => esc_attr__( 'Select billing', 'workforce' ),
				'label'         => esc_html__( 'Billing', 'workforce' ),
				'key'           => WORKFORCE_PROJECT_PREFIX . 'status',
				'compare'       => '=',
				'options'       => [
					self::PROJECT_BILLING_FIXED      => esc_attr__( 'Fixed', 'workforce' ),
					self::PROJECT_BILLING_HOURS   => esc_attr__( 'Hours', 'workforce' ),
				],
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET[ WORKFORCE_PROJECT_PREFIX . 'company_id' ] ) ? $_GET[ WORKFORCE_PROJECT_PREFIX . 'company_id' ] : null,
				'placeholder'   => esc_attr__( 'Select company', 'workforce' ),
				'label'         => esc_html__( 'Company', 'workforce' ),
				'key'           => WORKFORCE_PROJECT_PREFIX . 'company_id',
				'compare'       => '=',
				'options'       => CompanyType::get_all_formatted(),
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET['postauthor'] ) ? $_GET['postauthor'] : null,
				'placeholder'   => esc_attr__( 'Select author', 'workforce' ),
				'label'         => esc_html__( 'Author', 'workforce' ),
				'key'           => 'postauthor',
				'compare'       => '=',
				'options'       => UserType::get_all_formatted(),

			],
		];

		return $filters;
	}

	public static function get_by_company( $company_id, $count = 5 ) {
		$query = new WP_Query( [
			'post_type'         => 'project',
			'posts_per_page'    => $count,
			'meta_query'        => [
				[
					'key'       => WORKFORCE_PROJECT_PREFIX . 'company_id',
					'value'     => $company_id,
					'type'      => 'NUMERIC',
				],
			],
		] );

		return $query->posts;
	}

	public static function get_ids_by_company( $company_id, $count = 5 ) {
		$ids = [];
		$projects = self::get_by_company( $company_id, $count = 5 );

		foreach( $projects as $project ) {
			$ids[] = $project->ID;
		}

		return $ids;
	}

	public static function get_progress( $project_id ) {
		$tasks_all = TaskType::get_by_project( $project_id, -1 );
		$tasks_resolved = TaskType::get_by_project( $project_id, -1, TaskType::TASK_STATUS_RESOLVED );

		if ( 0 === count( $tasks_all ) ) {
			return null;
		}

		return 100 / count( $tasks_all ) * count( $tasks_resolved );
	}

	public static function get_progress_breakdown( $project_id ) {
		$tasks_all = TaskType::get_by_project( $project_id, -1 );
		$tasks_resolved = TaskType::get_by_project( $project_id, -1, TaskType::TASK_STATUS_RESOLVED );

		return sprintf( '%s / %s', count( $tasks_resolved ), count( $tasks_all ) );
	}
}
