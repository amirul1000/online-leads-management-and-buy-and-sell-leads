<?php

namespace Workforce\Type;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;
use Workforce\Api\SelectApi;
use WP_Query;

class InvoiceType {
	const INVOICE_STATUS_DRAFT = 'DRAFT';

	const INVOICE_STATUS_SENT = 'UNPAID';

	const INVOICE_STATUS_UNPAID = 'UNPAID';

	const INVOICE_STATUS_PAID = 'PAID';

	/**
	 * @Action(name="init")
	 */
	public static function register() {
		$labels = [
			'name'                  => esc_html__( 'Invoices', 'workforce' ),
			'singular_name'         => esc_html__( 'Invoice', 'workforce' ),
			'add_new'               => esc_html__( 'Add New Invoice', 'workforce' ),
			'add_new_item'          => esc_html__( 'Add New Invoice', 'workforce' ),
			'edit_item'             => esc_html__( 'Edit Invoice', 'workforce' ),
			'new_item'              => esc_html__( 'New Invoice', 'workforce' ),
			'all_items'             => esc_html__( 'Invoices', 'workforce' ),
			'view_item'             => esc_html__( 'View Invoice', 'workforce' ),
			'search_items'          => esc_html__( 'Search Invoice', 'workforce' ),
			'not_found'             => esc_html__( 'No Invoice found', 'workforce' ),
			'not_found_in_trash'    => esc_html__( 'No Invoices Found in Trash', 'workforce' ),
			'parent_item_colon'     => '',
			'menu_name'             => esc_html__( 'Invoices', 'workforce' ),
		];

		register_post_type( 'invoice', [
			'labels'              => $labels,
			'supports'            => [ 'title', 'author' ],
			'public'              => true,
			'has_archive'         => true,
			'show_ui'             => true,
			'exclude_from_search' => true,
			'rewrite'       	  => [ 'slug' => esc_attr__( 'invoices', 'workforce' ) ],
		] );
	}

	/**
	 * @Filter(name="workforce_crud_post_types")
	 */
	public static function enable_crud( $post_types ) {
		$post_types[] = 'invoice';
		return $post_types;
	}

	/**
	 * Get display name for status
	 *
	 * @param string $status
	 * @return null|string
	 */
	public static function get_status_display_name( $status ) {
		if ( self::INVOICE_STATUS_DRAFT === $status ) {
			return esc_html__( 'Draft', 'workforce' );
		} elseif ( self::INVOICE_STATUS_SENT === $status ) {
			return esc_html__( 'Sent', 'workforce' );			
		} elseif ( self::INVOICE_STATUS_PAID === $status ) {
			return esc_html__( 'Paid', 'workforce' );
		} elseif ( self::INVOICE_STATUS_UNPAID === $status ) {
			return esc_html__( 'Unpaid', 'workforce' );
		}

		return null;
	}

	/**
	 * @Action(name="cmb2_init")
	 */
	public static function fields() {
		// Payment information
		$cmb = new_cmb2_box( [
			'id'            => 'invoice',
			'title'         => esc_html__( 'Payment information', 'workforce' ),
			'object_types'  => [ 'invoice' ],
			'context'       => 'normal',
			'priority'      => 'high',
		] );

		$cmb->add_field( [
			'id'        => 'post_type',
			'type'      => 'hidden',
			'default'   => 'invoice',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_INVOICE_PREFIX . 'general_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'General Information', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Status', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'select',
			'id'            => WORKFORCE_INVOICE_PREFIX . 'status',
			'options'       => [
				self::INVOICE_STATUS_DRAFT    	=> esc_attr__( 'Draft', 'workforce' ),
				self::INVOICE_STATUS_SENT   	=> esc_attr__( 'Sent', 'workforce' ),
				self::INVOICE_STATUS_PAID       => esc_attr__( 'Paid', 'workforce' ),
				self::INVOICE_STATUS_UNPAID     => esc_attr__( 'Unpaid', 'workforce' ),
			],
			'attributes'    => [
				'required'  => 'required',
			],
		] );
		$cmb->add_field( [
			'name'          => esc_html__( 'Issue date', 'workforce' ) . '<span class="required">*</span>',
			'id'            => WORKFORCE_INVOICE_PREFIX . 'date',
			'type'          => 'text_date_timestamp',
			'attributes'        => [
				'required'      => 'required',
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_INVOICE_PREFIX . 'general_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_INVOICE_PREFIX . 'customer_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Customer', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Company', 'workforce' ) . '<span class="required">*</span>',
			'id'                => WORKFORCE_INVOICE_PREFIX . 'company_id',
			'type'              => 'select',
			'show_option_none'  => true,
			'options'           => CompanyType::get_all_formatted(),
			'attributes'        => [
				'required'                                  => 'required',
				'data-workforce-ajax-id'                    => WORKFORCE_INVOICE_PREFIX . 'company_id',
				'data-workforce-ajax-company-url'           => home_url( '/' ) . 'wp-json/' . SelectApi::PATH . 'get-company/',
				'data-workforce-ajax-customer-name'         => WORKFORCE_INVOICE_PREFIX . 'customer_name',
				'data-workforce-ajax-customer-registration-number'   => WORKFORCE_INVOICE_PREFIX . 'customer_registration_number',
				'data-workforce-ajax-customer-vat-number'            => WORKFORCE_INVOICE_PREFIX . 'customer_vat_number',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Name', 'workforce' ) . '<span class="required">*</span>',
			'id'            => WORKFORCE_INVOICE_PREFIX . 'customer_name',
			'type'          => 'text',
			'attributes'        => [
				'required'      => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Registration No.', 'workforce' ) . '<span class="required">*</span>',
			'id'            => WORKFORCE_INVOICE_PREFIX . 'customer_registration_number',
			'type'          => 'text_medium',
			'attributes'        => [
				'required'      => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'VAT No.', 'workforce' ) . '<span class="required">*</span>',
			'id'            => WORKFORCE_INVOICE_PREFIX . 'customer_vat_number',
			'type'          => 'text_medium',
			'attributes'        => [
				'required'      => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Details', 'workforce' ),
			'description'   => esc_html__( 'Additional information displayed on the invoice about customer.', 'workforce' ),
			'id'            => WORKFORCE_INVOICE_PREFIX . 'customer_details',
			'type'          => 'textarea',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_INVOICE_PREFIX . 'customer_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_INVOICE_PREFIX . 'supplier_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Supplier', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Name', 'workforce' ) . '<span class="required">*</span>',
			'id'            => WORKFORCE_INVOICE_PREFIX . 'supplier_name',
			'type'          => 'text',
			'default'       => get_theme_mod( 'workforce_invoices_billing_name', null ),
			'attributes'        => [
				'required'      => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Registration No.', 'workforce' ) . '<span class="required">*</span>',
			'id'            => WORKFORCE_INVOICE_PREFIX . 'supplier_registration_number',
			'type'          => 'text_medium',
			'default'       => get_theme_mod( 'workforce_invoices_billing_registration_number', null ),
			'attributes'        => [
				'required'      => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'VAT No.', 'workforce' ) . '<span class="required">*</span>',
			'id'            => WORKFORCE_INVOICE_PREFIX . 'supplier_vat_number',
			'type'          => 'text_medium',
			'default'       => get_theme_mod( 'workforce_invoices_billing_vat_number', null ),
			'attributes'        => [
				'required'      => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Details', 'workforce' ),
			'description'   => esc_html__( 'Additional information displayed about supplier on invoice.', 'workforce' ),
			'id'            => WORKFORCE_INVOICE_PREFIX . 'supplier_details',
			'type'          => 'textarea',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_INVOICE_PREFIX . 'supplier_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_INVOICE_PREFIX . 'invoice_items_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Invoice Items', 'workforce' ) . ' </legend>';
            },
        ] );

		$group = $cmb->add_field( [
			'id'          	=> WORKFORCE_INVOICE_PREFIX . 'item',
			'type'        	=> 'group',
			'post_type'   	=> 'invoice',
			'repeatable'  	=> true,
			'options'     	=> [
				'group_title'   => esc_html__( 'Invoice Item', 'workforce' ),
				'add_button'    => esc_html__( 'Add Another Item', 'workforce' ),
				'remove_button' => esc_html__( 'Remove Item', 'workforce' ),
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_INVOICE_PREFIX . 'item_title',
			'name'          => esc_html__( 'Title', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text',
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_INVOICE_PREFIX . 'item_quantity',
			'name'          => esc_html__( 'Quantity', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text_small',
			'default'       => 1,
			'attributes'    => [
				'required'  => 'required',
				'pattern'   => '\\d*\\.?\\d+',
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_INVOICE_PREFIX . 'item_unit_price',
			'name'          => esc_html__( 'Unit price', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text_small',
			'attributes'    => [
				'required'  => 'required',
				'pattern'   => '\\d*\\.?\\d+',
			],
		] );

		$tax_rate = get_theme_mod( 'workforce_invoices_tax_rate', null );
		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_INVOICE_PREFIX . 'item_tax_rate',
			'name'          => esc_html__( 'Tax rate', 'workforce' ) . '<span class="required">*</span>',
			'description'   => esc_html__( 'Enter value in percents e.g. 20%', 'workforce' ),
			'type'          => 'text_small',
			'default'       => $tax_rate,
			'attributes'    => [
				'required'  => 'required',
				'pattern'   => '\\d*\\.?\\d+',
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_INVOICE_PREFIX . 'invoice_items_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_INVOICE_PREFIX . 'custom_fields_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Custom Fields', 'workforce' ) . ' </legend>';
            },
        ] );

		$group = $cmb->add_field( [
			'id'            => WORKFORCE_INVOICE_PREFIX . 'custom_field',
			'type'          => 'group',
			'post_type'     => 'company',
			'repeatable'    => true,
			'options'       => [
				'group_title'   => esc_html__( 'Custom Field', 'workforce' ),
				'add_button'    => esc_html__( 'Add Another Custom Field', 'workforce' ),
				'remove_button' => esc_html__( 'Remove Custom Field', 'workforce' ),
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_INVOICE_PREFIX . 'custom_field_key',
			'name'          => esc_html__( 'Key', 'workforce' ),
			'type'          => 'text',
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_INVOICE_PREFIX . 'custom_field_value',
			'name'          => esc_html__( 'Value', 'workforce' ),
			'type'          => 'text',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_INVOICE_PREFIX . 'custom_fields_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_INVOICE_PREFIX . 'default_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Default', 'workforce' ) . ' </legend>';
            },
        ] );

		$currency_code = get_theme_mod( 'workforce_invoices_currency_code', 'USD' );
		$cmb->add_field( [
			'name'          => esc_html__( 'Currency code', 'workforce' ) . '<span class="required">*</span>',
			'id'            => WORKFORCE_INVOICE_PREFIX . 'currency_code',
			'type'          => 'text_small',
			'default'       => $currency_code,
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$payment_term = get_theme_mod( 'workforce_invoices_payment_term', 15 );
		$cmb->add_field( [
			'name'          => esc_html__( 'Payment term', 'workforce' ) . '<span class="required">*</span>',
			'id'            => WORKFORCE_INVOICE_PREFIX . 'payment_term',
			'type'          => 'text_small',
			'description'   => esc_html__( 'Number of days for paying invoice', 'workforce' ),
			'default'       => $payment_term,
			'attributes'    => [
				'required'      => 'required',
				'type'          => 'number',
				'pattern'       => '\d*',
			],
		] );

		$billing_details = get_theme_mod( 'workforce_invoices_billing_details', null );
		$cmb->add_field( [
			'name'          => esc_html__( 'Instructions', 'workforce' ),
			'id'            => WORKFORCE_INVOICE_PREFIX . 'details',
			'type'          => 'textarea',
			'default'       => $billing_details,
			'attributes'    => [
				'rows'      => 3,
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_INVOICE_PREFIX . 'default_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );
	}

	/**
	 * @Filter(name="workforce_filters")
	 */
	public static function filters( $filters ) {
		$filters['invoice'] = [
			[
				'input_type'    => 'text',
				'value'         => ! empty( $_GET['keyword'] ) ? $_GET['keyword'] : null,
				'placeholder'   => esc_attr__( 'Search for string', 'workforce' ),
				'label'         => esc_html__( 'Keyword', 'workforce' ),
				'key'           => 'keyword',
				'compare'       => '>=',
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET[ WORKFORCE_INVOICE_PREFIX . 'status' ] ) ? $_GET[ WORKFORCE_INVOICE_PREFIX . 'status' ] : null,
				'placeholder'   => esc_attr__( 'Select status', 'workforce' ),
				'label'         => esc_html__( 'Status', 'workforce' ),
				'key'           => WORKFORCE_INVOICE_PREFIX . 'status',
				'compare'       => '=',
				'options'       => [
					self::INVOICE_STATUS_DRAFT     => esc_attr__( 'Draft', 'workforce' ),
					self::INVOICE_STATUS_SENT      => esc_attr__( 'Sent', 'workforce' ),
					self::INVOICE_STATUS_PAID      => esc_attr__( 'Paid', 'workforce' ),
					self::INVOICE_STATUS_UNPAID    => esc_attr__( 'Unpading', 'workforce' ),
				],
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'options'       => CompanyType::get_all_formatted(),
				'value'         => ! empty( $_GET[ WORKFORCE_INVOICE_PREFIX . 'company_id' ] ) ? $_GET[ WORKFORCE_INVOICE_PREFIX . 'company_id' ] : null,
				'placeholder'   => esc_attr( 'Select company', 'workforce' ),
				'label'         => esc_html__( 'Company', 'workforce' ),
				'key'           => WORKFORCE_INVOICE_PREFIX . 'company_id',
				'compare'       => '=',
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'text',
				'class'         => 'has-datepicker',
				'value'         => ! empty( $_GET[ WORKFORCE_INVOICE_PREFIX . 'date' ] ) ? $_GET[ WORKFORCE_INVOICE_PREFIX . 'date' ] : null,
				'placeholder'   => esc_attr__( 'Issued date', 'workforce' ),
				'label'         => esc_html__( 'Issued', 'workforce' ),
				'key'           => WORKFORCE_INVOICE_PREFIX . 'date',
				'compare'       => '>=',
				'type'          => 'NUMERIC',
			],
		];

		return $filters;
	}

	/**
	 * Calculates invoices item subtotal
	 *
	 * @param $item array
	 * @return float
	 */
	public static function get_invoice_item_subtotal( $item ) {
		// unit price
		$unit_price_key = WORKFORCE_INVOICE_PREFIX . 'item_unit_price';
		$unit_price = ( ! empty( $item[ $unit_price_key ] ) ) ? (float) $item[ $unit_price_key ] : 0;

		// quantity
		$quantity_key = WORKFORCE_INVOICE_PREFIX . 'item_quantity';
		$quantity = ( ! empty( $item[ $quantity_key ] ) ) ? (float) $item[ $quantity_key ] : 0;

		// tax rate
		$tax_rate_key = WORKFORCE_INVOICE_PREFIX . 'item_tax_rate';
		$tax_rate = ( ! empty( $item[ $tax_rate_key ] ) ) ? (float) $item[ $tax_rate_key ] : 0;

		// item price
		$rate = (float) ( 100 + $tax_rate ) / 100;
		$subtotal = $unit_price * $quantity * $rate;

		return round( $subtotal, 2 );
	}

	/**
	 * Calculates invoice total price
	 *
	 * @param $invoice_id int
	 * @return float
	 */
	public static function get_invoice_total( $invoice_id ) {
		$items = get_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'item', true );

		$total = 0;

		if ( ! is_array( $items ) ) {
			return $total;
		}

		foreach ( $items as $item ) {
			$item_price = self::get_invoice_item_subtotal( $item );
			$total += $item_price;
		}

		return round( $total, 2 );
	}

	/**
	 * Returns invoice item list
	 *
	 * @param $invoice_id int
	 * @return array
	 */
	public static function get_invoice_item_list( $invoice_id ) {
		$items = get_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'item', true );

		if ( ! is_array( $items ) ) {
			return [];
		}

		$result = [];

		foreach ( $items as $item ) {
			$item_title_key = WORKFORCE_INVOICE_PREFIX . 'item_title';
			$item_title = ( ! empty( $item[ $item_title_key ] ) ) ? $item[ $item_title_key ] : null;

			if ( ! empty( $item_title ) ) {
				$result[] = $item_title;
			}
		}

		return $result;
	}

	/**
	 * Checks if invoice number already exist
	 *
	 * @return bool
	 */
	public static function invoice_number_exists( $invoice_number ) {
		global $wpdb;

		$title_ids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT ID FROM {$wpdb->posts} WHERE post_status = \"publish\" AND post_title = '%s'", $invoice_number ) );
		return count( $title_ids ) > 0;
	}

	/**
	 * Returns all invoices
	 *
	 * @return array
	 */
	public static function get_all( $status = null, $count = -1 ) {
		$args = [
			'post_type'         => 'invoice',
			'posts_per_page'    => $count,
			'post_status'       => 'publish',
			'orderby'           => 'date',
			'order'             => 'DESC',
			'meta_query'		=> [],
		];

		if ( ! empty( $status ) ) {
			if ( is_array( $status ) ) {
				$args['meta_query'][] = [
					'key' 		=> WORKFORCE_INVOICE_PREFIX . 'status',
					'value'		=> $status,
					'compare' 	=> 'IN',
				];
			} else {
				$args['meta_query'][] = [
					'key' 		=> WORKFORCE_INVOICE_PREFIX . 'status',
					'value'		=> $status,
					'compare' 	=> '=',
				];
			}
		}

		$query = new WP_Query( $args );

		return $query->posts;
	}

	public static function get_all_total() {
		$invoices = self::get_all( self::INVOICE_STATUS_PAID );
		$total = [];

		foreach( $invoices as $invoice ) {
			$currency_code = get_post_meta( $invoice->ID, WORKFORCE_INVOICE_PREFIX . 'currency_code', true );
			$price = self::get_invoice_total( $invoice->ID );

			if ( ! empty( $total[ $currency_code ] ) ) {
				$total[ $currency_code ]['total'] += $price;
			} else {
				$total[ $currency_code ] = [
					'currency_code' => $currency_code,
					'total' 		=> $price,
				];
			}
		}

		return $total;
	}

	/**
	 * Returns the very next number for new invoice
	 *
	 * @return string
	 */
	public static function get_next_invoice_number() {
		$next_number = 1;

		$invoices = self::get_all();

		if ( count( $invoices ) > 0 ) {
			$last_invoice = $invoices[0];
			$last_invoice_number = get_the_title( $last_invoice );

			if ( is_numeric( $last_invoice_number ) ) {
				$next_number = (int) $last_invoice_number + 1;
			}
		}

		while ( self::invoice_number_exists( $next_number ) ) {
			$next_number += 1;
		}

		return apply_filters( 'workforce_invoices_next_invoice_number', $next_number );
	}

	public static function get_by_company( $company_id, $count = 5 ) {
		$query = new WP_Query( [
			'post_type'         => 'invoice',
			'posts_per_page'    => $count,
			'meta_query'        => [
				[
					'key'       => WORKFORCE_INVOICE_PREFIX . 'company_id',
					'value'     => $company_id,
					'type'      => 'NUMERIC',
				],
			],
		] );

		return $query->posts;
	}	
}
