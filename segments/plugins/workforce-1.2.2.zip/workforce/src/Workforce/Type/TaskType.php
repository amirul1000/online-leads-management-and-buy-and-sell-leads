<?php

namespace Workforce\Type;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;
use WP_Query;

class TaskType {
	const TASK_STATUS_OPEN = 'OPEN';

	const TASK_STATUS_RESOLVED = 'RESOLVED';

	/**
	 * @Action(name="init")
	 */
	public static function register() {
		$labels = [
			'name'                  => esc_html__( 'Tasks', 'workforce' ),
			'singular_name'         => esc_html__( 'Task', 'workforce' ),
			'add_new'               => esc_html__( 'Add New Task', 'workforce' ),
			'add_new_item'          => esc_html__( 'Add New Task', 'workforce' ),
			'edit_item'             => esc_html__( 'Edit Task', 'workforce' ),
			'new_item'              => esc_html__( 'New Task', 'workforce' ),
			'all_items'             => esc_html__( 'Tasks', 'workforce' ),
			'view_item'             => esc_html__( 'View Task', 'workforce' ),
			'search_items'          => esc_html__( 'Search Task', 'workforce' ),
			'not_found'             => esc_html__( 'No Task found', 'workforce' ),
			'not_found_in_trash'    => esc_html__( 'No Tasks Found in Trash', 'workforce' ),
			'parent_item_colon'     => '',
			'menu_name'             => esc_html__( 'Tasks', 'workforce' ),
		];

		register_post_type( 'task', [
			'labels'              => $labels,
			'supports'            => [ 'title', 'editor', 'comments', 'author' ],
			'public'              => true,
			'has_archive'         => true,
			'show_ui'             => true,
			'exclude_from_search' => true,
			'rewrite'       	  => [ 'slug' => esc_attr__( 'tasks', 'workforce' ) ],
		] );
	}

	/**
	 * @Filter(name="workforce_crud_post_types")
	 */
	public static function enable_crud( $post_types ) {
		$post_types[] = 'task';
		return $post_types;
	}

	/**
	 * Get display name for status
	 *
	 * @param string $status
	 * @return null|string
	 */
	public static function get_status_display_name( $status ) {
		if ( self::TASK_STATUS_OPEN === $status ) {
			return esc_html__( 'Open', 'workforce' );
		} elseif ( self::TASK_STATUS_RESOLVED === $status ) {
			return esc_html__( 'Resolved', 'workforce' );
		}

		return null;
	}

	/**
	 * @Action(name="cmb2_init")
	 */
	public static function fields() {
		$cmb = new_cmb2_box( [
			'id'            => 'task',
			'title'         => esc_html__( 'Task', 'workforce' ),
			'object_types'  => [ 'task' ],
		]);

		$cmb->add_field( [
			'id'        => 'post_type',
			'type'      => 'hidden',
			'default'   => 'task',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_TASK_PREFIX . 'general_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'General Information', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Status', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'select',
			'id'            => WORKFORCE_TASK_PREFIX . 'status',
			'options'       => [
				self::TASK_STATUS_OPEN      => esc_attr__( 'Open', 'workforce' ),
				self::TASK_STATUS_RESOLVED  => esc_attr__( 'Resolved', 'workforce' ),
			],
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Title', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text',
			'id'            => 'post_title',
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_field( [
			'name'                  => esc_html__( 'Description', 'workforce' ),
			'type'                  => 'wysiwyg',
			'options'               => [
				'media_buttons'     => false,
			],
			'id'                    => 'post_content',
			'attributes'            => [
				'rows'              => 10,
			],
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Assign to', 'workforce' ),
			'type'              => 'select',
			'show_option_none'  => true,
			'id'                => WORKFORCE_TASK_PREFIX . 'user_id',
			'options'           => UserType::get_all_formatted(),
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Project', 'workforce' ),
			'type'              => 'select',
			'show_option_none'  => true,
			'id'                => WORKFORCE_TASK_PREFIX . 'project_id',
			'options'           => ProjectType::get_all_formatted(),
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Due', 'workforce' ),
			'type'              => 'text_datetime_timestamp',
			'id'                => WORKFORCE_TASK_PREFIX . 'due',
			'time_format'       => 'H:i',
			'attributes'        => [
				'placeholder'   => esc_attr__( 'Datetime', 'workforce' ),
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_TASK_PREFIX . 'general_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_TASK_PREFIX . 'repeatable_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Repeatable Options', 'workforce' ) . ' </legend>';
            },
        ] );


		$cmb->add_field( [
			'name'              => esc_html__( 'Repeatable', 'workforce' ),
			'type'              => 'checkbox',
			'id'                => WORKFORCE_TASK_PREFIX . 'repeatable',
			'description'       => esc_html__( 'By checking repeatable you can repeat tasks on weekly basis. Due date above will be ignored.', 'workforce' ),
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Time', 'workforce' ),
			'type'              => 'text_time',
			'id'                => WORKFORCE_TASK_PREFIX . 'repeatable_time',
			'time_format'       => 'H:i',
			'attributes'        => [
				'placeholder'   => esc_attr__( 'Select time', 'workforce' ),
			],
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Repeat weekdays', 'workforce' ),
			'type'              => 'multicheck',
			'id'                => WORKFORCE_TASK_PREFIX . 'repeatable_weekdays',
			'select_all_button' => false,
			'options'           => [
				1 => esc_html__( 'Monday', 'workforce' ),
				2 => esc_html__( 'Tuesday', 'workforce' ),
				3 => esc_html__( 'Wednesday', 'workforce' ),
				4 => esc_html__( 'Thursday', 'workforce' ),
				5 => esc_html__( 'Friday', 'workforce' ),
				6 => esc_html__( 'Saturday', 'workforce' ),
				7 => esc_html__( 'Sunday', 'workforce' ),
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_TASK_PREFIX . 'repeatabble_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_TASK_PREFIX . 'time_tracking_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Time Tracking', 'workforce' ) . '</legend>';
            },
        ] );

		$group = $cmb->add_field( [
			'id'            => WORKFORCE_TASK_PREFIX . 'item',
			'type'          => 'group',
			'post_type'     => 'task',
			'repeatable'    => true,
			'options'       => [
				'group_title'   => esc_html__( 'Task Item', 'workforce' ),
				'add_button'    => esc_html__( 'Add Another Item', 'workforce' ),
				'remove_button' => esc_html__( 'Remove Item', 'workforce' ),
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_TASK_PREFIX . 'item_title',
			'name'          => esc_html__( 'Task', 'workforce' ),
			'type'          => 'text',
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_TASK_PREFIX . 'item_quantity',
			'name'          => esc_html__( 'Hours', 'workforce' ),
			'type'          => 'text_small',
			'default'       => 1,
			'attributes'    => [
				'pattern'   => '\\d*\\.?\\d+',
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_TASK_PREFIX . 'time_tracking_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_TASK_PREFIX . 'custom_fields_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Custom fields', 'workforce' ) . '</legend>';
            },
        ] );

		$group = $cmb->add_field( [
			'id'            => WORKFORCE_TASK_PREFIX . 'custom_field',
			'type'          => 'group',
			'post_type'     => 'company',
			'repeatable'    => true,
			'options'       => [
				'group_title'   => esc_html__( 'Custom Field', 'workforce' ),
				'add_button'    => esc_html__( 'Add Another Custom Field', 'workforce' ),
				'remove_button' => esc_html__( 'Remove Custom Field', 'workforce' ),
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_TASK_PREFIX . 'custom_field_key',
			'name'          => esc_html__( 'Key', 'workforce' ),
			'type'          => 'text',
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_TASK_PREFIX . 'custom_field_value',
			'name'          => esc_html__( 'Value', 'workforce' ),
			'type'          => 'text',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_TASK_PREFIX . 'custom_fields_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_TASK_PREFIX . 'tags_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Tags', 'workforce' ) . '</legend>';
            },
        ] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Tags', 'workforce' ),
			'type'              => 'taxonomy_multicheck',
			'id'                => WORKFORCE_TASK_PREFIX . 'tags',
			'taxonomy'          => 'post_tag',
			'select_all_button' => false,
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_TASK_PREFIX . 'tags_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );
	}

	/**
	 * @Filter(name="workforce_filters")
	 */
	public static function filters( $filters ) {
		$filters['task'] = [
			[
				'input_type'    => 'text',
				'value'         => ! empty( $_GET['keyword'] ) ? $_GET['keyword'] : null,
				'placeholder'   => esc_attr__( 'Search for string', 'workforce' ),
				'label'         => esc_html__( 'Keyword', 'workforce' ),
				'key'           => 'keyword',
				'compare'       => '>=',
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET[ WORKFORCE_TASK_PREFIX . 'status' ] ) ? $_GET[ WORKFORCE_TASK_PREFIX . 'status' ] : null,
				'placeholder'   => esc_attr__( 'Select status', 'workforce' ),
				'label'         => esc_html__( 'Status', 'workforce' ),
				'key'           => WORKFORCE_TASK_PREFIX . 'status',
				'compare'       => '=',
				'options'       => [
					self::TASK_STATUS_OPEN      => esc_attr__( 'Open', 'workforce' ),
					self::TASK_STATUS_RESOLVED  => esc_attr__( 'Resolved', 'workforce' ),
				],
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET[ WORKFORCE_TASK_PREFIX . 'project_id' ] ) ? $_GET[ WORKFORCE_TASK_PREFIX . 'project_id' ] : null,
				'placeholder'   => esc_attr__( 'Select project', 'workforce' ),
				'label'         => esc_html__( 'Project', 'workforce' ),
				'key'           => WORKFORCE_TASK_PREFIX . 'project_id',
				'compare'       => '=',
				'options'       => ProjectType::get_all_formatted(),
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET[ WORKFORCE_TASK_PREFIX . 'user_id' ] ) ? $_GET[ WORKFORCE_TASK_PREFIX . 'user_id' ] : null,
				'placeholder'   => esc_attr__( 'Select colleague', 'workforce' ),
				'label'         => esc_html__( 'Assigned', 'workforce' ),
				'key'           => WORKFORCE_TASK_PREFIX . 'user_id',
				'compare'       => '=',
				'options'       => UserType::get_all_formatted(),
				'type'          => 'NUMERIC',
			],
		];

		return $filters;
	}

	/**
	 * Returns all tasks
	 *
	 * @return array
	 */
	public static function get_all( $status = null, $count = -1 ) {
		$args = [
			'post_type'         => 'task',
			'posts_per_page'    => $count,
			'post_status'       => 'publish',
			'orderby'           => 'date',
			'order'             => 'DESC',
			'meta_query'		=> [],
		];

		if ( ! empty( $status ) ) {
			if ( is_array( $status ) ) {
				$args['meta_query'][] = [
					'key' 		=> WORKFORCE_TASK_PREFIX . 'status',
					'value'		=> $status,
					'compare' 	=> 'IN',
				];
			} else {
				$args['meta_query'][] = [
					'key' 		=> WORKFORCE_TASK_PREFIX . 'status',
					'value'		=> $status,
					'compare' 	=> '=',
				];
			}
		}

		$query = new WP_Query( $args );

		return $query->posts;
	}

	public static function get_by_user( $user_id, $count = 5 ) {
		$query = new WP_Query( [
			'post_type'         => 'task',
			'posts_per_page'    => $count,
			'meta_query'        => [
				[
					'key'       => WORKFORCE_TASK_PREFIX . 'user_id',
					'value'     => $user_id,
					'type'      => 'NUMERIC',
				],
			],
		] );

		return $query->posts;
	}

	public static function get_by_project( $project_id, $count = 5, $status = null ) {
		$query = [
			'key'       => WORKFORCE_TASK_PREFIX . 'project_id',
			'value'     => $project_id,
			'type'      => 'NUMERIC',
		];

		if ( is_array( $project_id ) ) {			
			$query['compare'] = 'IN';
		}

		$args = [
			'post_type'         => 'task',
			'posts_per_page'    => $count,
			'meta_query'        => [ $query ],
		];
		

		if ( ! empty( $status ) ) {
			$args['meta_query'][] = [
				'key'       => WORKFORCE_TASK_PREFIX . 'status',
				'value'     => $status,
				'compare'   => '=',
			];
		}

		$query = new WP_Query( $args );		
		return $query->posts;
	}

	public static function get_tasks_count( $user_id ) {
		$tasks = self::get_by_user( $user_id, -1 );

		if ( empty( $tasks ) ) {
			return 0;
		}

		return count( $tasks );
	}
}
