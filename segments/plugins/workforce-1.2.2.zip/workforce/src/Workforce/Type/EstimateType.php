<?php

namespace Workforce\Type;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;
use WP_Query;

class EstimateType {
	const ESTIMATE_STATUS_DRAFT = 'DRAFT';

	const ESTIMATE_STATUS_SENT = 'SENT';

	const ESTIMATE_STATUS_DECLINED = 'DECLINED';

	const ESTIMATE_STATUS_ACCEPTED = 'ACCEPTED';

	/**
	 * @Action(name="init")
	 */
	public static function register() {
		$labels = [
			'name'                  => esc_html__( 'Estimates', 'workforce' ),
			'singular_name'         => esc_html__( 'Estimate', 'workforce' ),
			'add_new'               => esc_html__( 'Add New Estimate', 'workforce' ),
			'add_new_item'          => esc_html__( 'Add New Estimate', 'workforce' ),
			'edit_item'             => esc_html__( 'Edit Estimate', 'workforce' ),
			'new_item'              => esc_html__( 'New Estimate', 'workforce' ),
			'all_items'             => esc_html__( 'Estimates', 'workforce' ),
			'view_item'             => esc_html__( 'View Estimate', 'workforce' ),
			'search_items'          => esc_html__( 'Search Estimate', 'workforce' ),
			'not_found'             => esc_html__( 'No Estimate found', 'workforce' ),
			'not_found_in_trash'    => esc_html__( 'No Estimates Found in Trash', 'workforce' ),
			'parent_item_colon'     => '',
			'menu_name'             => esc_html__( 'Estimates', 'workforce' ),
		];

		register_post_type( 'estimate', [
			'labels'              => $labels,
			'supports'            => [ 'title', 'author' ],
			'public'              => true,
			'has_archive'         => true,
			'exclude_from_search' => true,
			'show_ui'             => true,
			'rewrite'       	  => [ 'slug' => esc_attr__( 'estimates', 'workforce' ) ],
		] );
	}

	/**
	 * @Filter(name="workforce_crud_post_types")
	 */
	public static function enable_crud( $post_types ) {
		$post_types[] = 'estimate';
		return $post_types;
	}

	/**
	 * Get display name for status
	 *
	 * @param string $status
	 * @return null|string
	 */
	public static function get_status_display_name( $status ) {
		if ( self::ESTIMATE_STATUS_DRAFT === $status ) {
			return esc_html__( 'Draft', 'workforce' );
		} elseif ( self::ESTIMATE_STATUS_SENT === $status ) {
			return esc_html__( 'Sent', 'workforce' );
		} elseif ( self::ESTIMATE_STATUS_DECLINED === $status ) {
			return esc_html__( 'Declined', 'workforce' );
		} elseif ( self::ESTIMATE_STATUS_ACCEPTED === $status ) {
			return esc_html__( 'Accepted', 'workforce' );
		}

		return null;
	}

	/**
	 * @Action(name="cmb2_init")
	 */
	public static function fields() {
		// Payment information
		$cmb = new_cmb2_box( [
			'id'            => 'estimate',
			'title'         => esc_html__( 'Estimate', 'workforce' ),
			'object_types'  => [ 'estimate' ],
			'context'       => 'normal',
			'priority'      => 'high',
		] );

		$cmb->add_field( [
			'id'        => 'post_type',
			'type'      => 'hidden',
			'default'   => 'estimate',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_ESTIMATE_PREFIX . 'general_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'General Information', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Name', 'workforce' ) . '<span class="required">*</span>',
			'id'            => 'post_title',
			'type'          => 'text',
			'attributes'        => [
				'required'      => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Status', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'select',
			'id'            => WORKFORCE_ESTIMATE_PREFIX . 'status',
			'options'       => [
				self::ESTIMATE_STATUS_DRAFT         => esc_attr__( 'Draft', 'workforce' ),
				self::ESTIMATE_STATUS_SENT          => esc_attr__( 'Sent', 'workforce' ),
				self::ESTIMATE_STATUS_DECLINED      => esc_attr__( 'Declined', 'workforce' ),
				self::ESTIMATE_STATUS_ACCEPTED      => esc_attr__( 'Accepted', 'workforce' ),
			],
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Company', 'workforce' ) . '<span class="required">*</span>',
			'type'              => 'select',
			'show_option_none'  => true,
			'id'                => WORKFORCE_ESTIMATE_PREFIX . 'company_id',
			'options'           => CompanyType::get_all_formatted(),
			'attributes'        => [
				'required'      => 'required',
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_ESTIMATE_PREFIX . 'general_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_ESTIMATE_PREFIX . 'items_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Items', 'workforce' ) . ' </legend>';
            },
        ] );

		$group = $cmb->add_field( [
			'id'          	=> WORKFORCE_ESTIMATE_PREFIX . 'item',
			'type'        	=> 'group',
			'post_type'   	=> 'estimate',
			'repeatable'  	=> true,
			'options'     	=> [
				'group_title'   => esc_html__( 'Estimate Item', 'workforce' ),
				'add_button'    => esc_html__( 'Add Another Item', 'workforce' ),
				'remove_button' => esc_html__( 'Remove Item', 'workforce' ),
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_ESTIMATE_PREFIX . 'item_title',
			'name'          => esc_html__( 'Title', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text',
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_ESTIMATE_PREFIX . 'item_quantity',
			'name'          => esc_html__( 'Quantity', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text_small',
			'default'       => 1,
			'attributes'    => [
				'required'  => 'required',
				'pattern'   => '\\d*\\.?\\d+',
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_ESTIMATE_PREFIX . 'item_unit_price',
			'name'          => esc_html__( 'Unit price', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text_small',
			'attributes'    => [
				'required'  => 'required',
				'pattern'   => '\\d*\\.?\\d+',
			],
		] );

		$tax_rate = get_theme_mod( 'workforce_invoices_tax_rate', null );
		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_ESTIMATE_PREFIX . 'item_tax_rate',
			'name'          => esc_html__( 'Tax rate', 'workforce' ) . '<span class="required">*</span>',
			'description'   => esc_html__( 'Enter value in percents e.g. 20%', 'workforce' ),
			'type'          => 'text_small',
			'default'       => $tax_rate,
			'attributes'    => [
				'required'  => 'required',
				'pattern'   => '\\d*\\.?\\d+',
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_ESTIMATE_PREFIX . 'items_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_ESTIMATE_PREFIX . 'default_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Override default values', 'workforce' ) . ' </legend>';
            },
        ] );

        $currency_code = get_theme_mod( 'workforce_invoices_currency_code', 'USD' );
        $cmb->add_field( [
            'name'          => esc_html__( 'Currency code', 'workforce' ) . '<span class="required">*</span>',
            'id'            => WORKFORCE_ESTIMATE_PREFIX . 'currency_code',
            'type'          => 'text_small',
            'default'       => $currency_code,
            'attributes'    => [
                'required'  => 'required',
            ],
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_ESTIMATE_PREFIX . 'default_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_ESTIMATE_PREFIX . 'custom_fields_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Custom Fields', 'workforce' ) . ' </legend>';
            },
        ] );

		$group = $cmb->add_field( [
			'id'            => WORKFORCE_ESTIMATE_PREFIX . 'custom_field',
			'type'          => 'group',
			'post_type'     => 'company',
			'repeatable'    => true,
			'options'       => [
				'group_title'   => esc_html__( 'Record', 'workforce' ),
				'add_button'    => esc_html__( 'Add Another Custom Field', 'workforce' ),
				'remove_button' => esc_html__( 'Remove Custom Field', 'workforce' ),
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_ESTIMATE_PREFIX . 'custom_field_key',
			'name'          => esc_html__( 'Key', 'workforce' ),
			'type'          => 'text',
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_ESTIMATE_PREFIX . 'custom_field_value',
			'name'          => esc_html__( 'Value', 'workforce' ),
			'type'          => 'text',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_ESTIMATE_PREFIX . 'custom_fields_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );
	}

	/**
	 * Calculates item subtotal
	 *
	 * @param $item array
	 * @return float
	 */
	public static function get_subtotal( $item ) {
		// unit price
		$unit_price_key = WORKFORCE_ESTIMATE_PREFIX . 'item_unit_price';
		$unit_price = ( ! empty( $item[ $unit_price_key ] ) ) ? (float) $item[ $unit_price_key ] : 0;

		// quantity
		$quantity_key = WORKFORCE_ESTIMATE_PREFIX . 'item_quantity';
		$quantity = ( ! empty( $item[ $quantity_key ] ) ) ? (float) $item[ $quantity_key ] : 0;

		// tax rate
		$tax_rate_key = WORKFORCE_ESTIMATE_PREFIX . 'item_tax_rate';
		$tax_rate = ( ! empty( $item[ $tax_rate_key ] ) ) ? (float) $item[ $tax_rate_key ] : 0;

		// item price
		$rate = (float) ( 100 + $tax_rate ) / 100;
		$subtotal = $unit_price * $quantity * $rate;

		return round( $subtotal, 2 );
	}

	/**
	 * Calculates total price
	 *
	 * @param $id int
	 * @return float
	 */
	public static function get_total( $id ) {
		$items = get_post_meta( $id, WORKFORCE_ESTIMATE_PREFIX . 'item', true );

		$total = 0;

		if ( ! is_array( $items ) ) {
			return $total;
		}

		foreach ( $items as $item ) {
			$item_price = self::get_subtotal( $item );
			$total += $item_price;
		}

		return round( $total, 2 );
	}

	/**
	 * @Filter(name="workforce_filters")
	 */
	public static function filters( $filters ) {
		$filters['estimate'] = [
			[
				'input_type'    => 'text',
				'value'         => ! empty( $_GET['keyword'] ) ? $_GET['keyword'] : null,
				'placeholder'   => esc_attr__( 'Search for string', 'workforce' ),
				'label'         => esc_html__( 'Keyword', 'workforce' ),
				'key'           => 'keyword',
				'compare'       => '>=',
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET[ WORKFORCE_ESTIMATE_PREFIX . 'status' ] ) ? $_GET[ WORKFORCE_ESTIMATE_PREFIX . 'status' ] : null,
				'placeholder'   => esc_attr__( 'Select status', 'workforce' ),
				'label'         => esc_html__( 'Status', 'workforce' ),
				'key'           => WORKFORCE_ESTIMATE_PREFIX . 'status',
				'compare'       => '=',
				'options'       => [
					self::ESTIMATE_STATUS_DRAFT         => esc_attr__( 'Draft', 'workforce' ),
					self::ESTIMATE_STATUS_SENT          => esc_attr__( 'Sent', 'workforce' ),
					self::ESTIMATE_STATUS_DECLINED      => esc_attr__( 'Declined', 'workforce' ),
					self::ESTIMATE_STATUS_ACCEPTED      => esc_attr__( 'Accepted', 'workforce' ),
				],
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET[ WORKFORCE_ESTIMATE_PREFIX . 'company_id' ] ) ? $_GET[ WORKFORCE_ESTIMATE_PREFIX . 'company_id' ] : null,
				'placeholder'   => esc_attr__( 'Select company', 'workforce' ),
				'label'         => esc_html__( 'Company', 'workforce' ),
				'key'           => WORKFORCE_ESTIMATE_PREFIX . 'company_id',
				'compare'       => '=',
				'options'       => CompanyType::get_all_formatted(),
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET['author'] ) ? $_GET['author'] : null,
				'placeholder'   => esc_attr__( 'Select author', 'workforce' ),
				'label'         => esc_html__( 'Author', 'workforce' ),
				'key'           => 'author',
				'compare'       => '=',
				'options'       => UserType::get_all_formatted(),

			],
		];

		return $filters;
	}

	/**
	 * Returns all estimates
	 *
	 * @return array
	 */
	public static function get_all( $status = null, $count = -1 ) {
		$args = [
			'post_type'         => 'estimate',
			'posts_per_page'    => $count,
			'post_status'       => 'publish',
			'orderby'           => 'date',
			'order'             => 'DESC',
			'meta_query'		=> [],
		];

		if ( ! empty( $status ) ) {
			if ( is_array( $status ) ) {
				$args['meta_query'][] = [
					'key' 		=> WORKFORCE_ESTIMATE_PREFIX . 'status',
					'value'		=> $status,
					'compare' 	=> 'IN',
				];
			} else {
				$args['meta_query'][] = [
					'key' 		=> WORKFORCE_ESTIMATE_PREFIX . 'status',
					'value'		=> $status,
					'compare' 	=> '=',
				];
			}
		}

		$query = new WP_Query( $args );

		return $query->posts;
	}	
}
