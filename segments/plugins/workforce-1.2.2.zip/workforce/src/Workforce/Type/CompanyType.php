<?php

namespace Workforce\Type;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;
use WP_Query;

class CompanyType {
	/**
	 * @Action(name="init")
	 */
	public static function register() {
		$labels = [
			'name'                  => esc_html__( 'Companies', 'workforce' ),
			'singular_name'         => esc_html__( 'Company', 'workforce' ),
			'add_new'               => esc_html__( 'Add New Company', 'workforce' ),
			'add_new_item'          => esc_html__( 'Add New Company', 'workforce' ),
			'edit_item'             => esc_html__( 'Edit Company', 'workforce' ),
			'new_item'              => esc_html__( 'New Company', 'workforce' ),
			'all_items'             => esc_html__( 'Companies', 'workforce' ),
			'view_item'             => esc_html__( 'View Company', 'workforce' ),
			'search_items'          => esc_html__( 'Search Company', 'workforce' ),
			'not_found'             => esc_html__( 'No Company found', 'workforce' ),
			'not_found_in_trash'    => esc_html__( 'No Companies Found in Trash', 'workforce' ),
			'parent_item_colon'     => '',
			'menu_name'             => esc_html__( 'Companies', 'workforce' ),
		];

		register_post_type( 'company', [
			'labels'              => $labels,
			'supports'            => [ 'title', 'thumbnail', 'author' ],
			'public'              => true,
			'has_archive'         => true,
			'show_ui'             => true,
			'exclude_from_search' => true,
			'rewrite'       	  => [ 'slug' => esc_attr__( 'companies', 'workforce' ) ],
		] );
	}

	/**
	 * @Filter(name="workforce_crud_post_types")
	 */
	public static function enable_crud( $post_types ) {
	    $post_types[] = 'company';
		return $post_types;
	}

	/**
	 * @Action(name="cmb2_init")
	 */
	public static function fields() {
		$cmb = new_cmb2_box( [
			'id'           => 'company',
			'title'        => esc_html__( 'Company', 'workforce' ),
			'object_types' => [ 'company' ],
		] );

		$cmb->add_field( [
			'id'        => 'post_type',
			'type'      => 'hidden',
			'default'   => 'company',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_COMPANY_PREFIX . 'general_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'General Information', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Name', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text',
			'id'            => 'post_title',
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Website', 'workforce' ),
			'type'          => 'text',
			'id'            => WORKFORCE_COMPANY_PREFIX . 'website',
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'E-mail', 'workforce' ),
			'type'          => 'text',
			'id'            => WORKFORCE_COMPANY_PREFIX . 'email',
			'repeatable'    => true,
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Phone', 'workforce' ),
			'type'          => 'text',
			'id'            => WORKFORCE_COMPANY_PREFIX . 'phone',
			'repeatable'    => true,
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Address', 'workforce' ),
			'type'          => 'textarea',
			'id'            => WORKFORCE_COMPANY_PREFIX . 'address',
			'attributes'    => [
				'rows'      => 3,
			],
		] );

        $cmb->add_field( [
            'name'              => esc_html__( 'Image', 'workforce' ),
            'type'              => 'file',
            'id'                => WORKFORCE_COMPANY_PREFIX . 'image',
            'options' => [
                'url' => false,
            ],
            'text'    => [
                'add_upload_file_text' => esc_attr( 'Upload Image', 'workforce' ),
            ],
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_COMPANY_PREFIX . 'general_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_COMPANY_PREFIX . 'billing_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Billing Information', 'workforce' ) . ' </legend>';
            },
        ] );

        $cmb->add_field( [
            'name'          => esc_html__( 'Name', 'workforce' ),
            'type'          => 'text',
            'id'            => WORKFORCE_COMPANY_PREFIX . 'billing_name',
        ] );

        $cmb->add_field( [
            'name'          => esc_html__( 'VAT Number', 'workforce' ),
            'type'          => 'text',
            'id'            => WORKFORCE_COMPANY_PREFIX . 'billing_vat_number',
        ] );

        $cmb->add_field( [
            'name'          => esc_html__( 'Registration Number', 'workforce' ),
            'type'          => 'text',
            'id'            => WORKFORCE_COMPANY_PREFIX . 'billing_registration_number',
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_COMPANY_PREFIX . 'billing_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_COMPANY_PREFIX . 'custom_fields_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Custom Fields', 'workforce' ) . ' </legend>';
            },
        ] );

        $group = $cmb->add_field( [
            'id'            => WORKFORCE_COMPANY_PREFIX . 'custom_field',
            'type'          => 'group',
            'post_type'     => 'company',
            'repeatable'    => true,
            'options'       => [
                'group_title'   => esc_html__( 'Record', 'workforce' ),
                'add_button'    => esc_html__( 'Add Another Record', 'workforce' ),
                'remove_button' => esc_html__( 'Remove Record', 'workforce' ),
            ],
        ] );

        $cmb->add_group_field( $group, [
            'id'            => WORKFORCE_COMPANY_PREFIX . 'custom_field_key',
            'name'          => esc_html__( 'Key', 'workforce' ),
            'type'          => 'text',
        ] );

        $cmb->add_group_field( $group, [
            'id'            => WORKFORCE_COMPANY_PREFIX . 'custom_field_value',
            'name'          => esc_html__( 'Value', 'workforce' ),
            'type'          => 'text',
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_COMPANY_PREFIX . 'custom_fields_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_COMPANY_PREFIX . 'billing_tags_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Tags', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'type'              => 'taxonomy_multicheck',
			'id'                => WORKFORCE_COMPANY_PREFIX . 'tags',
			'taxonomy'          => 'post_tag',
			'select_all_button' => false,
		] );


        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'      => WORKFORCE_COMPANY_PREFIX . 'billing_tags_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );
	}

	/**
	 * @return array
	 */
	public static function get_all() {
		$query = new WP_Query( [
			'post_type'         => 'company',
			'post_status'       => 'publish',
			'posts_per_page'    => -1,
		] );

		return $query->posts;
	}

	/**
	 * @return array
	 */
	public static function get_all_formatted() {
		$results = [];
		$companies = self::get_all();

		foreach ( $companies as $company ) {
			$results[ $company->ID ] = $company->post_title;
		}

		return $results;
	}

	public static function get_revenue( $company_id,  $status = [] ) {
		$query = new WP_Query( [
			'post_type' 		=> 'invoice',
			'post_status' 		=> 'publish',
			'posts_per_page' 	=> -1,
			'meta_query' 		=> [
				[
					'key' 		=> WORKFORCE_INVOICE_PREFIX . 'company_id',
					'value' 	=> $company_id,
					'compare' 	=> '=',
					'type'		=> 'NUMERIC',
				],
				[
					'key'		=> WORKFORCE_INVOICE_PREFIX . 'status',
					'value' 	=> $status, 
					'compare'	=> 'IN',
				]
			]
		] );

		if ( ! empty( $query->posts ) ) {
			$result = [];

			foreach( $query->posts as $invoice ) {
				$currency_code = get_post_meta( $invoice->ID, WORKFORCE_INVOICE_PREFIX . 'currency_code', true );
				$total = InvoiceType::get_invoice_total( $invoice->ID );

				if ( ! empty( $result[ $currency_code ] ) ) {
					$result[ $currency_code ]['total'] += $total; 
				} else {
					$result[ $currency_code ] = [
						'currency_code' => $currency_code,
						'total'			=> $total,
					];
				}
			}

			return $result;
		}

		return null;
	}

	/**
	 * @Filter(name="workforce_filters")
	 */
	public static function filters( $filters ) {
		$filters['company'] = [
			[
				'input_type'    => 'text',
				'value'         => ! empty( $_GET['keyword'] ) ? $_GET['keyword'] : null,
				'placeholder'   => esc_attr__( 'Search for string', 'workforce' ),
				'label'         => esc_html__( 'Keyword', 'workforce' ),
				'key'           => 'keyword',
				'compare'       => '>=',
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET['postauthor'] ) ? $_GET['postauthor'] : null,
				'placeholder'   => esc_attr__( 'Select author', 'workforce' ),
				'label'         => esc_html__( 'Author', 'workforce' ),
				'key'           => 'postauthor',
				'compare'       => '=',
				'options'       => UserType::get_all_formatted(),

			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET['post_tag'] ) ? $_GET['post_tag'] : null,
				'placeholder'   => esc_attr__( 'Select tag', 'workforce' ),
				'label'         => esc_html__( 'Tag', 'workforce' ),
				'key'           => 'taxonomy',
				'taxonomy'      => 'post_tag',
				'compare'       => '=',
			],
		];

		return $filters;
	}
}
