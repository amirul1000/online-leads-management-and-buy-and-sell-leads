<?php

namespace Workforce\Type;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;

use WP_Query;

class ExpenseType {
	/**
	 * @Action(name="init")
	 */
	public static function register() {
		$labels = [
			'name'                  => esc_html__( 'Expenses', 'workforce' ),
			'singular_name'         => esc_html__( 'Expense', 'workforce' ),
			'add_new'               => esc_html__( 'Add New Expense', 'workforce' ),
			'add_new_item'          => esc_html__( 'Add New Expense', 'workforce' ),
			'edit_item'             => esc_html__( 'Edit Expense', 'workforce' ),
			'new_item'              => esc_html__( 'New Expense', 'workforce' ),
			'all_items'             => esc_html__( 'Expenses', 'workforce' ),
			'view_item'             => esc_html__( 'View Expenses', 'workforce' ),
			'search_items'          => esc_html__( 'Search Expense', 'workforce' ),
			'not_found'             => esc_html__( 'No Expense found', 'workforce' ),
			'not_found_in_trash'    => esc_html__( 'No Expenses Found in Trash', 'workforce' ),
			'parent_item_colon'     => '',
			'menu_name'             => esc_html__( 'Expenses', 'workforce' ),
		];

		register_post_type( 'expense', [
			'labels'              => $labels,
			'supports'            => [ 'title', 'author' ],
			'public'              => true,
			'has_archive'         => true,
			'show_ui'             => true,
			'exclude_from_search' => true,
			'rewrite'             => [ 'slug' => esc_attr__( 'expenses', 'workforce' ) ],
		] );
	}

	/**
	 * @Filter(name="workforce_crud_post_types")
	 */
	public static function enable_crud( $post_types ) {
		$post_types[] = 'expense';
		return $post_types;
	}

	/**
	 * @Action(name="cmb2_init")
	 */
	public static function fields() {
		$cmb = new_cmb2_box( [
			'id'           => 'expense',
			'title'        => esc_html__( 'Expense', 'workforce' ),
			'object_types' => [ 'expense' ],
		] );

		$cmb->add_field( [
			'id'        => 'post_type',
			'type'      => 'hidden',
			'default'   => 'expense',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_EXPENSE_PREFIX . 'general_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'General Information', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Name', 'workforce' ) . '<span class="required">*</span>',
			'id'            => 'post_title',
			'type'          => 'text',
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_field( [
			'id'            => WORKFORCE_EXPENSE_PREFIX . 'price',
			'name'          => esc_html__( 'Price', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text_small',
			'attributes'    => [
				'required'  => 'required',
				'pattern'   => '\\d*\\.?\\d+',
			],
		] );

		$currency_code = get_theme_mod( 'workforce_invoices_currency_code', 'USD' );
		$cmb->add_field( [
			'name'          => esc_html__( 'Currency code', 'workforce' ) . '<span class="required">*</span>',
			'id'            => WORKFORCE_EXPENSE_PREFIX . 'currency_code',
			'type'          => 'text_small',
			'default'       => $currency_code,
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Date', 'workforce' ) . '<span class="required">*</span>',
			'type'              => 'text_date_timestamp',
			'id'                => WORKFORCE_EXPENSE_PREFIX . 'date',
			'attributes'        => [
				'required'      => 'required',
				'placeholder'   => esc_attr__( 'Datetime', 'workforce' ),
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_EXPENSE_PREFIX . 'general_information_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_EXPENSE_PREFIX . 'custom_fields_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Custom Fields', 'workforce' ) . ' </legend>';
            },
        ] );

		$group = $cmb->add_field( [
			'id'            => WORKFORCE_EXPENSE_PREFIX . 'custom_field',
			'type'          => 'group',
			'post_type'     => 'company',
			'repeatable'    => true,
			'options'       => [
				'group_title'   => esc_html__( 'Record', 'workforce' ),
				'add_button'    => esc_html__( 'Add Another Custom Field', 'workforce' ),
				'remove_button' => esc_html__( 'Remove Custom Field', 'workforce' ),
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_EXPENSE_PREFIX . 'custom_field_key',
			'name'          => esc_html__( 'Key', 'workforce' ),
			'type'          => 'text',
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_EXPENSE_PREFIX . 'custom_field_value',
			'name'          => esc_html__( 'Value', 'workforce' ),
			'type'          => 'text',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_EXPENSE_PREFIX . 'custom_fields_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_EXPENSE_PREFIX . 'tags_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Tags', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Expense Type', 'workforce' ),
			'type'              => 'taxonomy_select',
			'id'                => WORKFORCE_EXPENSE_PREFIX . 'type',
			'taxonomy'          => 'expense_type',
			'select_all_button' => false,
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Tags', 'workforce' ),
			'type'              => 'taxonomy_multicheck',
			'id'                => WORKFORCE_EXPENSE_PREFIX . 'tags',
			'taxonomy'          => 'post_tag',
			'select_all_button' => false,
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_EXPENSE_PREFIX . 'tags_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );
	}

	/**
	 * @Filter(name="workforce_filters")
	 */
	public static function filters( $filters ) {
		$filters['expense'] = [
			[
				'input_type'    => 'text',
				'value'         => ! empty( $_GET['keyword'] ) ? $_GET['keyword'] : null,
				'placeholder'   => esc_attr__( 'Search for string', 'workforce' ),
				'label'         => esc_html__( 'Keyword', 'workforce' ),
				'key'           => 'keyword',
				'compare'       => '>=',
				'type'          => 'NUMERIC',
			],
			[
				'id'            => 'date_start',
				'input_name'    => WORKFORCE_EXPENSE_PREFIX . 'date_start',
				'input_type'    => 'text',
				'class'         => 'has-datepicker',
				'value'         => ! empty( $_GET[ WORKFORCE_EXPENSE_PREFIX . 'date_start' ] ) ? $_GET[ WORKFORCE_EXPENSE_PREFIX . 'date_start' ] : null,
				'placeholder'   => esc_attr__( 'Start date', 'workforce' ),
				'label'         => esc_html__( 'Starts', 'workforce' ),
				'key'           => WORKFORCE_EXPENSE_PREFIX . 'date',
				'compare'       => '>=',
			],
			[
				'id'            => 'date_end',
				'input_name'    => WORKFORCE_EXPENSE_PREFIX . 'date_end',
				'input_type'    => 'text',
				'class'         => 'has-datepicker',
				'value'         => ! empty( $_GET[ WORKFORCE_EXPENSE_PREFIX . 'date_end' ] ) ? $_GET[ WORKFORCE_EXPENSE_PREFIX . 'date_end' ] : null,
				'placeholder'   => esc_attr__( 'End date', 'workforce' ),
				'label'         => esc_html__( 'Ends', 'workforce' ),
				'key'           => WORKFORCE_EXPENSE_PREFIX . 'date',
				'compare'       => '<=',
			],
		];

		return $filters;
	}

	/**
	 * Returns all estimates
	 *
	 * @return array
	 */
	public static function get_all( $count = -1 ) {
		$args = [
			'post_type'         => 'expense',
			'posts_per_page'    => $count,
			'post_status'       => 'publish',
			'orderby'           => 'date',
			'order'             => 'DESC',
			'meta_query'		=> [],
		];

		$query = new WP_Query( $args );

		return $query->posts;
	}	

	public static function get_all_total() {
		$expenses = self::get_all();
		$total = [];

		foreach( $expenses as $expense ) {
			$currency_code = get_post_meta( $expense->ID, WORKFORCE_EXPENSE_PREFIX . 'currency_code', true );
			$price = get_post_meta( $expense->ID, WORKFORCE_EXPENSE_PREFIX . 'price', true );

			if ( ! empty( $total[ $currency_code ] ) ) {
				$total[ $currency_code ]['total'] += $price;
			} else {
				$total[ $currency_code ] = [
					'currency_code' => $currency_code,
					'total' 		=> $price,
				];
			}
		}

		return $total;
	}	
}
