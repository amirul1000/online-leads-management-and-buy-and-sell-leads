<?php

namespace Workforce\Type;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;
use Workforce\Helper\TemplateHelper;
use WP_Query;

class LeadFormType {
	/**
	 * @Action(name="init")
	 */
	public static function register() {
		$labels = [
			'name'                  => esc_html__( 'Lead Forms', 'workforce' ),
			'singular_name'         => esc_html__( 'Lead Form', 'workforce' ),
			'add_new'               => esc_html__( 'Add New Lead Form', 'workforce' ),
			'add_new_item'          => esc_html__( 'Add New Lead Form', 'workforce' ),
			'edit_item'             => esc_html__( 'Edit Lead Form', 'workforce' ),
			'new_item'              => esc_html__( 'New Lead Form', 'workforce' ),
			'all_items'             => esc_html__( 'Lead Forms', 'workforce' ),
			'view_item'             => esc_html__( 'View Lead Form', 'workforce' ),
			'search_items'          => esc_html__( 'Search Lead Forms', 'workforce' ),
			'not_found'             => esc_html__( 'No Lead Form Found', 'workforce' ),
			'not_found_in_trash'    => esc_html__( 'No Lead Form Found in Trash', 'workforce' ),
			'parent_item_colon'     => '',
			'menu_name'             => esc_html__( 'Lead Forms', 'workforce' ),				
		];

		register_post_type( 'lead_form', [
			'labels'              => $labels,
			'supports'            => [ 'title', 'author' ],
			'public'              => true,
			'has_archive'         => true,
			'show_ui'             => true,
			'exclude_from_search' => true,
			'rewrite'       	  => [ 'slug' => esc_attr__( 'lead-forms', 'workforce' ) ],
		] );		
	}

	/**
	 * @Filter(name="workforce_crud_post_types")
	 */
	public static function enable_crud( $post_types ) {
		$post_types[] = 'lead_form';
		return $post_types;
	}

	/**
	 * @Action(name="cmb2_init")
	 */
	public static function fields() {
		$cmb = new_cmb2_box( [
			'id'           => 'lead_form',
			'title'        => esc_html__( 'Lead Form', 'workforce' ),
			'object_types' => [ 'lead_form' ],
		] );

		$cmb->add_field( [
			'id'        => 'post_type',
			'type'      => 'hidden',
			'default'   => 'lead_form',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_LEAD_FORM_PREFIX . 'general_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'General Information', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Name', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text',
			'id'            => 'post_title',
			'attributes'    => [
				'required'  => 'required',
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_LEAD_FORM_PREFIX . 'general_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_LEAD_FORM_PREFIX . 'fields_general_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Fields', 'workforce' ) . ' </legend>';
            },
        ] );

		$group = $cmb->add_field( [
			'id'            => WORKFORCE_LEAD_FORM_PREFIX . 'fields',
			'type'          => 'group',
			'post_type'     => 'lead_form',
			'repeatable'    => true,
			'options'       => [
				'sortable'		=> true,
				'group_title'   => esc_html__( 'Form Field', 'workforce' ),
				'add_button'    => esc_html__( 'Add Another Field', 'workforce' ),
				'remove_button' => esc_html__( 'Remove Field', 'workforce' ),
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => 'label',
			'name'          => esc_html__( 'Label', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text',
			'attributes'    => [
				'required'  => 'required',
			],			
		] );	

		$cmb->add_group_field( $group, [
			'id'            => 'id',
			'name'          => esc_html__( 'ID', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text',
			'attributes'    => [
				'required'  => 'required',
			],			
		] );	

		$cmb->add_group_field( $group, [
			'id'            => 'type',
			'name'          => esc_html__( 'Type', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'select',
			'attributes'    => [
				'required'  => 'required',
			],			
            'options'       => [
                'text'              => esc_attr__( 'Text', 'workforce' ),
                'email'        		=> esc_attr__( 'Email', 'workforce' ),
                'url'          		=> esc_attr__( 'URL', 'workforce' ),
                'textarea'          => esc_attr__( 'Textarea', 'workforce' ),
                'select'            => esc_attr__( 'Select', 'workforce' ),
            ],			
		] );

		$cmb->add_group_field( $group, [
			'id'            => 'values',
			'name'          => esc_html__( 'Values', 'workforce' ),
			'type'          => 'textarea',
			'attributes'	=> [
				'rows'		=> 4,
			]
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_LEAD_FORM_PREFIX . 'fields_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );


		$cmb->add_group_field( $group, [
			'id'            => 'required',
			'name'          => esc_html__( 'Required', 'workforce' ),
			'type'          => 'checkbox',
		] );	
	}

	public static function get_form( $id ) {
		$fields = get_post_meta( $id, WORKFORCE_LEAD_FORM_PREFIX . 'fields', true );
		$result = '';

		if ( ! empty( $fields ) ) {
			$result .= TemplateHelper::load( 'lead-form/form-prefix', [
				'id' => $id,
			] );

			foreach ( $fields as $field ) {
				$result .= TemplateHelper::load( 'lead-form/fields/' . $field['type'] , $field );
			}

			$result .= TemplateHelper::load( 'lead-form/form-submit', [
				'id' => $id,
			]  );
			
			$result .= TemplateHelper::load( 'lead-form/form-suffix', [
				'id' => $id,
			]  );
		}

		return $result;
	}

	public static function get_captures( $id ) {
		$query = new WP_Query( [
			'post_type' 		=> 'lead',
			'post_status' 		=> 'publish',
			'posts_per_page' 	=> -1,
			'meta_query'		=> [
				[
					'key' 		=> WORKFORCE_LEAD_PREFIX . 'capture_form_id',
					'value' 	=> $id,
					'compare' 	=> '=',
					'type' 		=> 'NUMERIC',
				]
			]
		] );

		return count( $query->posts );
	}
}