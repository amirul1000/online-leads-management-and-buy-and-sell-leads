<?php

namespace Workforce\Type;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;

use WP_User_Query;

class UserType {
	/**
	 * @Action(name="init")
	 */
	public static function register() {
		$labels = [
			'name'                  => esc_html__( 'Colleagues', 'workforce' ),
			'singular_name'         => esc_html__( 'Colleague', 'workforce' ),
			'add_new'               => esc_html__( 'Add New Colleague', 'workforce' ),
			'add_new_item'          => esc_html__( 'Add New Colleague', 'workforce' ),
			'edit_item'             => esc_html__( 'Edit Colleague', 'workforce' ),
			'new_item'              => esc_html__( 'New Colleague', 'workforce' ),
			'all_items'             => esc_html__( 'Colleagues', 'workforce' ),
			'view_item'             => esc_html__( 'View Colleague', 'workforce' ),
			'search_items'          => esc_html__( 'Search Colleague', 'workforce' ),
			'not_found'             => esc_html__( 'No Colleague found', 'workforce' ),
			'not_found_in_trash'    => esc_html__( 'No Colleagues Found in Trash', 'workforce' ),
			'parent_item_colon'     => '',
			'menu_name'             => esc_html__( 'Colleagues', 'workforce' ),
		];

		register_post_type( 'colleague', [
			'labels'              => $labels,
			'supports'            => [],
			'public'              => true,
			'has_archive'         => true,
			'exclude_from_search' => true,
			'show_ui'             => false,
			'rewrite'       	  => [ 'slug' => esc_attr__( 'colleagues', 'workforce' ) ],
		] );
	}

	/**
	 * @Filter(name="workforce_crud_post_types")
	 */
	public static function enable_crud( $post_types ) {
		$post_types[] = 'colleague';
		return $post_types;
	}

	public static function get_all() {
		$query = new WP_User_Query( [
			'number' => -1,
		] );

		return $query->results;
	}

	/**
	 * @return array
	 */
	public static function get_all_formatted() {
		$results = [];
		$objects = self::get_all();

		foreach ( $objects as $object ) {
			$results[ $object->ID ] = self::get_name( $object->ID );
		}

		return $results;
	}

	/**
	 * @Action(name="cmb2_init")
	 */
	public static function fields() {
		$cmb = new_cmb2_box( [
			'id'            => 'user',
			'title'         => esc_html__( 'User', 'workforce' ),
			'object_types'  => [ 'user' ],
		]);

		if ( is_admin() ) {
			$cmb->add_field( [
				'id'        		=> WORKFORCE_USER_PREFIX . 'company_id',
				'name'      		=> esc_html__( 'Company', 'workforce' ),
				'type'      		=> 'select',
				'show_option_none' 	=> true,
				'options'			=> CompanyType::get_all_formatted(),
			] );
		}

		$cmb->add_field( [
			'id'        => 'post_type',
			'type'      => 'hidden',
			'default'   => 'user',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'general_image',
			'name'      => esc_html__( 'Image', 'workforce' ),
			'type'      => 'file',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'general_first_name',
			'name'      => esc_html__( 'First name', 'workforce' ),
			'type'      => 'text',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'general_last_name',
			'name'      => esc_html__( 'Last name', 'workforce' ),
			'type'      => 'text',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'general_email',
			'name'      => esc_html__( 'E-mail', 'workforce' ),
			'type'      => 'text',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'general_website',
			'name'      => esc_html__( 'Website', 'workforce' ),
			'type'      => 'text',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'general_phone',
			'name'      => esc_html__( 'Phone', 'workforce' ),
			'type'      => 'text',
		] );

		// Address
		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'address_title',
			'name'      => esc_html__( 'Address', 'workforce' ),
			'type'      => 'title',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'address_country',
			'name'      => esc_html__( 'Country', 'workforce' ),
			'type'      => 'text',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'address_county',
			'name'      => esc_html__( 'State / County', 'workforce' ),
			'type'      => 'text',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'address_city',
			'name'      => esc_html__( 'City', 'workforce' ),
			'type'      => 'text',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'address_street_and_number',
			'name'      => esc_html__( 'Street and number', 'workforce' ),
			'type'      => 'text',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'address_postal_code',
			'name'      => esc_html__( 'Postal code', 'workforce' ),
			'type'      => 'text',
		] );

		// Social Connections
		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'social_title',
			'name'      => esc_html__( 'Social Connections', 'workforce' ),
			'type'      => 'title',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'social_facebook',
			'name'      => esc_html__( 'Facebook', 'workforce' ),
			'type'      => 'text',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'social_twitter',
			'name'      => esc_html__( 'Twitter', 'workforce' ),
			'type'      => 'text',
		] );

		$cmb->add_field( [
			'id'        => WORKFORCE_USER_PREFIX . 'social_linkedin',
			'name'      => esc_html__( 'LinkedIn', 'workforce' ),
			'type'      => 'text',
		] );
	}

	public static function get_name( $user_id, $display_you = true ) {
		$user = get_userdata( $user_id );

 		$user_exists = get_userdata( $user_id );
 		if ( ! $user_exists ) {
 			return esc_html__( 'UNDEFINED', 'workforce' );
 		}

		if ( ! empty( $user->first_name ) && ! empty( $user->last_name ) ) {
			$name = $user->first_name . ' ' . $user->last_name;
		} else {
			$name = $user->display_name;
		}

		if ( $display_you && $user_id == get_current_user_id() ) {
			$name .= sprintf( ' (%s)', esc_html__( 'You', 'workforce' ) );
		}

		return $name;
	}
}
