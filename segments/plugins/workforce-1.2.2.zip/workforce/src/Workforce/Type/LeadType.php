<?php

namespace Workforce\Type;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;
use Workforce\Helper\TemplateHelper;
use WP_Query;

class LeadType {
	/**
	 * @Action(name="init")
	 */
	public static function register() {
		$labels = [
			'name'                  => esc_html__( 'Leads', 'workforce' ),
			'singular_name'         => esc_html__( 'Lead', 'workforce' ),
			'add_new'               => esc_html__( 'Add New Lead', 'workforce' ),
			'add_new_item'          => esc_html__( 'Add New Lead', 'workforce' ),
			'edit_item'             => esc_html__( 'Edit Lead', 'workforce' ),
			'new_item'              => esc_html__( 'New Lead', 'workforce' ),
			'all_items'             => esc_html__( 'Leads', 'workforce' ),
			'view_item'             => esc_html__( 'View Lead ', 'workforce' ),
			'search_items'          => esc_html__( 'Search Leads', 'workforce' ),
			'not_found'             => esc_html__( 'No Leads Found', 'workforce' ),
			'not_found_in_trash'    => esc_html__( 'No Leads Found in Trash', 'workforce' ),
			'parent_item_colon'     => '',
			'menu_name'             => esc_html__( 'Leads', 'workforce' ),
		];

		register_post_type( 'lead', [
			'labels'              => $labels,
			'supports'            => [ 'title', 'author' ],
			'public'              => true,
			'has_archive'         => true,
			'show_ui'             => true,
			'exclude_from_search' => true,
			'rewrite'       	  => [ 'slug' => esc_attr__( 'leads', 'workforce' ) ],
		] );		
	}

	/**
	 * @Filter(name="workforce_crud_post_types")
	 */
	public static function enable_crud( $post_types ) {
		$post_types[] = 'lead';
		return $post_types;
	}

	/**
	 * @Action(name="cmb2_init")
	 */
	public static function fields() {
		$cmb = new_cmb2_box( [
			'id'           => 'lead',
			'title'        => esc_html__( 'Lead', 'workforce' ),
			'object_types' => [ 'lead' ],
		] );

		$cmb->add_field( [
			'id'        => 'post_type',
			'type'      => 'hidden',
			'default'   => 'lead',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_LEAD_PREFIX . 'general_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'General Information', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Name', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text',
			'id'            => 'post_title',
			'attributes'    => [
				'required'  => 'required',
			],
		] );

        $cmb->add_field( [
            'name'              => esc_html__( 'Assign to', 'workforce' ),
            'type'              => 'select',
            'show_option_none'  => true,
            'id'                => WORKFORCE_LEAD_PREFIX . 'user_id',
            'options'           => UserType::get_all_formatted(),
        ] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Capture Form ID', 'workforce' ),
			'type'          => 'text',
			'id'            => WORKFORCE_LEAD_PREFIX . 'capture_form_id',
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Company', 'workforce' ),
			'type'          => 'text',
			'id'            => WORKFORCE_LEAD_PREFIX . 'company',
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'E-mail', 'workforce' ),
			'type'          => 'text',
			'id'            => WORKFORCE_LEAD_PREFIX . 'email',
			'repeatable'    => true,
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Phone', 'workforce' ),
			'type'          => 'text',
			'id'            => WORKFORCE_LEAD_PREFIX . 'phone',
			'repeatable'    => true,
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'About', 'workforce' ),
			'type'          => 'textarea',
			'id'            => WORKFORCE_LEAD_PREFIX . 'about',
			'attributes'    => [
				'rows'      => 3,
			],
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_TASK_PREFIX . 'general_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_LEAD_PREFIX . 'custom_fields_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Custom Fields', 'workforce' ) . ' </legend>';
            },
        ] );

		$group = $cmb->add_field( [
			'id'            	=> WORKFORCE_LEAD_PREFIX . 'custom_field',
			'type'          	=> 'group',
			'post_type'     	=> 'company',
			'repeatable'    	=> true,
			'options'       	=> [
				'group_title'   => esc_html__( 'Record', 'workforce' ),
				'add_button'    => esc_html__( 'Add Another Custom Field', 'workforce' ),
				'remove_button' => esc_html__( 'Remove Custom Field', 'workforce' ),
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => 'key',
			'name'          => esc_html__( 'Key', 'workforce' ),
			'type'          => 'text',
		] );

		$cmb->add_group_field( $group, [
			'id'            => 'value',
			'name'          => esc_html__( 'Value', 'workforce' ),
			'type'          => 'text',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_TASK_PREFIX . 'custom_fields_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_LEAD_PREFIX . 'tags_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Tags', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Lead Type', 'workforce' ),
			'type'              => 'taxonomy_select',
			'id'                => WORKFORCE_LEAD_PREFIX . 'type',
			'taxonomy'          => 'lead_type',
			'select_all_button' => false,
		] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Tags', 'workforce' ),
			'type'              => 'taxonomy_multicheck',
			'id'                => WORKFORCE_LEAD_PREFIX . 'tags',
			'taxonomy'          => 'post_tag',
			'select_all_button' => false,
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_TASK_PREFIX . 'custom_fields_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );
	}

    /**
     * @Filter(name="workforce_filters")
     */
    public static function filters( $filters ) {
        $filters['lead'] = [
            [
                'input_type'    => 'text',
                'value'         => ! empty( $_GET['keyword'] ) ? $_GET['keyword'] : null,
                'placeholder'   => esc_attr__( 'Search for string', 'workforce' ),
                'label'         => esc_html__( 'Keyword', 'workforce' ),
                'key'           => 'keyword',
                'compare'       => '>=',
                'type'          => 'NUMERIC',
            ],
            [
                'input_type'    => 'select',
                'allow_null'    => true,
                'value'         => ! empty( $_GET[ WORKFORCE_LEAD_PREFIX . 'user_id' ] ) ? $_GET[ WORKFORCE_LEAD_PREFIX . 'user_id' ] : null,
                'placeholder'   => esc_attr__( 'Select colleague', 'workforce' ),
                'label'         => esc_html__( 'Assigned', 'workforce' ),
                'key'           => WORKFORCE_LEAD_PREFIX . 'user_id',
                'compare'       => '=',
                'options'       => UserType::get_all_formatted(),
                'type'          => 'NUMERIC',
            ],
            [
                'input_type'    => 'select',
                'allow_null'    => true,
                'value'         => ! empty( $_GET['lead_type'] ) ? $_GET['lead_type'] : null,
                'placeholder'   => esc_attr__( 'Select lead type', 'workforce' ),
                'label'         => esc_html__( 'Lead type', 'workforce' ),
                'key'           => 'taxonomy',
                'taxonomy'      => 'lead_type',
                'compare'       => '=',
            ],
        ];

        return $filters;
    }

	public static function is_converted( $id ) {
		$query = new WP_Query( [
			'post_type' 		=> 'customer',
			'post_status' 		=> 'publish',
			'posts_per_page' 	=> -1,
			'meta_query' 		=> [
				[
					'key' 		=> WORKFORCE_CUSTOMER_PREFIX . 'lead_id',
					'value'		=> $id,
					'compare' 	=> '=',
					'type' 		=> 'NUMERIC',
				],
			]
		] );

		if ( ! empty( $query->posts ) && count( $query->posts ) > 0 ) {
			return true;
		}

		return false;
	}
}