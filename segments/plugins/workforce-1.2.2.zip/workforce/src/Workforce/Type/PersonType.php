<?php

namespace Workforce\Type;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;
use Workforce\Helper\TemplateHelper;
use WP_Query;

class PersonType {
	/**
	 * @Action(name="init")
	 */
	public static function register() {
		$labels = [
			'name'                  => esc_html__( 'People', 'workforce' ),
			'singular_name'         => esc_html__( 'Person', 'workforce' ),
			'add_new'               => esc_html__( 'Add New Person', 'workforce' ),
			'add_new_item'          => esc_html__( 'Add New Person', 'workforce' ),
			'edit_item'             => esc_html__( 'Edit Person', 'workforce' ),
			'new_item'              => esc_html__( 'New Person', 'workforce' ),
			'all_items'             => esc_html__( 'People', 'workforce' ),
			'view_item'             => esc_html__( 'View Person', 'workforce' ),
			'search_items'          => esc_html__( 'Search People', 'workforce' ),
			'not_found'             => esc_html__( 'No Person Found', 'workforce' ),
			'not_found_in_trash'    => esc_html__( 'No Person Found in Trash', 'workforce' ),
			'parent_item_colon'     => '',
			'menu_name'             => esc_html__( 'People', 'workforce' ),
		];

		register_post_type( 'person', [
			'labels'              => $labels,
			'supports'            => [ 'title', 'editor', 'author' ],
			'public'              => true,
			'has_archive'         => true,
			'show_ui'             => true,
			'exclude_from_search' => true,
			'rewrite'       	  => [ 'slug' => esc_attr__( 'people', 'workforce' ) ],
		] );
	}

	/**
	 * @Filter(name="workforce_crud_post_types")
	 */
	public static function enable_crud( $post_types ) {
		$post_types[] = 'person';
		return $post_types;
	}

	/**
	 * @Action(name="cmb2_init")
	 */
	public static function fields() {
		$cmb = new_cmb2_box( [
			'id'           => 'person',
			'title'        => esc_html__( 'Person', 'workforce' ),
			'object_types' => [ 'person' ],
		] );

		$cmb->add_field( [
			'id'        => 'post_type',
			'type'      => 'hidden',
			'default'   => 'person',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_PERSON_PREFIX . 'general_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'General Information', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Company', 'workforce' ),
			'type'              => 'select',
			'show_option_none'  => true,
			'id'                => WORKFORCE_PERSON_PREFIX . 'company_id',
			'options'           => CompanyType::get_all_formatted(),
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'First Name', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text',
			'id'            => WORKFORCE_PERSON_PREFIX . 'first_name',
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Last Name', 'workforce' ) . '<span class="required">*</span>',
			'type'          => 'text',
			'id'            => WORKFORCE_PERSON_PREFIX . 'last_name',
			'attributes'    => [
				'required'  => 'required',
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Position', 'workforce' ),
			'type'          => 'text',
			'id'            => WORKFORCE_PERSON_PREFIX . 'position',
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Address', 'workforce' ),
			'type'          => 'textarea',
			'id'            => WORKFORCE_PERSON_PREFIX . 'address',
			'attributes'    => [
				'rows'      => 3,
			],
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Website', 'workforce' ),
			'type'          => 'text_url',
			'id'            => WORKFORCE_PERSON_PREFIX . 'website',
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'Phone', 'workforce' ),
			'type'          => 'text',
			'id'            => WORKFORCE_PERSON_PREFIX . 'phone',
			'repeatable'    => true,
		] );

		$cmb->add_field( [
			'name'          => esc_html__( 'E-mail', 'workforce' ),
			'type'          => 'text_email',
			'id'            => WORKFORCE_PERSON_PREFIX . 'email',
			'repeatable'    => true,
		] );

        $cmb->add_field( [
            'name'              => esc_html__( 'Image', 'workforce' ),
            'type'              => 'file',
            'id'                => WORKFORCE_PERSON_PREFIX . 'image',
            'options' => [
                'url' => false,
            ],
            'text'    => [
                'add_upload_file_text' => esc_attr( 'Upload Image', 'workforce' ),
            ],
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_PERSON_PREFIX . 'general_information_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_PERSON_PREFIX . 'custom_fields_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Custom Fields', 'workforce' ) . ' </legend>';
            },
        ] );

		$group = $cmb->add_field( [
			'id'            => WORKFORCE_PERSON_PREFIX . 'custom_field',
			'type'          => 'group',
			'post_type'     => 'company',
			'repeatable'    => true,
			'options'       => [
				'group_title'   => esc_html__( 'Record', 'workforce' ),
				'add_button'    => esc_html__( 'Add Another Custom Field', 'workforce' ),
				'remove_button' => esc_html__( 'Remove Custom Field', 'workforce' ),
			],
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_PERSON_PREFIX . 'custom_field_key',
			'name'          => esc_html__( 'Key', 'workforce' ),
			'type'          => 'text',
		] );

		$cmb->add_group_field( $group, [
			'id'            => WORKFORCE_PERSON_PREFIX . 'custom_field_value',
			'name'          => esc_html__( 'Value', 'workforce' ),
			'type'          => 'text',
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_PERSON_PREFIX . 'custom_fields_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );

        $cmb->add_field( [
            'type'          => 'fieldset_start',
            'id'            => WORKFORCE_PERSON_PREFIX . 'tags_fieldset_start',
            'render_row_cb' => function( $field_args, $field ) {
                return '<fieldset><legend>' . esc_html__( 'Tags', 'workforce' ) . ' </legend>';
            },
        ] );

		$cmb->add_field( [
			'name'              => esc_html__( 'Tags', 'workforce' ),
			'type'              => 'taxonomy_multicheck',
			'id'                => WORKFORCE_PERSON_PREFIX . 'tags',
			'taxonomy'          => 'post_tag',
			'select_all_button' => false,
		] );

        $cmb->add_field( [
            'type'          => 'fieldset_end',
            'id'            => WORKFORCE_PERSON_PREFIX . 'tags_fieldset_end',
            'render_row_cb' => function( $field_args, $field ) {
                return '</fieldset>';
            },
        ] );
	}

	/**
	 * @param int $company_id
	 * @return array
	 */
	public static function get_all( $company_id = null ) {
		$args = [
			'post_type'         => 'person',
			'post_status'       => 'publish',
			'posts_per_page'    => -1,
		];

		if ( ! empty( $company_id ) ) {
			$args['meta_query'] = [
				[
					'key'       => WORKFORCE_PERSON_PREFIX . 'company_id',
					'value'     => $company_id,
					'type'      => 'NUMERIC',
				],
			];
		}

		$query = new WP_Query( $args );

		return $query->posts;
	}

	/**
	 * @param int $company_id
	 * @return array
	 */
	public static function get_all_formatted( $company_id = null ) {
		$results = [];
		$persons = self::get_all( $company_id );

		foreach ( $persons as $person ) {
			$results[ $person->ID ] = $person->post_title;
		}

		return $results;
	}

	public static function get_position( $id ) {
		$company_id = get_post_meta( $id, WORKFORCE_PERSON_PREFIX . 'company_id', true );
		$position = get_post_meta( $id, WORKFORCE_PERSON_PREFIX . 'position', true );

		return sprintf( '%s at %s', $position, get_the_title( $company_id ) );
	}

	/**
	 * @Filter(name="workforce_filters")
	 */
	public static function filters( $filters ) {
		$filters['person'] = [
			[
				'input_type'    => 'text',
				'value'         => ! empty( $_GET['keyword'] ) ? $_GET['keyword'] : null,
				'placeholder'   => esc_attr__( 'Search for string', 'workforce' ),
				'label'         => esc_html__( 'Keyword', 'workforce' ),
				'key'           => 'keyword',
				'compare'       => '>=',
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET[ WORKFORCE_PERSON_PREFIX . 'company_id' ] ) ? $_GET[ WORKFORCE_PERSON_PREFIX . 'company_id' ] : null,
				'placeholder'   => esc_attr__( 'Select company', 'workforce' ),
				'label'         => esc_html__( 'Company', 'workforce' ),
				'key'           => WORKFORCE_PERSON_PREFIX . 'company_id',
				'compare'       => '=',
				'options'       => CompanyType::get_all_formatted(),
				'type'          => 'NUMERIC',
			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET['postauthor'] ) ? $_GET['postauthor'] : null,
				'placeholder'   => esc_attr__( 'Select author', 'workforce' ),
				'label'         => esc_html__( 'Author', 'workforce' ),
				'key'           => 'postauthor',
				'compare'       => '=',
				'options'       => UserType::get_all_formatted(),

			],
			[
				'input_type'    => 'select',
				'allow_null'    => true,
				'value'         => ! empty( $_GET['post_tag'] ) ? $_GET['post_tag'] : null,
				'placeholder'   => esc_attr__( 'Select one', 'workforce' ),
				'label'         => esc_html__( 'Tag', 'workforce' ),
				'key'           => 'taxonomy',
				'taxonomy'      => 'post_tag',
				'compare'       => '=',
			],
		];

		return $filters;
	}

	public static function get_by_company( $company_id, $count = 5 ) {
		$query = new WP_Query( [
			'post_type'         => 'person',
			'posts_per_page'    => $count,
			'meta_query'        => [
				[
					'key'       => WORKFORCE_PERSON_PREFIX . 'company_id',
					'value'     => $company_id,
					'type'      => 'NUMERIC',
				],
			],
		] );

		return $query->posts;
	}
}
