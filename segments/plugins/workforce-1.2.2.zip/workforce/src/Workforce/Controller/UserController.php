<?php

namespace Workforce\Controller;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;
use Workforce\Helper\MessageHelper;

use WP_User_Query;

class UserController {
	/**
	 * @Action(name="pre_get_posts")
	 */
	public static function media_files( $wp_query ) {
		global $current_user;

		if ( ! current_user_can( 'manage_options' ) && ( is_admin() && 'attachment' === $wp_query->query['post_type']) ) {
			$wp_query->set( 'author', $current_user->ID );
		}
	}

	/**
	 * @Filter(name="wp_count_attachments")
	 */
	public static function recount_attachments( $counts_in ) {
		global $wpdb;
		global $current_user;

		$and = wp_post_mime_type_where( '' );
		$count = $wpdb->get_results( "SELECT post_mime_type, COUNT( * ) AS num_posts FROM $wpdb->posts WHERE post_type = 'attachment' AND post_status != 'trash' AND post_author = {$current_user->ID} $and GROUP BY post_mime_type", ARRAY_A );

		$counts = [];
		foreach ( (array) $count as $row ) {
			$counts[ $row['post_mime_type'] ] = $row['num_posts'];
		}

		$counts['trash'] = $wpdb->get_var( "SELECT COUNT( * ) FROM $wpdb->posts WHERE post_type = 'attachment' AND post_author = {$current_user->ID} AND post_status = 'trash' $and" );
		return $counts;
	}

	/**
	 * @Action(name="wp")
	 * @Action(name="admin_init")
	 */
	public static function set_users_default_capabilities() {
		$user_query = new WP_User_Query( [ 'role__in' => ['employee', 'administrator', ], 'number' => -1 ] );

		if ( ! empty( $user_query->results ) ) {
			foreach ( $user_query->results as $user ) {
				$has_default_capabilities = get_user_meta( $user->ID, 'has_default_capabilities', true );

				if ( empty( $has_default_capabilities ) ) {
					$caps = \Workforce\Bootstrap::capabilities();

					foreach ( $caps as $cap_key => $cap_value ) {
						$user->add_cap( $cap_key );
					}

					update_user_meta( $user->ID, 'has_default_capabilities', true );
				}
			}
		}
	}

	public static function redirect_not_allowed() {
		MessageHelper::add( esc_html__( 'You are not allowed to access this page.', 'workforce' ), MessageHelper::STATUS_DANGER );

		if ( is_user_logged_in() ) {
			$dashboard_id = get_theme_mod( 'workforce_pages_dashboard', null );
			$redirect = ! empty( $dashboard_id ) ? get_permalink( $dashboard_id ) : site_url( '/' );
		} else {
			$login_id = get_theme_mod( 'workforce_pages_login', null );
			$redirect = ! empty( $login_id ) ? get_permalink( $login_id ) : site_url( '/' );
		}

		wp_redirect( $redirect );
		exit();
	}

	/**
	 * @Filter(name="wp_get_nav_menu_items", priority=20, accepted_args=2)
	 */
	public static function check_menu( $items, $menu ) {
		if ( ! is_user_logged_in() ) {
			return $items;
		}

		if ( ! empty( $items ) ) {
			$post_types = apply_filters( 'workforce_crud_post_types', [] );

			foreach ( $items as $item_id => $item ) {
				if ( 'archive_pages' === $item->object ) {
					$term = get_term( $item->object_id, 'archive_pages' );

					if ( in_array( $term->slug, $post_types ) ) {
						if ( ! current_user_can( 'workforce_' . $term->slug ) ) {
							unset( $items[ $item_id ] );
						}
					}
				}
			}
		}

		return $items;
	}

	/**
	 * @Action(name="wp")
	 */
	public static function check_capabilities() {
		global $wp_query;

		if ( is_admin() ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			return;
		}

		$post_types = apply_filters( 'workforce_crud_post_types', [] );
		if ( is_post_type_archive( $post_types ) ) {
			if ( ! current_user_can( 'workforce_' . $wp_query->query['post_type'] ) ) {
				self::redirect_not_allowed();
			}
		}

		$query_var = get_query_var( 'workforce-post-type' );
		if ( ! empty( $query_var ) && in_array( $query_var, $post_types ) ) {
			if ( ! current_user_can( 'workforce_' . $query_var ) ) {
				self::redirect_not_allowed();
			}
		}
	}

	public static function is_private() {
		global $wp_query;
		global $post;

		$post_types = apply_filters( 'workforce_crud_post_types', [] );
		$dashboard_id = get_theme_mod( 'workforce_pages_dashboard', null );
		$change_password_id = get_theme_mod( 'workforce_pages_change_password', null );
		$profile_id = get_theme_mod( 'workforce_pages_profile', null );
		$current_page_id = ! empty( $wp_query->queried_object_id ) ? $wp_query->queried_object_id : ! empty( $wp_query->query_vars['page_id'] ) ? $wp_query->query_vars['page_id'] : null;
		$workforce_post_type = get_query_var( 'workforce-post-type' );
		$workforce_action = get_query_var( 'workforce-action' );
		$workforce_id = get_query_var( 'workforce-id' );

		if ( empty( $current_page_id ) && ! empty( $post ) ) {
			$current_page_id = $post->ID;
		}

		if ( $current_page_id == $dashboard_id ) {
			return true;
		}

		if ( is_post_type_archive( $post_types ) || is_singular( $post_types ) ) {
			return true;
		}

		if ( ! empty( $workforce_post_type ) || ! empty( $workforce_action ) || ! empty( $workforce_id ) ) {
			return true;
		}

		if ( get_query_var( 'author' ) ) {
			return true;
		}
		

		return false;
	}

    /**
     * @Action(name="wp")
     */
	public static function make_everything_private() {
        $private_site = get_theme_mod( 'workforce_general_private_site', false );

        if ( ! empty( $private_site ) && ! is_user_logged_in() ) {
            $login_id = get_theme_mod( 'workforce_pages_login', false );

            if ( ! empty( $login_id ) ) {
                if ( $login_id != get_the_ID() ) {
                    wp_redirect( get_permalink( $login_id ) );
                    exit();
                }
            } else {
                auth_redirect();
            }
        }
    }

	/**
	 * @Action(name="wp")
	 */
	public static function make_site_private() {
        if ( is_admin() ) {
            return;
        }

		if ( self::is_private() && ! is_user_logged_in() ) {
			self::redirect_to_login();
		}

		$user = wp_get_current_user();
		if ( self::is_private() && is_user_logged_in() ) {
			if ( ! in_array( 'administrator', (array) $user->roles ) && ! in_array( 'employee', (array) $user->roles ) ) {
				MessageHelper::add( esc_attr__( 'Only employees and administrators are allowed to access this page.', 'workforce' ), MessageHelper::STATUS_DANGER );

				if ( in_array( 'client',  (array) $user->roles ) ) {
                    wp_redirect( home_url( '/' . esc_attr__( 'client-zone', 'workforce' ) ) );
                } else {
                    wp_redirect( home_url( '/' ) );
                }
				exit();
			}
		}
	}

	/**
	 * @Action(name="wp")
	 */
	public static function make_client_zone_private() {
        if ( is_admin() ) {
            return;
        }

		$client_zone = get_query_var( 'workforce-client-zone');

		if ( ! empty( $client_zone ) && ! is_user_logged_in() ) {
			self::redirect_to_login();
		}

		$user = wp_get_current_user();

		if ( ! empty( $client_zone ) && is_user_logged_in() ) {
			if ( ! in_array( 'client', (array) $user->roles ) ) {				
				MessageHelper::add( esc_attr__( 'Only clients are allowed to access this page.', 'workforce' ), MessageHelper::STATUS_DANGER );
				wp_redirect( home_url( '/' ) );
				exit();
			}
		}
	}

	public static function redirect_to_login() {
		$login_page = get_theme_mod( 'workforce_pages_login', null );

		if ( $login_page ) {
			wp_redirect( get_permalink( $login_page ) );
			exit();
		}

		auth_redirect();
	}

	/**
	 * @Action(name="wp")
	 */
	public static function login() {
        if ( is_admin() ) {
            return;
        }

		$login_page = get_theme_mod( 'workforce_pages_login', null );

		if ( is_admin() ) {
			return;
		}

		if ( ! $login_page ) {
			return;
		}

		if ( get_the_ID() != $login_page ) {
			return;
		}

		if ( is_user_logged_in() ) {
			MessageHelper::add( esc_html__( 'Before login please sign out.', 'workforce' ), MessageHelper::STATUS_DANGER );
			wp_redirect( home_url( '/' ) );
			exit();
		}
	}

	/**
	 * @Action(name="init")
	 */
	public static function login_process() {
		if ( ! isset( $_POST['login_form'] ) ) {
			return;
		}

		if ( empty( $_POST['login'] ) || empty( $_POST['password'] ) ) {
			MessageHelper::add( esc_html__( 'Login and password are required.', 'workforce' ), MessageHelper::STATUS_DANGER );
			return;
		}

		self::login_user( $_POST['login'], $_POST['password'] );
	}

	public static function login_user( $login, $password ) {
		$user = wp_signon( [ 'user_login' => $login, 'user_password' => $password ], false );

		if ( is_wp_error( $user ) ) {
			MessageHelper::add( $user->get_error_message(), MessageHelper::STATUS_DANGER );
			return;
		}

		// login page
		$login_required_page = get_theme_mod( 'workforce_pages_login' );
		$login_required_page_url = $login_required_page ? get_permalink( $login_required_page ) : site_url();

		// after login page
		$after_login_page = get_theme_mod( 'workforce_pages_login_after' );
		$after_login_page_url = $after_login_page ? get_permalink( $after_login_page ) : site_url();

		// if user logs in at login page, redirect him to after login page. Otherwise, redirect him back to previous URL.
		$protocol = is_ssl() ? 'https://' : 'http://';
		$current_url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

		// Special condition for clients
		$user = get_userdata( $user->ID );
		if ( in_array( 'client', (array) $user->roles ) ) {						
			$after_login_page_url = $protocol . $_SERVER['HTTP_HOST'] . '/' . esc_attr__( 'client-zone', 'workforce' ) . '/';
		}

		wp_redirect( $after_login_page_url );
		exit();
	}

	/**
	 * @Action(name="wp")
	 */
	public static function register() {
		$register_page = get_theme_mod( 'workforce_pages_register', null );

		if ( is_admin() ) {
			return;
		}

		if ( ! $register_page ) {
			return;
		}

		if ( get_the_ID() != $register_page ) {
			return;
		}

		if ( ! get_option( 'users_can_register' ) ) {
			MessageHelper::add( esc_html__( 'User registration are not allowed.', 'workforce' ), MessageHelper::STATUS_DANGER );
			wp_redirect( home_url( '/' ) );
			exit();
		}

		if ( is_user_logged_in() ) {
			MessageHelper::add( esc_html__( 'Before registration please sign out.', 'workforce' ), MessageHelper::STATUS_DANGER );
			wp_redirect( home_url( '/' ) );
			exit();
		}
	}

	/**
	 * @Action(name="init")
	 */
	public static function register_process() {
		if ( ! isset( $_POST['register_form'] ) ) {
			return;
		}

		$register_page = get_theme_mod( 'workforce_pages_register', null );

		if ( ! get_option( 'users_can_register' ) ) {
			MessageHelper::add( esc_html__( 'User registrations are not allowed.', 'workforce' ), MessageHelper::STATUS_DANGER );
			wp_redirect( get_permalink( $register_page ) );
			exit();
		}

		if ( empty( $_POST['username'] ) || empty( $_POST['email'] ) ) {
			MessageHelper::add( esc_html__( 'Username and e-mail are required.', 'workforce' ), MessageHelper::STATUS_DANGER );
			wp_redirect( get_permalink( $register_page ) );
			exit();
		}

		$user_id = username_exists( $_POST['username'] );
		if ( ! empty( $user_id ) ) {
			MessageHelper::add( esc_html__( 'Username already exists.', 'workforce' ), MessageHelper::STATUS_DANGER );
			wp_redirect( get_permalink( $register_page ) );
			exit();
		}

		$user_id = email_exists( $_POST['email'] );
		if ( ! empty( $user_id ) ) {
			MessageHelper::add( esc_html__( 'Email already exists.', 'workforce' ), MessageHelper::STATUS_DANGER );
			wp_redirect( get_permalink( $register_page ) );
			exit();
		}

		if ( $_POST['password'] != $_POST['password_retype'] ) {
			MessageHelper::add( esc_html__( 'Passwords must be same.', 'workforce' ), MessageHelper::STATUS_DANGER );
			wp_redirect( get_permalink( $register_page ) );
			exit();
		}

		$terms_id = get_theme_mod( 'workforce_pages_terms', false );

		if ( $terms_id && empty( $_POST['terms'] ) ) {
			MessageHelper::add( esc_html__( 'You must agree terms &amp; conditions.', 'workforce' ), MessageHelper::STATUS_DANGER );
			wp_redirect( get_permalink( $register_page ) );
			exit();
		}

		if ( $_POST['password'] != $_POST['password_retype'] ) {
			MessageHelper::add( esc_html__( 'Passwords must be same.', 'workforce' ), MessageHelper::STATUS_DANGER );
			wp_redirect( get_permalink( $register_page ) );
			exit();
		}

        // Accepted terms and conditions
        $terms_id = get_theme_mod( 'workforce_pages_tos', null );

        if ( ! empty( $terms_id ) && empty( $_POST[ 'agree_terms' ] ) ) {
            MessageHelper::add( esc_html__( 'You must agree terms &amp; conditions.', 'workforce' ), MessageHelper::STATUS_DANGER );
            wp_redirect( get_permalink( $register_page ) );
            exit();
        }

		$user_login = $_POST['username'];
		$user_id = wp_create_user( $user_login, $_POST['password'], $_POST['email'] );

		wp_new_user_notification( $user_id, null, 'both' );

		if ( is_wp_error( $user_id ) ) {
			MessageHelper::add( $user_id->get_error_message(), MessageHelper::STATUS_DANGER );
			wp_redirect( get_permalink( $register_page ) );
			exit();
		}

		MessageHelper::add( esc_html__( 'You have been successfully registered.', 'workforce' ), MessageHelper::STATUS_SUCCESS );
		$user = get_user_by( 'login', $user_login );
		$log_in_after_registration = get_theme_mod( 'workforce_general_login_after_registration', false );

		// automatic user log in
		if ( $user && $log_in_after_registration ) {
			wp_set_current_user( $user->ID, $user_login );
			wp_set_auth_cookie( $user->ID );
			do_action( 'wp_login', $user_login );
		}

		// registration page
		$registration_page = get_theme_mod( 'workforce_pages_register' );
		$registration_page_url = $registration_page ? get_permalink( $registration_page ) : site_url();

		// after register page
		$after_register_page = get_theme_mod( 'workforce_pages_register_after' );
		$after_register_page_url = $after_register_page ? get_permalink( $after_register_page ) : site_url();

		// if user registers at registration page, redirect him to after register page. Otherwise, redirect him back to previous URL.
		$protocol = is_ssl() ? 'https://' : 'http://';
		$current_url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

		$after_register_url = $current_url == $registration_page_url ? $after_register_page_url : $current_url;

		wp_redirect( $after_register_url );
		exit();
	}

	/**
	 * @Action(name="wp")
	 */
	public static function change_password() {
		$reset_password_page = get_theme_mod( 'workforce_pages_reset_password', null );

		if ( is_admin() ) {
			return;
		}

		if ( ! $reset_password_page ) {
			return;
		}

		if ( get_the_ID() != $reset_password_page ) {
			return;
		}

		if ( is_user_logged_in() ) {
			MessageHelper::add( esc_html__( 'Resetting password functionality is available only for anymous users.', 'workforce' ), MessageHelper::STATUS_DANGER );
			wp_redirect( home_url( '/' ) );
			exit();
		}
	}

	/**
	 * @Action(name="init")
	 */
	public static function change_password_process() {
		if ( ! isset( $_POST['change_password_form'] ) ) {
			return;
		}

		$old_password = $_POST['old_password'];
		$new_password = $_POST['new_password'];
		$retype_password = $_POST['retype_password'];

		if ( empty( $old_password ) || empty( $new_password ) || empty( $retype_password ) ) {
			MessageHelper::add( esc_html__( 'All fields are required.', 'workforce' ), MessageHelper::STATUS_DANGER );
			return;
		}

		if ( $new_password != $retype_password ) {
			MessageHelper::add( esc_html__( 'New and retyped password are not same.', 'workforce' ), MessageHelper::STATUS_DANGER );
			return;
		}

		$user = wp_get_current_user();

		if ( ! wp_check_password( $old_password, $user->data->user_pass, $user->ID ) ) {
			MessageHelper::add( esc_html__( 'Your old password is not correct.', 'workforce' ), MessageHelper::STATUS_DANGER );
			return;
		}

		wp_set_password( $new_password, $user->ID );
		MessageHelper::add( esc_html__( 'Your password has been successfully changed.', 'workforce' ), MessageHelper::STATUS_DANGER );
	}

	/**
	 * @Action(name="init")
	 */
	public static function reset_password_process() {
		if ( ! isset( $_POST['reset_form'] ) ) {
			return;
		}

		$result = retrieve_password();

		if ( is_wp_error( $result ) ) {
			MessageHelper::add( esc_html__( 'Unable to send an e-mail.', 'workforce' ), MessageHelper::STATUS_DANGER );
		} else {
			MessageHelper::add( esc_html__( 'Please check inbox for more information.', 'workforce' ), MessageHelper::STATUS_SUCCESS );
		}

		wp_redirect( $_SERVER['HTTP_REFERER'] );
		exit();
	}

	/**
	 * @Action(name="wp")
	 */
	public static function logout() {
        if ( is_admin() ) {
            return;
        }
        		
		$logout_page = get_theme_mod( 'workforce_pages_logout', null );

		if ( ! $logout_page ) {
			return;
		}

		if ( $logout_page == get_the_ID() ) {
			MessageHelper::add(
				esc_html__( 'You have been successfully signed out.', 'workforce' ),
			MessageHelper::STATUS_SUCCESS );
			wp_logout();
			wp_redirect( home_url( '/' ) );
			exit();
		}
	}

	/**
	 * @Action(name="cmb2_init", priority=9999)
	 */
	public static function process_profile_form() {
		if ( ! empty( $_POST['submit-cmb'] ) && ! empty( $_POST['post_type'] ) && 'user' === $_POST['post_type'] ) {
			$cmb = cmb2_get_metabox( 'user', get_current_user_id() );
			$cmb->save_fields( get_current_user_id(), 'user', $_POST );
			MessageHelper::add( esc_html__( 'Profile has been successfully saved.', 'workforce' ), MessageHelper::STATUS_SUCCESS );

			$profile_id = get_theme_mod( 'workforce_pages_profile', null );
			if ( ! empty( $profile_id ) ) {
				wp_redirect( get_the_permalink( $profile_id ) );
				exit();
			}
		}
	}

	/**
	 * @Action(name="cmb2_sanitize_text", priority=10, accepted_args=5)
	 */
	public static function sanitize_text( $override_value, $value, $object_id, $field_args, $sanitizer_object ) {
		$object_type = $sanitizer_object->field->object_type;
		$field_id = $sanitizer_object->field->args['id'];

		if ( 'user' !== $object_type ) {
			return $value;
		}

		if ( $field_id == WORKFORCE_USER_PREFIX . 'general_first_name' ) {
			wp_update_user( [ 'ID' => $object_id, 'first_name' => $value ] );
		}

		if ( $field_id == WORKFORCE_USER_PREFIX . 'general_last_name' ) {
			wp_update_user( [ 'ID' => $object_id, 'last_name' => $value ] );
		}

		return $value;
	}
}
