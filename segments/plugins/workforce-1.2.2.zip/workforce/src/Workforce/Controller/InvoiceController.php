<?php

namespace Workforce\Controller;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;
use Workforce\Helper\MessageHelper;
use Workforce\Helper\TemplateHelper;
use Workforce\Type\InvoiceType;

use mPDF;

class InvoiceController {
    public static function get_invoice_template( $id ) {
        $invoice = TemplateHelper::load( 'helpers/invoice', [
            'id'                            => $id,
            'issue_date'                    => get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'date', true ),
            'currency_code'                 => get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'currency_code', true ),
            'payment_term'                  => get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'payment_term', true ),
            'details'                       => get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'details', true ),
            'supplier_name'                 => get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'supplier_name', true ),
            'supplier_registration_number'  => get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'supplier_registration_number', true ),
            'supplier_vat_number'           => get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'supplier_vat_number', true ),
            'supplier_details'              => get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'supplier_details', true ),
            'customer_name'                 => get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'customer_name', true ),
            'customer_registration_number'  => get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'customer_registration_number', true ),
            'customer_vat_number'           => get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'customer_vat_number', true ),
            'customer_details'              => get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'customer_details', true ),
            'items'                         => get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'item', true ),
            'total'                         => \Workforce\Type\InvoiceType::get_invoice_total( $id ),
        ] );

        $mpdf = new Mpdf();
        $mpdf->WriteHTML( $invoice );

        return $mpdf;
    }

	/**
	 * @Filter(name="workforce_invoice_title")
	 */
	public static function format_title( $id ) {
		$number = get_the_title( $id );

		if ( empty( $number ) ) {
			return 'UNDEFINED';
		}

		return '#' . date( 'Y', get_post_time( 'U', false, $id ) ) . str_pad( $number, 5, '0', STR_PAD_LEFT );
	}

	/**
	 * @Filter(name="workforce_before_save", priority=10, accepted_args=2)
	 */
	public static function generate_title( $values, $post_type ) {
		if ( 'invoice' === $post_type ) {
			$title = get_the_title( $values['object_id'] );

			if ( empty( $title ) ) {
				$values['post_title'] = InvoiceType::get_next_invoice_number();
			}
		}

		return $values;
	}

    /**
     * @Action(name="init")
     */
    public static function send() {
        if ( empty( $_GET['send-invoice'] ) ) {
            return;
        }

        if ( ! current_user_can( 'workforce_invoice' ) ) {
            MessageHelper::add( esc_html__( 'You are not allowed to send invoice.', 'workforce' ), MessageHelper::STATUS_DANGER );
            wp_redirect( wp_get_referer() );
            exit();
        }

        $id = $_GET['send-invoice'];
        $mpdf = self::get_invoice_template( $id );

        $upload_dir = wp_upload_dir();
        $filename = $upload_dir['path'] . '/invoice-' . $id . '.pdf';
        $mpdf->Output( $filename, 'F' );
        $company_id = get_post_meta( $id, WORKFORCE_INVOICE_PREFIX . 'company_id', true );

        $emails = get_post_meta( $company_id, WORKFORCE_COMPANY_PREFIX . 'email', true );
        $email = array_shift( $emails );
        $subject = sprintf( '[%s] %s', get_bloginfo( 'name' ), esc_html__( 'Invoice', 'workforce' ) );
        $message = esc_html__( 'Invoice', 'workforce' );
        $headers = 'Content-Type: text/html; charset=UTF-8';

        $attachments = [];
        $attachments[] = $filename;

        $result = wp_mail( $email, $subject, $message, $headers, $attachments );
        wp_delete_file( $filename );

        if ( $result ) {
            MessageHelper::add( sprintf( esc_html__( 'Invoice has been successfully sent to %s.', 'workforce' ), $email ), MessageHelper::STATUS_SUCCESS );
            wp_redirect( wp_get_referer() );
            exit();
        }

        MessageHelper::add( esc_html__( 'An error occurred when sending an e-mail.', 'workforce' ), MessageHelper::STATUS_DANGER );
        wp_redirect( wp_get_referer() );
        exit();
    }

	/**
	 * @Action(name="init")
	 */
	public static function download() {
		if ( empty( $_GET['download-invoice'] ) ) {
			return;
		}

		$user = wp_get_current_user();

		if ( ! is_user_logged_in() ) {
			UserController::redirect_not_allowed();
		}

		if ( ! in_array( 'administrator', (array) $user->roles ) && in_array( 'employee', (array) $user->roles ) && in_array( 'client', (array) $user->roles ) ) {
			UserController::redirect_not_allowed();
		}

		if ( in_array( 'client', (array) $user->roles ) ) {
			$company_id = get_user_meta( $user->ID, WORKFORCE_USER_PREFIX . 'company_id', true );
			$invoice_company_id = get_post_meta( $_GET['download-invoice'], WORKFORCE_INVOICE_PREFIX . 'company_id', true );

			if ( $company_id != $invoice_company_id ) {
				UserController::redirect_not_allowed();
			}
		}

        if ( ! current_user_can( 'workforce_invoice' ) ) {
            MessageHelper::add( esc_html__( 'You are not allowed to download invoice.', 'workforce' ), MessageHelper::STATUS_DANGER );
            wp_redirect( wp_get_referer() );
            exit();
        }

		$id = $_GET['download-invoice'];
        $mpdf = self::get_invoice_template( $id );

		$mpdf->Output( 'invoice-' . $id . '.pdf', 'D' );
		exit();
	}
}
