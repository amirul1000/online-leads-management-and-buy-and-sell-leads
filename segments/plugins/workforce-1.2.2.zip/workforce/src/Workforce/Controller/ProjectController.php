<?php

namespace Workforce\Controller;

use Workforce\Annotation\Action;
use Workforce\Helper\MessageHelper;
use Workforce\Type\InvoiceType;
use Workforce\Type\ProjectType;
use Workforce\Type\TaskType;

use WP_Query;

class ProjectController {
	/**
	 * @Action(name="wp")
	 */
	public static function convert_to_invoice() {
		if ( ! empty( $_GET['create-invoice-from-project'] ) ) {
			$user = wp_get_current_user();

			if ( ! is_user_logged_in() ) {
				UserController::redirect_not_allowed();
			}

			if ( ! in_array( 'administrator', (array) $user->roles ) && in_array( 'employee', (array) $user->roles ) && in_array( 'client', (array) $user->roles ) ) {
				UserController::redirect_not_allowed();
			}

			$project_id = $_GET['create-invoice-from-project'];

			if ( 'project' !== get_post_type( $project_id ) ) {
				MessageHelper::add( esc_html__( 'This is not project ID.', 'workforce' ), MessageHelper::STATUS_DANGER );
				return;
			}

			$billing_type = get_post_meta( $project_id, WORKFORCE_PROJECT_PREFIX . 'billing_type', true );

			if ( empty( $billing_type ) ) {
				MessageHelper::add( esc_html__( 'Billing type for project is not defined.', 'workforce' ), MessageHelper::STATUS_DANGER );
				return;
			}

			// Prepare information for the invoice
			$currency_code = get_post_meta( $project_id, WORKFORCE_PROJECT_PREFIX . 'currency_code', true );
			$payment_term = get_theme_mod( 'workforce_invoices_payment_term', null );

			$company_id = get_post_meta( $project_id, WORKFORCE_PROJECT_PREFIX . 'company_id', true );
			$company_name = get_post_meta( $company_id, WORKFORCE_COMPANY_PREFIX . 'billing_name', true );
			$company_vat_number = get_post_meta( $company_id, WORKFORCE_COMPANY_PREFIX . 'billing_vat_number', true );
			$company_registration_number = get_post_meta( $company_id, WORKFORCE_COMPANY_PREFIX . 'billing_registration_number', true );

			if ( empty( $company_name ) || empty( $company_vat_number ) || empty( $company_registration_number ) || empty( $payment_term ) ) {
				MessageHelper::add( esc_html__( 'Billing information for company are missing.', 'workforce' ), MessageHelper::STATUS_DANGER );
				return;
			}

			$tasks = new WP_Query( [
				'post_type'			=> 'task',
				'posts_per_page' 	=> -1,
				'post_status'		=> 'publish',
				'meta_query'		=> [
					[
						'key'		=> WORKFORCE_TASK_PREFIX . 'project_id',
						'value'		=> $project_id,
						'compare'	=> '=',
						'type'		=> 'NUMERIC',
					],
					[
						'key'		=> WORKFORCE_TASK_PREFIX . 'status',
						'value'		=> TaskType::TASK_STATUS_RESOLVED,
					],
				],
			] );

			// No completed tasks for horuly project
			if ( empty( $tasks->posts ) && $billing_type === ProjectType::PROJECT_BILLING_HOURS ) {
				MessageHelper::add( esc_html__( 'Can not create invoice. This is hourly project without any completed tasks.', 'workforce' ), MessageHelper::STATUS_DANGER );
				return;
			}

			// No time trackings found
			if ( ! empty( $tasks->posts ) && $billing_type === ProjectType::PROJECT_BILLING_HOURS ) {
				$has_times = false;

				foreach ( $tasks->posts as $task ) {
					$items = get_post_meta( $task->ID, WORKFORCE_TASK_PREFIX . 'item', true );

					if ( ! empty( $items ) ) {
						foreach ( $items as $item ) {
							if ( is_array( $item ) && count( $item ) > 0 ) {
								if ( ! empty( $item[ WORKFORCE_TASK_PREFIX . 'item_title' ] ) && ! empty( $item[ WORKFORCE_TASK_PREFIX . 'item_quantity' ] ) ) {
									$has_times = true;
								}
							}
						}
					}
				}

				if ( ! $has_times ) {
					MessageHelper::add( esc_html__( 'Can not create invoice. This is hourly project without any time logs.', 'workforce' ), MessageHelper::STATUS_DANGER );
					return;
				}
			}

			$data = [
				'post_title'    => InvoiceType::get_next_invoice_number(),
				'post_author'   => get_current_user_id(),
				'post_status'   => 'publish',
				'post_type'     => 'invoice',
			];

			// Save new invoice
			$invoice_id = wp_insert_post( $data );

			// Save company information
			update_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'currency_code', $currency_code );
			update_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'status', InvoiceType::INVOICE_STATUS_PENDING );
			update_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'payment_term', $payment_term );
			update_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'company_id', $company_id );

			update_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'supplier_name', get_theme_mod( 'workforce_invoices_billing_name', null ) );
			update_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'supplier_registration_number', get_theme_mod( 'workforce_invoices_billing_registration_number', null ) );
			update_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'supplier_vat_number', get_theme_mod( 'workforce_invoices_billing_vat_number', null ) );
			update_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'supplier_details', get_theme_mod( 'workforce_invoices_billing_details', null ) );

			update_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'customer_name', $company_name );
			update_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'customer_registration_number', $company_registration_number );
			update_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'customer_vat_number', $company_vat_number );

			if ( $billing_type === ProjectType::PROJECT_BILLING_FIXED ) {
				update_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'item', [
					[
						WORKFORCE_INVOICE_PREFIX . 'item_title' 		=> get_the_title( $project_id ),
						WORKFORCE_INVOICE_PREFIX . 'item_quantity' 	=> 1,
						WORKFORCE_INVOICE_PREFIX . 'item_unit_price' 	=> get_post_meta( $project_id, WORKFORCE_PROJECT_PREFIX . 'price', true ),
						WORKFORCE_INVOICE_PREFIX . 'item_tax_rate'		=> get_theme_mod( 'workforce_invoices_tax_rate', null ),
					],
				] );
			} elseif ( $billing_type === ProjectType::PROJECT_BILLING_HOURS ) {
				$result = [];

				if ( ! empty( $tasks->posts ) ) {
					foreach ( $tasks->posts as $task ) {
						$items = get_post_meta( $task->ID, WORKFORCE_TASK_PREFIX . 'item', true );

						if ( ! empty( $items ) ) {
							foreach ( $items as $item ) {
								if ( ! empty( $item[ WORKFORCE_TASK_PREFIX . 'item_title' ] ) && ! empty( $item[ WORKFORCE_TASK_PREFIX . 'item_quantity' ] ) ) {
									$result[] = [
										WORKFORCE_INVOICE_PREFIX . 'item_title' 		=> $item[ WORKFORCE_TASK_PREFIX . 'item_title' ],
										WORKFORCE_INVOICE_PREFIX . 'item_quantity' 	=> $item[ WORKFORCE_TASK_PREFIX . 'item_quantity' ],
										WORKFORCE_INVOICE_PREFIX . 'item_unit_price' 	=> get_post_meta( $project_id, WORKFORCE_PROJECT_PREFIX . 'price', true ),
										WORKFORCE_INVOICE_PREFIX . 'item_tax_rate'		=> get_theme_mod( 'workforce_invoices_tax_rate', null ),
									];
								}
							}
						}
					}

					update_post_meta( $invoice_id, WORKFORCE_INVOICE_PREFIX . 'item', $result );
				}
			}

			MessageHelper::add( esc_html__( 'Invoice has been successfully created from project.', 'workforce' ), MessageHelper::STATUS_SUCCESS );
			wp_redirect( get_post_type_archive_link( 'invoice' ) );
			exit();
		}
	}
}
