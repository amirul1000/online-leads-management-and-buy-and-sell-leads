<?php
namespace Workforce\Controller;

use Workforce\Type\InvoiceType;
use WP_Query;

class StatsController {
	public static function get_years() {
		$years = [ date( 'Y' ) ];

		$query = new WP_Query( [
			'post_type'			=> [ 'expense', 'invoice' ],
			'post_status'		=> 'publish',
			'posts_per_page'	=> -1,
		] );

		foreach ( $query->posts as $post ) {
			if ( 'expense' === $post->post_type ) {
				$date = get_post_meta( $post->ID, WORKFORCE_EXPENSE_PREFIX . 'date', true );
				$year = date( 'Y', $date );
			} else {
				$year = date( 'Y', strtotime( $post->post_date ) );
			}

			if ( ! in_array( $year, $years ) ) {
				$years[] = $year;
			}
		}

		sort( $years );
		return $years;
	}

	public static function get_series( $year ) {
		$expenses = self::get_expenses( $year );
		$earnings = self::get_earnings( $year );

		return '[' . $earnings . ', ' . $expenses . ']';
	}

	public static function get_earnings( $year ) {
		if ( ! current_user_can( 'workforce_invoice' ) ) {
			return '[]';
		}

		$earnings = '';

		for ( $i = 1; $i <= 12; $i++ ) {
			$total = 0;
			$days = cal_days_in_month( CAL_GREGORIAN, $i, $year );

			$query = new WP_Query( [
				'post_type' 		=> 'invoice',
				'posts_per_page' 	=> -1,
				'post_status'		=> 'publish',
				'meta_query'		=> [
					[
						'key'		=> WORKFORCE_INVOICE_PREFIX . 'status',
						'value'		=> InvoiceType::INVOICE_STATUS_PAID,
						'compare' 	=> '=',
					],
					[
						'key'		=> WORKFORCE_INVOICE_PREFIX . 'date',
						'value'		=> mktime( 0, 0, 0, $i, 1, $year ),
						'compare' 	=> '>=',
						'type'		=> 'NUMERIC',
					],
					[
						'key'		=> WORKFORCE_INVOICE_PREFIX . 'date',
						'value'		=> mktime( 23, 59, 0, $i, $days, $year ),
						'compare' 	=> '<=',
						'type'		=> 'NUMERIC',
					],
				],
			] );

			foreach ( $query->posts as $invoice ) {
				$total += InvoiceType::get_invoice_total( $invoice->ID );
			}

			$earnings .= $total;

			if ( 12 != $i ) {
				$earnings .= ',';
			}
		}

		return '[' . $earnings . ']';
	}

	public static function get_expenses( $year ) {
		if ( ! current_user_can( 'workforce_expense' ) ) {
			return '[]';
		}

		$expenses = '';

		for ( $i = 1; $i <= 12; $i++ ) {
			$total = 0;
			$days = cal_days_in_month( CAL_GREGORIAN, $i, $year );

			$query = new WP_Query( [
				'post_type' 		=> 'expense',
				'posts_per_page' 	=> -1,
				'post_status'		=> 'publish',
				'meta_query'		=> [
					[
						'key'		=> WORKFORCE_EXPENSE_PREFIX . 'date',
						'value'		=> mktime( 0, 0, 0, $i, 1, $year ),
						'compare' 	=> '>=',
						'type'		=> 'NUMERIC',
					],
					[
						'key'		=> WORKFORCE_EXPENSE_PREFIX . 'date',
						'value'		=> mktime( 23, 59, 0, $i, $days, $year ),
						'compare' 	=> '<=',
						'type'		=> 'NUMERIC',
					],
				],
			] );

			foreach ( $query->posts as $expense ) {
				$total += get_post_meta( $expense->ID, WORKFORCE_EXPENSE_PREFIX . 'price', true );
			}

			$expenses .= $total;

			if ( 12 != $i ) {
				$expenses .= ',';
			}
		}

		return '[' . $expenses . ']';
	}
}
