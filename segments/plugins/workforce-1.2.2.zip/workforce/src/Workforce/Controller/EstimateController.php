<?php

namespace Workforce\Controller;

use mPDF;

use Workforce\Annotation\Action;
use Workforce\Helper\TemplateHelper;
use Workforce\Helper\MessageHelper;

class EstimateController {
    public static function get_estimate_template( $id ) {
        $company_id = get_post_meta( $id, WORKFORCE_ESTIMATE_PREFIX . 'company_id', true );

        $estimate = TemplateHelper::load( 'helpers/estimate', [
            'id'                            => $id,
            'currency_code'                 => get_post_meta( $id, WORKFORCE_ESTIMATE_PREFIX . 'currency_code', true ),
            'items'                         => get_post_meta( $id, WORKFORCE_ESTIMATE_PREFIX . 'item', true ),
            'total'                         => \Workforce\Type\EstimateType::get_total( $id ),
            'supplier_name'                 => get_theme_mod( 'workforce_invoices_billing_name', null ),
            'supplier_registration_number'  => get_theme_mod( 'workforce_invoices_billing_registration_number', null ),
            'supplier_vat_number'           => get_theme_mod( 'workforce_invoices_billing_vat_number', null ),
            'customer_name'                 => get_post_meta( $company_id, WORKFORCE_COMPANY_PREFIX . 'billing_name', true ),
            'customer_registration_number'  => get_post_meta( $company_id, WORKFORCE_COMPANY_PREFIX . 'billing_registration_number', true ),
            'customer_vat_number'           => get_post_meta( $company_id, WORKFORCE_COMPANY_PREFIX . 'billing_vat_number', true ),
        ] );

        $mpdf = new Mpdf();
        $mpdf->WriteHTML( $estimate );

        return $mpdf;
    }

    /**
     * @Action(name="init")
     */
    public static function send() {
        if ( empty( $_GET['send-estimate'] ) ) {
            return;
        }

        if ( ! current_user_can( 'workforce_estimate' ) ) {
            MessageHelper::add( esc_html__( 'You are not allowed to send estimate.', 'workforce' ), MessageHelper::STATUS_DANGER );
            wp_redirect( wp_get_referer() );
            exit();
        }

        $id = $_GET['send-estimate'];
        $mpdf = self::get_estimate_template( $id );

        $upload_dir = wp_upload_dir();
        $filename = $upload_dir['path'] . '/estimate-' . $id . '.pdf';
        $mpdf->Output( $filename, 'F' );
        $company_id = get_post_meta( $id, WORKFORCE_ESTIMATE_PREFIX . 'company_id', true );

        $emails = get_post_meta( $company_id, WORKFORCE_COMPANY_PREFIX . 'email', true );
        $email = array_shift( $emails );
        $subject = sprintf( '[%s] %s', get_bloginfo( 'name' ), esc_html__( 'Estimate', 'workforce' ) );
        $message = esc_html__( 'Estimate', 'workforce' );
        $headers = 'Content-Type: text/html; charset=UTF-8';

        $attachments = [];
        $attachments[] = $filename;

        $result = wp_mail( $email, $subject, $message, $headers, $attachments );
        wp_delete_file( $filename );

        if ( $result ) {
            MessageHelper::add( sprintf( esc_html__( 'Estimate has been successfully sent to %s.', 'workforce' ), $email ), MessageHelper::STATUS_SUCCESS );
            wp_redirect( wp_get_referer() );
            exit();
        }

        MessageHelper::add( esc_html__( 'An error occurred when sending an e-mail.', 'workforce' ), MessageHelper::STATUS_DANGER );
        wp_redirect( wp_get_referer() );
        exit();
    }

	/**
	 * @Action(name="init")
	 */
	public static function download() {
		if ( empty( $_GET['download-estimate'] ) ) {
			return;
		}

        if ( ! current_user_can( 'workforce_estimate' ) ) {
            MessageHelper::add( esc_html__( 'You are not allowed to download estimate.', 'workforce' ), MessageHelper::STATUS_DANGER );
            wp_redirect( wp_get_referer() );
            exit();
        }

        $mpdf = self::get_estimate_template( $_GET['download-estimate'] );
		$mpdf->Output( 'estimate-' . $_GET['download-estimate'] . '.pdf', 'D' );
	}
}
