<?php

namespace Workforce\Controller;

use Workforce\Annotation\Action;
use Workforce\Type\TaskType;
use Workforce\Type\TouchpointType;

use WP_Query;

class NotificationController {
	/**
	 * @Action(name="wp_ajax_workforce_send_notifications")
	 * @Action(name="wp_ajax_nopriv_workforce_send_notifications")
	 */
	public static function check() {
		$allow = get_theme_mod( 'workforce_notifications_allow', false );

		if ( empty( $allow ) ) {
			return;
		}

		self::check_touchpoints();
		self::check_tasks();
	}

	public static function check_touchpoints() {
		$query = new WP_Query( [
			'post_type' 	=> [ 'touchpoint' ],
			'post_status' 	=> 'publish',
			'post_per_page'	=> -1,
			'meta_query'	=> [
				'key'		=> WORKFORCE_TOUCHPOINT_PREFIX . 'date_start',
				'value'		=> time() + ( get_option( 'gmt_offset' ) * 60 * 60 ),
				'compare'	=> '>=',
			],
		] );

		$seconds = get_theme_mod( 'workforce_notifications_minutes', 60 ) * 60;

		foreach ( $query->posts as $post ) {
			$repeatable = get_post_meta( $post->ID, WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable', true );
			$now = time() + ( get_option( 'gmt_offset' ) * 60 * 60 );

			if ( ! empty( $repeatable ) ) {
				$weekdays = get_post_meta( $post->ID, WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable_weekdays', true );
				$time = get_post_meta( $post->ID, WORKFORCE_TOUCHPOINT_PREFIX . 'repeatable_time', true );
				$time = explode( ':', $time );
				$notification_sent = self::notification_sent( $post->ID, true, $time );

				if ( ! empty( $weekdays ) ) {
					foreach ( $weekdays as $weekday ) {
						if ( $weekday != date( 'w' ) ) {
							continue;
						}

						$event_start = mktime( $time[0], $time[1], 0, date( 'm' ), date( 'd' ), date( 'Y' ) );
						if ( ( $event_start - $seconds <= $now ) && ( $now <= $event_start ) && ! $notification_sent ) {
							$user_id = get_post_meta( $post->ID, WORKFORCE_TOUCHPOINT_PREFIX . 'user_id', true );
							self::send_notification( $post->ID, 'touchpoint', $user_id, $event_start );
						}
					}
				}
			} else {
				$event_start = get_post_meta( $post->ID, WORKFORCE_TOUCHPOINT_PREFIX . 'date_start', true );
				$notification_sent = self::notification_sent( $post->ID );

				if ( ( $event_start - $seconds <= $now ) && ( $now <= $event_start ) && ! $notification_sent ) {
					$user_id = get_post_meta( $post->ID, WORKFORCE_TOUCHPOINT_PREFIX . 'date_start', true );
					self::send_notification( $post->ID, 'touchpoint', $user_id, $event_start );
				}
			}
		}
	}

	public static function check_tasks() {
		$query = new WP_Query( [
			'post_type' 	=> [ 'task' ],
			'post_status' 	=> 'publish',
			'post_per_page'	=> -1,
			'meta_query'	=> [
				'key'		=> WORKFORCE_TASK_PREFIX . 'status',
				'value'		=> TaskType::TASK_STATUS_OPEN,
				'compare'	=> '=',
			],
		] );

		$seconds = get_theme_mod( 'workforce_notifications_minutes', 60 ) * 60;

		foreach ( $query->posts as $post ) {
			$repeatable = get_post_meta( $post->ID, WORKFORCE_TASK_PREFIX . 'repeatable', true );
			$now = time() + ( get_option( 'gmt_offset' ) * 60 * 60 );

			if ( ! empty( $repeatable ) ) {
				$weekdays = get_post_meta( $post->ID, WORKFORCE_TASK_PREFIX . 'repeatable_weekdays', true );
				$time = get_post_meta( $post->ID, WORKFORCE_TASK_PREFIX . 'repeatable_time', true );
				$time = explode( ':', $time );
				$notification_sent = self::notification_sent( $post->ID, true, $time );

				if ( ! empty( $weekdays ) ) {
					foreach ( $weekdays as $weekday ) {
						if ( $weekday != date( 'w' ) ) {
							continue;
						}

						$event_start = mktime( $time[0], $time[1], 0, date( 'm' ), date( 'd' ), date( 'Y' ) );
						if ( ( $event_start - $seconds <= $now ) && ( $now <= $event_start ) && ! $notification_sent ) {
							$user_id = get_post_meta( $post->ID, WORKFORCE_TASK_PREFIX . 'user_id', true );
							self::send_notification( $post->ID, 'task', $user_id, $event_start );
						}
					}
				}
			} else {
				$event_start = get_post_meta( $post->ID, WORKFORCE_TASK_PREFIX . 'due', true );
				$notification_sent = self::notification_sent( $post->ID );

				if ( ( $event_start - $seconds <= $now ) && ( $now <= $event_start ) && ! $notification_sent ) {
					$user_id = get_post_meta( $post->ID, WORKFORCE_TASK_PREFIX . 'user_id', true );
					self::send_notification( $post->ID, 'task', $user_id, $event_start );
				}
			}
		}
	}

	public static function send_notification( $post_id, $post_type, $user_id, $start ) {
		$email = get_user_meta( $user_id, WORKFORCE_USER_PREFIX . 'general_email', true );
		$subject = sprintf( '[%s %s] %s', get_bloginfo( 'name' ), esc_html__( 'Notification', 'workforce' ), get_the_title( $post_id ) );
		$message = \Workforce\Helper\TemplateHelper::load( 'notifications/' . $post_type, [
			'post_id' 	=> $post_id,
			'user_id' 	=> $user_id,
			'start'		=> $start,
		] );
		$headers = [ 'Content-Type: text/html; charset=UTF-8' ];
		$result = wp_mail( $email, $subject, $message, $headers );

		$notifications = get_option( 'workforce_notifications', [] );
		$notifications[ $post_id ] = $now = time() + ( get_option( 'gmt_offset' ) * 60 * 60 );
		update_option( 'workforce_notifications', $notifications );
	}

	public static function notification_sent( $post_id, $repeatable = false, $time = null ) {
		$notifications = get_option( 'workforce_notifications', [] );
		$seconds = get_theme_mod( 'workforce_notifications_minutes', 60 ) * 60;

		if ( empty( $notifications[ $post_id ] ) ) {
			return false;
		}

		if ( ! $repeatable && ! empty( $notification[ $post_id  ] ) ) {
			return true;
		}

		if ( $repeatable ) {
			$event_start = $event_start = mktime( $time[0], $time[1], 0, date( 'm' ), date( 'd' ), date( 'Y' ) );

			if ( $event_start - $seconds <= $notifications[ $post_id ] && $notifications[ $post_id ] <= $event_start ) {
				return true;
			}
		}

		return true;
	}
}
