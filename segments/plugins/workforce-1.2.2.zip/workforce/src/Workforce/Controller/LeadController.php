<?php

namespace Workforce\Controller;

use Workforce\Annotation\Action;
use Workforce\Helper\MessageHelper;

class LeadController {
	/**
	 * @Action(name="wp")
	 */	
	public static function convert() {
		if ( ! empty( $_GET['convert-lead'] ) ) {
			$user = wp_get_current_user();

			if ( ! is_user_logged_in() ) {
				UserController::redirect_not_allowed();
			}

			if ( ! in_array( 'administrator', (array) $user->roles ) && in_array( 'employee', (array) $user->roles ) && in_array( 'client', (array) $user->roles ) ) {
				UserController::redirect_not_allowed();
			}

			$lead_id = $_GET['convert-lead'];						
			$lead = get_post( $lead_id );

			if ( empty( $lead ) ) {
				MessageHelper::add( esc_html__( 'Object does not exists.', 'workforce' ), MessageHelper::STATUS_DANGER );
				return;
			}

			if ( 'lead' !== get_post_type( $lead_id ) ) {
				MessageHelper::add( esc_html__( 'This is not lead ID.', 'workforce' ), MessageHelper::STATUS_DANGER );
				return;
			}			

			$data = [
				'post_title'    => $lead->post_title,
				'post_author'   => get_current_user_id(),
				'post_status'   => 'publish',
				'post_type'     => 'customer',
			];

			// Save new invoice
			$customer_id = wp_insert_post( $data );			

			update_post_meta( $customer_id, WORKFORCE_CUSTOMER_PREFIX . 'lead_id', $lead_id );

			update_post_meta( $customer_id, WORKFORCE_CUSTOMER_PREFIX . 'company', get_post_meta( $lead_id, WORKFORCE_LEAD_PREFIX . 'company', true ) );
			update_post_meta( $customer_id, WORKFORCE_CUSTOMER_PREFIX . 'email', get_post_meta( $lead_id, WORKFORCE_LEAD_PREFIX . 'email', true ));
			update_post_meta( $customer_id, WORKFORCE_CUSTOMER_PREFIX . 'phone', get_post_meta( $lead_id, WORKFORCE_LEAD_PREFIX . 'phone', true ) );
			update_post_meta( $customer_id, WORKFORCE_CUSTOMER_PREFIX . 'about', get_post_meta( $lead_id, WORKFORCE_LEAD_PREFIX . 'about', true ) );
			update_post_meta( $customer_id, WORKFORCE_CUSTOMER_PREFIX . 'custom_field', get_post_meta( $lead_id, WORKFORCE_LEAD_PREFIX . 'custom_field', true ) );						
			MessageHelper::add( esc_html__( 'Customer has been successfully created from lead.', 'workforce' ), MessageHelper::STATUS_SUCCESS );
			wp_redirect( get_post_type_archive_link( 'customer' ) );
			exit();			
		}
	}

	/**
	 * @Action(name="init")
	 */
	public static function capture_form() {
		if ( empty( $_POST['lead-form'] ) ) {
			return;
		}

		$lead_form = get_post( $_POST['lead-form'] );

		if ( empty( $lead_form ) ) {
			return;
		}
		
		$post_title = sprintf( esc_html__( 'Lead Captured by %s', 'workforce' ), $lead_form->post_title );

        $data = [
            'post_title'    => $post_title,            
            'post_author'   => 0,
            'post_status'   => 'publish',
            'post_type'     => 'lead',
        ];

		$post_id = wp_insert_post( $data );		

		$fields = [];
		foreach ( $_POST as $key => $value ) {
			$fields[] = [ 'key' => $key, 'value' => $value ];			
		}		

		update_post_meta( $post_id, 'post_title', $post_title );
		update_post_meta( $post_id, WORKFORCE_LEAD_PREFIX . 'capture_form_id', $lead_form->ID );		
		update_post_meta( $post_id, WORKFORCE_LEAD_PREFIX . 'custom_field', $fields );		

		if ( wp_get_referer() ) {
		    wp_safe_redirect( wp_get_referer() );
		} else {
		    wp_safe_redirect( get_home_url() );
		}		

		exit();
	}
}