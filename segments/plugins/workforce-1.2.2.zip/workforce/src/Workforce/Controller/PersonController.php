<?php

namespace Workforce\Controller;

use Workforce\Annotation\Action;
use Workforce\Annotation\Filter;

class PersonController {
	/**
	 * @Filter(name="workforce_before_save", priority=10, accepted_args=2)
	 */
	public static function generate_title( $values, $post_type ) {
		if ( 'person' === $post_type ) {
			$values['post_title'] = sprintf( '%s, %s', $values[ WORKFORCE_PERSON_PREFIX . 'last_name' ], $values[ WORKFORCE_PERSON_PREFIX . 'first_name' ] );
		}

		return $values;
	}
}
