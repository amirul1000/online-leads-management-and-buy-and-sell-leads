<p>
	<strong>
		<a href="<?php echo \Workforce\Helper\CrudHelper::get_action_uri( 'task', \Workforce\Helper\CrudHelper::ACTION_UPDATE, $post_id ); ?>">
			<?php echo get_the_title( $post_id ); ?>			
		</a>
	</strong>
</p>

<table>	
	<?php if ( ! empty( $start ) ) : ?>
		<tr>
			<th><?php echo esc_html__( 'When', 'workforce' ); ?></th>
			<td><?php echo date( get_option( 'date_format' ), $start ); ?> <?php echo date( get_option( 'time_format' ), $start ); ?></td>
		</tr>
	<?php endif; ?>

	<?php $username = Workforce\Type\UserType::get_name( $user_id, false ); ?>
	<?php if ( ! empty( $username ) ) : ?>
		<tr>
			<th><?php echo esc_html__( 'Who', 'workforce' ); ?></th>
			<td><?php echo esc_html( $username ); ?></td>
		</tr>
	<?php endif; ?>

	<?php $post = get_post( $post_id ); ?>		
	<?php if ( ! empty( $post->post_content ) ) : ?>
		<tr>
			<th><?php echo esc_html__( 'Description', 'workforce' ); ?></th>
			<td><?php echo wp_kses( $post->post_content, wp_kses_allowed_html( 'post' ) ); ?></td>
		</tr>
	<?php endif; ?>
</table>
