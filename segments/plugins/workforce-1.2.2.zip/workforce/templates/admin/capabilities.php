<div class="wrap">
	<h2><?php echo esc_html__( 'Capabilities', 'workforce' ); ?></h2>
		
	<form id="workforce-capabilities-form" 
		  action="<?php echo admin_url( 'users.php?page=user-permissions' ); ?>" 
		  method="post">
		<input type="hidden" name="action" value="workforce-capabilities" >

		<?php wp_nonce_field( 'workforce-capabilities' ); ?>

		<table class="wp-list-table widefat posts">
			<thead>
				<tr>
					<th><?php echo esc_html__( 'Username', 'workforce' ); ?></th>
					<th><?php echo esc_html__( 'Full name', 'workforce' ); ?></th>
					<th><?php echo esc_html__( 'Capabilities', 'workforce' ); ?></th>
				</tr>
			</thead>

			<tfoot>
				<tr>
					<th><?php echo esc_html__( 'Username', 'workforce' ); ?></th>
					<th><?php echo esc_html__( 'Full name', 'workforce' ); ?></th>
					<th><?php echo esc_html__( 'Capabilities', 'workforce' ); ?></th>
				</tr>
			</tfoot>

			<tbody>
				<?php $user_query = new WP_User_Query( [ 'role' => [], 'number' => -1 ] ); ?>

				<?php if ( ! empty( $user_query->results ) ) : ?>
					<?php $x = 1; ?>

					<?php foreach ( $user_query->results as $user ) : ?>
						<?php $user_role = $user->roles; ?>

						<tr class="<?php echo ( $x++ % 2 == 0 ) ? 'alternate': 'uneven'; ?>">
							<td><?php echo esc_html( $user->user_login ); ?></td>

							<td>
								<?php echo \Workforce\Type\UserType::get_name( $user->ID ); ?>								
							</td>

							<td>
								<?php foreach ( \Workforce\Bootstrap::capabilities() as $capability_key => $capability_value ) : ?>
									<div>
										<label>
											<input type="hidden" name="workforce_capabilities[<?php echo $user->ID; ?>][<?php echo esc_attr( $capability_key ); ?>]" value="0">
											<input 	name="workforce_capabilities[<?php echo $user->ID; ?>][<?php echo esc_attr( $capability_key ); ?>]" 
													id="<?php echo esc_attr( $capability_key ); ?>" 
													type="checkbox" value="1" 
													<?php checked( isset( $user->allcaps[ $capability_key ] ) ); ?>>

											<?php echo $capability_value; ?>
										</label>
									</div>
								<?php endforeach?>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td colspan="3"><?php echo esc_html__( 'No results found.', 'workforce' ); ?></td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>

		<p>
			<input type="submit" name="workforce-capabilities-submit" id="workforce-capabilities-submit" class="button-primary" value="<?php echo esc_html__( 'Save Capabilities', 'workforce' ); ?>"/>
		</p>
	</form>
</div><!-- /.wrap -->
