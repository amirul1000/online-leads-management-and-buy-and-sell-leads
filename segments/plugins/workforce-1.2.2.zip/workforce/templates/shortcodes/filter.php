<?php global $wp_query; ?>

<?php if ( ! empty( $filters[ $wp_query->query['post_type'] ] ) ) : ?>
	<?php $post_type = get_post_type_object( $wp_query->query['post_type'] ); ?>

	<div class="workforce-filter-wrapper">
		<div class="workforce-filter">
			<div class="workforce-filter-title">
				<h2><?php echo esc_html__( 'Filter', 'workforce' ); ?> <?php echo esc_attr( $post_type->labels->name ); ?></h2>

				<div class="workforce-filter-actions">
					<?php global $wp_query; ?>

					<?php $query = add_query_arg( 'export', 'csv', $_SERVER['REQUEST_URI'] ); ?>

					<a href="<?php echo esc_attr( $query ); ?>" class="workforce-filter-export-csv">
						<?php echo esc_html__( 'Export CSV', 'workforce' ); ?> <span>(<?php echo esc_html( $wp_query->found_posts ); ?>)</span>
					</a>

					<a href="<?php echo strtok( $_SERVER['REQUEST_URI'], '?' ); ?>" class="workforce-filter-reset" title="<?php echo esc_attr__( 'Reset filter', 'workforce' ); ?>">
						<?php echo esc_html__( 'Reset Filter', 'workforce' ); ?>
					</a>
				</div><!-- /.workforce-filter-actions -->
			</div><!-- /.workforce-filter-title -->

			<form method="get" class="workforce-filter-form">
				<input type="hidden" name="posttype" value="<?php echo $wp_query->query['post_type']; ?>">

				<?php if ( ! empty( $_GET['sort'] ) ) : ?>
					<input type="hidden" name="sort" value="<?php echo esc_attr( $_GET['sort'] ); ?>">
				<?php endif; ?>

				<?php if ( ! empty( $_GET['order'] ) ) : ?>
					<input type="hidden" name="order" value="<?php echo esc_attr( $_GET['order'] ); ?>">
				<?php endif; ?>

				<div class="workforce-filter-form-inner">
					<?php foreach ( $filters[ $wp_query->query['post_type'] ] as $field ) : ?>
						<?php echo Workforce\Helper\TemplateHelper::load( 'filters/' . $field['input_type'], $field );?>
					<?php endforeach; ?>

					<div class="form-group form-group-button">
						<button class="button">
							<?php echo esc_html__( 'Filter', 'workforce' ); ?> <?php echo esc_attr( $post_type->labels->name ); ?>
						</button>
					</div><!-- /.form-group -->
				</div><!-- /.workforce-filter-form-inner -->
			</form><!-- /.workforce-filter-form -->
		</div><!-- /.workforce-filter -->
	</div><!-- /.workforce-filter-wrapper -->
<?php endif; ?>
