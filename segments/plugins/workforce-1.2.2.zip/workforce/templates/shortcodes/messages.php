<?php if ( $messages ) : ?>
	<div class="alerts">
		<?php foreach ( $messages as $message ) : ?>
			<div class="alert alert-<?php echo esc_attr( strtolower( $message['status'] ) ); ?>">
				<?php echo wp_kses( $message['message'], wp_kses_allowed_html( 'post' ) ); ?>

				<span class="alert-close">x</span><!-- /.alert-close -->
			</div><!-- /.alert -->
		<?php endforeach; ?>
	</div><!-- /.alerts -->
<?php endif; ?>
