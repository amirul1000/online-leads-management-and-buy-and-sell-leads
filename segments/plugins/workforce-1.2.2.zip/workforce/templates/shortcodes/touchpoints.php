<?php
use Workforce\Helper\CrudHelper;
use Workforce\Type\TaskType;
?>

<div class="workforce-touchpoints-wrapper">
	<?php if ( ! empty( $show_create_button ) ) : ?>
		<a href="<?php echo CrudHelper::get_action_uri( 'touchpoint', CrudHelper::ACTION_CREATE ); ?>" class="btn workforce-touchpoints-create">
			<?php echo esc_html__( 'Create', 'workforce' ); ?>
		</a>
	<?php endif; ?>

	<?php if ( have_posts() ) : ?>
		<div class="workforce-touchpoints">
			<?php while ( have_posts() ) : the_post(); ?>
				<div class="workforce-touchpoint">
					<?php $start_date = get_post_meta( get_the_ID(), WORKFORCE_TOUCHPOINT_PREFIX . 'date_start', true ); ?>
					<?php if ( ! empty( $start_date ) ) : ?>
						<div class="workforce-touchpoint-date">
							<span class="day"><?php echo date( 'd', $start_date ); ?></span><!-- /.day -->
							<span class="month"><?php echo date( 'M', $start_date ); ?></span><!-- /.month -->
						</div><!-- /.workforce-touchpoint-date -->
					<?php endif; ?>

					<div class="workforce-touchpoint-content">
						<h3>
							<a href="<?php echo CrudHelper::get_action_uri( 'touchpoint', CrudHelper::ACTION_UPDATE, get_the_ID() ); ?>">
								<?php the_title(); ?>
							</a>
						</h3>

						<?php $company_id = get_post_meta( get_the_ID(), WORKFORCE_TOUCHPOINT_PREFIX . 'company_id', true ); ?>
						<?php $person_id = get_post_meta( get_the_ID(), WORKFORCE_TOUCHPOINT_PREFIX . 'person_id', true ); ?>
						<?php $types = wp_get_post_terms( get_the_ID(), 'touchpoint_type' ); ?>
						<?php $type = is_array( $types ) ? array_shift( $types ) : null; ?>
						
						<?php if ( ! empty( $company_id ) || ! empty( $person_id ) ) : ?>
							<div class="workforce-touchpoint-attributes">
								<?php if ( ! empty( $company_id ) ) : ?>
									<div class="workforce-touchpoint-company">
										<?php echo get_the_title( $company_id ); ?>
									</div><!-- /.workforce-touchpoint-company -->
								<?php endif; ?>

								<?php if ( ! empty( $person_id ) ) : ?>
									<?php if ( ! empty( $company_id ) ) : ?>
										-
									<?php endif; ?>

									<div class="workforce-touchpoint-person">
										<?php echo get_the_title( $person_id ); ?>
									</div><!-- /.workforce-touchpoint-person -->
								<?php endif; ?>

								<?php if ( ! empty( $type ) ) : ?>
									<div class="workforce-touchpoint-type">
										<?php echo esc_html( $type->name ); ?>
									</div><!-- /.workforce-touchpoint-type -->
								<?php endif; ?>
							</div><!-- /.workforce-touchpoint-attributes -->
						<?php endif; ?>
					</div><!-- /.workforce-touchpoint-content -->
				</div><!-- /.workforce-touchpoint -->
			<?php endwhile; ?>
		</div><!-- /.workforce-touchpoints -->

		<?php if ( ! empty( $show_all_button ) ) : ?>
			<div class="show-all">
				<a href="<?php echo get_post_type_archive_link( 'touchpoint' ); ?>">
					<?php echo esc_html__( 'Show all touchpoints', 'workforce' ); ?>
				</a>
			</div><!-- /.show-all -->
		<?php endif; ?>
	<?php else : ?>
		<p class="not-found">
			<?php echo esc_html__( 'No touchpoints found.', 'workforce' ); ?>
		</p><!-- /.not-found -->
	<?php endif; ?>
</div><!-- /.workforce-touchpoints-wrapper -->
