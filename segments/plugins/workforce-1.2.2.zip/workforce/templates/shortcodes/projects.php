<?php use Workforce\Helper\CrudHelper; ?>

<div class="workforce-projects-wrapper">
	<?php if ( ! empty( $show_create_button ) ) : ?>
	    <a href="<?php echo CrudHelper::get_action_uri( 'project', CrudHelper::ACTION_CREATE ); ?>" class="btn workforce-projects-create">
	        <?php echo esc_html__( 'Create', 'workforce' ); ?>
	    </a>
	<?php endif; ?>	    

	<?php if ( have_posts() ) : ?>	   
		<div class="workforce-projects"> 
			<?php while ( have_posts() ) : the_post() ?>		
				<div class="workforce-project">
					<h3>
						<a href="<?php echo CrudHelper::get_action_uri( 'project', CrudHelper::ACTION_UPDATE, get_the_ID() ); ?>">
							<?php the_title(); ?>				
						</a>
					</h3>		

			        <?php $progress = Workforce\Type\ProjectType::get_progress( get_the_ID() ); ?>
			        <?php if ( null === $progress ) : ?>
			        	<div class="wokforce-project-not-found">
			            	<?php echo esc_html( 'No tasks assigned to project.', 'workforce' ); ?>
			            </div><!-- /.wokforce-project-not-found -->
			        <?php else : ?>
						<?php $breakdown = Workforce\Type\ProjectType::get_progress_breakdown( get_the_ID() ); ?>

						<div class="progress-bar <?php if ( 0 === $progress ) : ?>progress-not-started<?php endif;?>">
							<span class="progress-bar-inner" style="width: <?php echo esc_attr( $progress ); ?>%">					
								<span class="progress-bar-breakdown"><?php echo esc_attr( $breakdown ); ?></span>
							</span>				
						</div><!-- /.progress-bar -->     
			        <?php endif; ?>				
				</div><!-- /.workforce-project -->
			<?php endwhile; ?>
		</div><!-- /.workforce-projects -->

		<?php if ( ! empty( $show_all_button ) ) : ?>
			<div class="show-all">
				<a href="<?php echo get_post_type_archive_link( 'project' ); ?>">
					<?php echo esc_html__( 'Show all projects', 'workforce' ); ?>
				</a>
			</div><!-- /.show-all -->
		<?php endif; ?>
	<?php else : ?>
		<p class="not-found">
			<?php echo esc_html__( 'No projects found.', 'workforce' ); ?>
		</p><!-- /.not-found -->	
	<?php endif; ?>
</div><!-- /.workforce-projects-wrapper -->
