<?php global $post; ?>

<?php if ( have_posts() ) : ?>
	<div class="workforce-activity">
		<?php while ( have_posts() ) : the_post(); ?>
			<div class="workforce-activity-item">
				<?php $labels = get_post_type_labels( get_post_type_object( get_post_type() ) ); ?>
				

				<?php $user_id = get_post_meta( $post->ID, '_edit_last', true ); ?>
				<?php $user_id = empty( $user_id ) ? $post->post_author : $user_id; ?>
				<?php echo Workforce\Helper\TemplateHelper::get_avatar( $user_id, WORKFORCE_USER_PREFIX . 'general_image', false, true ); ?>

				<div class="workforce-activity-content">
					<div class="workforce-activity-date"><?php the_modified_date(); ?> <?php the_modified_time()?></div>
					
					<div class="workforce-activity-message">			
						<a href="<?php echo Workforce\Helper\CrudHelper::get_action_uri( get_post_type(), Workforce\Helper\CrudHelper::ACTION_UPDATE, get_the_ID() ); ?>">
							<?php if ( 'invoice' === get_post_type() ) : ?>
								<?php echo apply_filters( 'workforce_invoice_title', get_the_ID() ); ?>
							<?php else : ?>
								<?php the_title(); ?>
							<?php endif; ?>					
						</a>

						<?php echo esc_html__( 'of type ', 'workforce' ); ?>
									
						<a href="<?php echo get_post_type_archive_link( get_post_type() ); ?>">
							<?php echo esc_html( $labels->singular_name ); ?>
						</a>

						<?php if ( $post->post_modified == $post->post_date ) : ?>
							<?php echo esc_html__( 'has been created.', 'workforce' ); ?>
						<?php else : ?>
							<?php echo esc_html__( 'has been modified.', 'workforce' ); ?>
						<?php endif; ?>				
					</div><!-- /.workforce-activity-message -->	
				</div><!-- /.workforce-activity-content -->
			</div><!-- /.workforce-activity-item -->
		<?php endwhile; ?>
	</div><!-- /.workforce-activity -->
<?php else : ?>
	<?php echo esc_html__( 'No results found.', 'workforce' ); ?>
<?php endif; ?>
