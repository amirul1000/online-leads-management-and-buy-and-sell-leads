<?php
use Workforce\Helper\CrudHelper;
use Workforce\Type\TaskType;
?>

<div class="workforce-tasks-wrapper">
	<?php if ( ! empty( $show_create_button ) ) : ?>
		<a href="<?php echo CrudHelper::get_action_uri( 'task', CrudHelper::ACTION_CREATE ); ?>" class="btn workforce-tasks-create">
			<?php echo esc_html__( 'Create', 'workforce' ); ?>
		</a>
	<?php endif; ?>
		
	<?php if ( have_posts() ) : ?>
		<div class="workforce-tasks">
			<?php while ( have_posts() ) : the_post(); ?>
				<div class="workforce-task">
					<?php $status = get_post_meta( get_the_ID(), WORKFORCE_TASK_PREFIX . 'status', true ); ?>

					<h3>
						<?php if ( ! empty( $status ) ) : ?>
							<span class="task-<?php echo strtolower( $status ); ?>"><?php echo TaskType::get_status_display_name( $status ); ?></span>
						<?php endif; ?>

						<a href="<?php echo CrudHelper::get_action_uri( 'task', CrudHelper::ACTION_UPDATE, get_the_ID() ); ?>">
							<?php the_title(); ?>
						</a>
					</h3>

					<?php $due = get_post_meta( get_the_ID(), WORKFORCE_TASK_PREFIX . 'due', true ); ?>
					<?php $user_id = get_post_meta( get_the_ID(), WORKFORCE_TASK_PREFIX . 'user_id', true ); ?>

					<?php if ( ! empty( $due ) || ! empty( $user_id ) ) : ?>
						<div class="workforce-task-content">
							<?php if ( ! empty( $due ) ) : ?>
								<?php $date = date( get_option( 'date_format' ), $due ); ?>
								<?php $time = str_replace( '00:00', '', date( get_option( 'time_format' ), $due ) ); ?>

								<div class="workforce-task-due">
									<?php echo esc_html( $date ); ?> <?php echo esc_html( $time ); ?>
								</div><!-- /.workforce-task-due -->
							<?php endif; ?>
							
							<?php if ( ! empty( $user_id ) ) : ?>
								<div class="workforce-task-user">
									<?php echo esc_html__( 'for', 'workforce' ); ?> <?php echo \Workforce\Type\UserType::get_name( $user_id ); ?>
								</div><!-- /.workforce-task-user -->
							<?php endif; ?>               
						</div><!-- /.workforce-task-content -->
					<?php endif; ?>
				</div><!-- /.workforce-task -->
			<?php endwhile; ?>
		</div><!-- /.workforce-tasks -->

		<?php if ( ! empty( $show_all_button ) ) : ?>
			<div class="show-all">
				<a href="<?php echo get_post_type_archive_link( 'task' ); ?>">
					<?php echo esc_html__( 'Show all tasks', 'workforce' ); ?>
				</a>
			</div><!-- /.show-all -->
		<?php endif; ?>
	<?php else : ?>
		<p class="not-found">
			<?php echo esc_html__( 'No tasks found.', 'workforce' ); ?>
		</p><!-- /.not-found -->
	<?php endif; ?>
</div><!-- /.workforce-tasks-wrapper -->
