<?php $years = Workforce\Controller\StatsController::get_years(); ?>
<?php $current_year = ! empty( $_GET['stats-money-year'] ) ? $_GET['stats-money-year'] : date( 'Y' ); ?>

<?php if ( ! empty( $years ) ) : ?>	
	<ul class="workforce-stats-money-years">
		<?php foreach ( $years as $year ) : ?>
			<li class="<?php if ( $current_year == $year ) : ?>current<?php endif?>">
				<a href="?stats-money-year=<?php echo esc_attr( $year ); ?>"><?php echo esc_html( $year ); ?></a>
			</li>
		<?php endforeach; ?>
	</ul>
<?php endif; ?>


<div id="workforce-stats-money-chart" 
	 data-series="<?php echo Workforce\Controller\StatsController::get_series( $year ); ?>">
</div>
