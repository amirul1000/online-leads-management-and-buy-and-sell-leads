<?php
use Workforce\Type\EstimateType;
use Workforce\Type\ExpenseType;
use Workforce\Type\InvoiceType;
use Workforce\Type\TaskType;
?>

<div class="overview-wrapper">
	<div class="overview">
		<?php if ( current_user_can( 'workforce_invoice' ) ) : ?>
			<div class="overview-item overview-invoices">
				<div class="overview-item-inner">
					<div class="overview-item-content">
						<h3><?php echo esc_html__( 'Invoices', 'workforce' ); ?></h3>

						<ul>
							<li>
								<strong><?php echo esc_html__( 'Processing' ); ?></strong>
								<span><?php echo count( InvoiceType::get_all( [ InvoiceType::INVOICE_STATUS_DRAFT, InvoiceType::INVOICE_STATUS_SENT, ] ) ); ?></span>
							</li>

							<li>
								<strong><?php echo esc_html__( 'Paid' ); ?></strong>
								<span><?php echo count( InvoiceType::get_all( InvoiceType::INVOICE_STATUS_PAID ) ); ?></span>
							</li>
						</ul>
					</div><!-- /.overview-item-content -->
				</div><!-- /.overview-item-inner -->
			</div><!-- /.overview-item -->
		<?php endif; ?>

		<?php if ( current_user_can( 'workforce_task' ) ) : ?>
			<div class="overview-item overview-tasks">
				<div class="overview-item-inner">
					<div class="overview-item-content">
						<h3><?php echo esc_html__( 'Tasks', 'workforce' ); ?></h3>
						
						<ul>
							<li>
								<strong><?php echo esc_html__( 'Processing', 'workforce' ); ?></strong>
								<span><?php echo count( TaskType::get_all( [ TaskType::TASK_STATUS_OPEN ] ) ); ?></span>
							</li>

							<li>
								<strong><?php echo esc_html__( 'Completed', 'workforce' ); ?></strong>
								<span><span><?php echo count( TaskType::get_all( [ TaskType::TASK_STATUS_RESOLVED ] ) ); ?></span></span>
							</li>
						</ul>
					</div><!-- /.overview-item-content -->
				</div><!-- /.overview-item-inner -->				
			</div><!-- /.overview-item -->	
		<?php endif; ?>	

		<?php if ( current_user_can( 'workforce_estimate' ) ) : ?>
			<div class="overview-item overview-estimates">
				<div class="overview-item-inner">
					<div class="overview-item-content">
						<h3><?php echo esc_html__( 'Estimates', 'workforce' ); ?></h3>
						
						<ul>
							<li><strong><?php echo esc_html__( 'Processing' ); ?></strong><span><?php echo count( EstimateType::get_all( [ EstimateType::ESTIMATE_STATUS_DRAFT, EstimateType::ESTIMATE_STATUS_SENT ] ) ); ?></span></li>
							<li><strong><?php echo esc_html__( 'Accepted' ); ?></strong><span><?php echo count( EstimateType::get_all( [ EstimateType::ESTIMATE_STATUS_ACCEPTED] ) ); ?></span></li>
						</ul>
					</div><!-- /.overview-item-content -->
				</div><!-- /.overview-item-inner -->				
			</div><!-- /.overview-item -->			
		<?php endif; ?>	

		<?php if ( current_user_can( 'workforce_expense' )  && current_user_can( 'workforce_invoice' ) ) : ?>
			<div class="overview-item overview-revenue">
				<div class="overview-item-inner">
					<div class="overview-item-content">
						<h3><?php echo esc_html__( 'Revenue', 'workforce' ); ?></h3>
						
						<ul>
							<li>
								<strong><?php echo esc_html__( 'Earnings', 'workforce' ); ?></strong>
								<span>
									<?php $earnings = InvoiceType::get_all_total(); ?>

									<?php foreach( $earnings as $earning ) : ?>		
										<?php echo Workforce\Helper\PriceHelper::format( $earning[ 'total' ], $earning[ 'currency_code' ] ); ?>		
									<?php endforeach; ?>
								</span>
							</li>

							<li>
								<strong><?php echo esc_html__( 'Expenses', 'workforce' ); ?></strong>
								<span>
									<?php $expenses = ExpenseType::get_all_total(); ?>

									<?php foreach( $expenses as $expense ) : ?>		
										<?php echo Workforce\Helper\PriceHelper::format( $expense[ 'total' ], $expense[ 'currency_code' ] ); ?>		
									<?php endforeach; ?>
								</span>
							</li>
						</ul>
					</div><!-- /.overview-item-content -->
				</div><!-- /.overview-item-inner -->								
			</div><!-- /.overview-item -->						
		<?php endif; ?>
	</div><!-- /.overview -->
</div><!-- .overview-wrapper -->