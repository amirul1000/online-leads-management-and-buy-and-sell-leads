<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo home_url( '/' ); ?>"><?php echo esc_html__( 'Home', 'workforce' ); ?></a>
	</li>

	<?php $dashboard = get_theme_mod( 'workforce_pages_dashboard', null ); ?>
	<?php if ( is_user_logged_in() && ! empty( $dashboard ) ) : ?>
		<li class="breadcrumb-item">
			<a href="<?php echo get_permalink( $dashboard ); ?>"><?php echo esc_html__( 'Dashboard', 'workforce' ); ?></a>
		</li>
	<?php endif; ?>

	<?php if ( is_archive() ) : ?>
		<li class="breadcrumb-item">
			<a href="<?php echo get_post_type_archive_link( get_post_type() ); ?>"><?php echo get_the_archive_title(); ?></a>
		</li>
	<?php endif; ?>

	<?php if ( is_404() ) : ?>
		<li class="breadcrumb-item">
			<?php echo esc_html__( 'Page not found', 'workforce' ); ?>            
		</li>
	<?php endif; ?>

	<?php if ( is_search() ) : ?>
		<li class="breadcrumb-item">
			<?php echo esc_html__( 'Search Results', 'workforce' ); ?>            
		</li>
	<?php endif; ?>

	<?php if ( is_single() ) : ?>
		<li class="breadcrumb-item">
			<?php $post_type_obj = get_post_type_object( get_post_type() ); ?>

			<a href="<?php echo get_post_type_archive_link( get_post_type() ); ?>">				
				<?php echo $post_type_obj->labels->name; ?>
			</a>
		</li>

		<li class="breadcrumb-item">
			<?php the_title(); ?>
		</li>
    <?php elseif ( is_page() ) : ?>
        <li class="breadcrumb-item">
            <?php the_title(); ?>
        </li>
	<?php endif; ?>

	<?php if ( ! empty( get_query_var( 'workforce-post-type' ) ) && ! empty( get_query_var( 'workforce-action' ) ) ) : ?>
		<li class="breadcrumb-item">
			<a href="<?php echo get_post_type_archive_link( get_query_var( 'workforce-post-type' ) ); ?>">
				<?php $post_type_obj = get_post_type_object( get_query_var( 'workforce-post-type' ) ); ?>
				<?php echo esc_html( $post_type_obj->labels->name ); ?>
			</a>
		</li>

		<?php if ( ! empty( get_query_var( 'workforce-id' ) ) ) : ?>
			<li class="breadcrumb-item">
				<?php echo get_the_title( get_query_var( 'workforce-id' ) ); ?>
			</li>
		<?php endif; ?>

		<li class="breadcrumb-item">
			<?php if ( \Workforce\Helper\CrudHelper::ACTION_UPDATE === get_query_var( 'workforce-action' ) ) : ?>
				<?php echo esc_html__( 'Update', 'workforce' ); ?>
			<?php elseif ( \Workforce\Helper\CrudHelper::ACTION_CREATE === get_query_var( 'workforce-action' ) ) : ?>
				<?php echo esc_html__( 'Create', 'workforce' ); ?>
			<?php endif; ?>
		</li>
	<?php endif; ?>
</ol>
