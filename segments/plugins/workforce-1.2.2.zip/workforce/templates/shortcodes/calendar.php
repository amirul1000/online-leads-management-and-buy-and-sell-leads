<?php use Workforce\Api\EventsApi; ?>

<div id="calendar" data-url="<?php echo home_url( '/' ) . rest_get_url_prefix() . '/' . EventsApi::PATH . 'get/'; ?>?"></div>
