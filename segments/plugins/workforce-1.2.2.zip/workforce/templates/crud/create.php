<?php get_header(); ?>

<div class="page-header">
	<?php do_action( 'workforce_page_header_before' ); ?>

	<?php $post_type = get_post_type_object( get_query_var( 'workforce-post-type' ) ); ?>
	<h1><?php echo esc_html__( 'Create New', 'workforce' ); ?> <span><?php echo esc_html( $post_type->labels->singular_name ); ?></span></h1>

	<?php do_action( 'workforce_page_header_after' ); ?>
</div><!-- .page-header -->

<div id="primary" class="content-area">
	<?php do_action( 'workforce_content_loop_before' );?>

	<main id="main" class="site-main" role="main">
		<?php cmb2_print_metabox_form( get_query_var( 'workforce-post-type' ), 'fake-id' ); ?>
	</main><!-- .site-main -->

	<?php do_action( 'workforce_content_loop_after' );?>
</div><!-- .content-area -->

<?php get_footer(); ?>
