<?php get_header(); ?>

<div class="page-header">
	<?php do_action( 'workforce_page_header_before' ); ?>

	<h1>
		<?php $post = get_post( get_query_var( 'workforce-id' ) ); ?>
		<?php echo esc_html__( 'Update', 'workforce' ); ?> <span><?php echo esc_html( $post->post_title ); ?></span>
	</h1>

	<?php do_action( 'workforce_page_header_after' ); ?>
</div><!-- .page-header -->

<div id="primary" class="content-area">
	<?php do_action( 'workforce_content_loop_before' );?>

	<main id="main" class="site-main" role="main">
		<?php cmb2_print_metabox_form( get_query_var( 'workforce-post-type' ), get_query_var( 'workforce-id' ) ); ?>
	</main><!-- .site-main -->

	<?php do_action( 'workforce_content_loop_after' );?>
</div><!-- .content-area -->

<?php get_footer(); ?>
