<?php use Workforce\Helper\CrudHelper; ?>

<?php get_header(); ?>

<div class="page-header">
	<?php do_action( 'workforce_page_header_before' ); ?>

	<h1><?php the_title(); ?></h1>

	<?php do_action( 'workforce_page_header_after' ); ?>
</div><!-- .page-header -->

<div id="primary" class="content-area">
	<?php do_action( 'workforce_content_loop_before' );?>

	<main id="main" class="site-main" role="main">
		<?php if ( have_posts() ) : ?>
			<div class="main-inner">
				<?php while( have_posts() ): the_post(); ?>
					<?php $form = Workforce\Type\LeadFormType::get_form( get_the_ID() ); ?>

					<?php if ( ! empty( $form ) ) : ?>
						<pre><code class="language-markup"><?php echo htmlentities( $form ); ?></code></pre>

						<hr>

						<?php echo $form; ?>
					<?php else : ?>
						<p><?php echo esc_html__( 'No capture form fields found. Please create some of them.', 'workforce' ); ?></p>
					<?php endif; ?>
				<?php endwhile; ?>
			</div><!-- /.main-inner -->		
		<?php endif; ?>
	</main><!-- .site-main -->

	<?php do_action( 'workforce_content_loop_after' ); ?>			
</div><!-- .content-area -->

<?php get_footer(); ?>	
