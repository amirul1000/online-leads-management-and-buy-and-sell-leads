<?php $company_id = get_user_meta( get_current_user_id(), WORKFORCE_USER_PREFIX . 'company_id', true ); ?>
<?php $project_ids = \Workforce\Type\ProjectType::get_ids_by_company( $company_id, -1 ); ?>
<?php $tasks = \Workforce\Type\TaskType::get_by_project( $project_ids, -1 ); ?>

<?php if ( ! empty( $tasks ) ) : ?>
	<h3><?php echo esc_html__( 'Tasks', 'workforce' ); ?></h3>

	<div class="table-wrapper">
		<table class="table workforce-client-table">
			<thead>
				<tr>
					<th class="title"><?php echo esc_html__( 'Title', 'workforce' ); ?></th>

					<th class="project"><?php echo esc_html__( 'Project', 'workforce' ); ?></th>

					<th class="status"><?php echo esc_html__( 'Status', 'workforce' ); ?></th>
				</tr>
			</thead>

			<tbody>
				<?php foreach ( $tasks as $task ) : ?>
					<tr>
					    <td class="title <?php echo Workforce\Helper\FilterHelper::is_active_order( 'title' ); ?>">
							<?php $user_id = get_post_meta( $task->ID, WORKFORCE_TASK_PREFIX . 'user_id', true ); ?>        


							<?php if ( ! empty( $user_id ) ) : ?>
								<?php echo Workforce\Helper\TemplateHelper::get_avatar( $user_id, WORKFORCE_USER_PREFIX . 'general_image', false, true ); ?>
							<?php endif; ?>

							<h2>
								<?php the_title(); ?>            

								<?php if ( ! empty( $user_id ) ) : ?>
									<span><?php echo Workforce\Type\UserType::get_name( $user_id ); ?></span>
								<?php endif; ?>			
							</h2>
						</td>

						<td class="project">
							<?php $project_id = get_post_meta( $task->ID, WORKFORCE_TASK_PREFIX . 'project_id', true ); ?>        

							<?php if ( ! empty( $project_id ) ) : ?>						
								<?php echo get_the_title( $project_id ); ?>
							<?php endif; ?>
						</td>

						<td class="status">
							<?php $status = get_post_meta( $task->ID, WORKFORCE_TASK_PREFIX . 'status', true ); ?>

							<?php if ( ! empty( $status ) ) : ?>
								<span class="label">
									<?php echo Workforce\Type\TaskType::get_status_display_name( $status ); ?>
								</span><!-- /.label -->
							<?php endif; ?>
						</td>		
					</tr>	
				<?php endforeach ?>
			</tbody>
		</table>
	</div><!-- /.table-wrapper -->						
<?php endif; ?>