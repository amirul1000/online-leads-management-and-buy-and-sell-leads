<?php $company_id = get_user_meta( get_current_user_id(), WORKFORCE_USER_PREFIX . 'company_id', true ); ?>
<?php $invoices = \Workforce\Type\InvoiceType::get_by_company( $company_id, -1 ); ?>

<?php if ( ! empty( $invoices ) ) : ?>
	<h3><?php echo esc_html__( 'Invoices', 'workforce' ); ?></h3>

	<div class="table-wrapper">
		<table class="table workforce-client-table">
			<thead>
				<tr>
					<th class="title"><?php echo esc_html__( 'Title', 'workforce' ); ?></th>

					<th class="date"><?php echo esc_html__( 'Date', 'workforce' ); ?></th>

					<th class="price"><?php echo esc_html__( 'Price', 'workforce' ); ?></th>

					<th class="status"><?php echo esc_html__( 'Status', 'workforce' ); ?></th>

					<th class="actions"><?php echo esc_html__( 'Actions', 'workforce' ); ?></th>
				</tr>
			</thead>

			<tbody>
				<?php foreach( $invoices as $invoice ) : ?>
					<tr>
						<td><h2><?php echo apply_filters( 'workforce_invoice_title', $invoice->ID ); ?></h2></td>

						<td class="date">
							<?php $date = get_post_meta( $invoice->ID, WORKFORCE_INVOICE_PREFIX . 'date', true ); ?>
							
							<?php if ( ! empty( $date ) ) : ?>
								<?php echo date( get_option( 'date_format' ), $date ); ?>
							<?php endif; ?>
						</td> 

						<td class="price">
							<?php $price = Workforce\Type\InvoiceType::get_invoice_total( $invoice->ID ); ?>
							<?php $currency_code = get_post_meta( $invoice->ID, WORKFORCE_INVOICE_PREFIX . 'currency_code', true ); ?>
							<?php echo Workforce\Helper\PriceHelper::format( $price, $currency_code ); ?>		
						</td>

						<td class="status">
							<?php $status = get_post_meta( $invoice->ID, WORKFORCE_INVOICE_PREFIX . 'status', true ); ?>

							<?php if ( ! empty( $status ) ) : ?>
								<span class="label">
									<?php echo Workforce\Type\InvoiceType::get_status_display_name( $status ); ?>
								</span><!-- /.label -->
							<?php endif; ?>
						</td>		
						
						<td class="actions">		
							<a href="?download-invoice=<?php echo esc_attr( $invoice->ID ); ?>">
								<?php echo esc_html__( 'Download', 'workforce' ); ?>								
							</a>
						</td>			
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div><!-- /.table-wrapper -->
<?php endif; ?>