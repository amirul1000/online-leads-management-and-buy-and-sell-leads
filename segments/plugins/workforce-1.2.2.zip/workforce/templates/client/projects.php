<?php $company_id = get_user_meta( get_current_user_id(), WORKFORCE_USER_PREFIX . 'company_id', true ); ?>
<?php $projects = \Workforce\Type\ProjectType::get_by_company( $company_id, -1 ); ?>

<?php if ( ! empty( $projects ) ) : ?>
	<h3><?php echo esc_html__( 'Projects', 'workforce' ); ?></h3>

	<div class="table-wrapper">
		<table class="table workforce-client-table">
			<thead>
				<tr>
					<th class="title"><?php echo esc_html__( 'Title', 'workforce' ); ?></th>

					<th class="progress"><?php echo esc_html__( 'Progress', 'workforce' ); ?></th>

					<th class="type"><?php echo esc_html__( 'Billing', 'workforce' ); ?></th>
				</tr>
			</thead>

			<tbody>
				<?php foreach ( $projects as $project ) : ?>		
					<tr>
					    <td class="title">
					    	<h2><?php echo $project->post_title; ?></h2>
						</td>

						<td class="progress">
							<?php $progress = Workforce\Type\ProjectType::get_progress( $project->ID ); ?>

							<?php if ( null === $progress ) : ?>
								<?php echo esc_html__( 'No assigned tasks', 'workforce' ); ?>
							<?php else : ?>
								<?php $breakdown = Workforce\Type\ProjectType::get_progress_breakdown( $project->ID ); ?>

								<div class="progress-bar <?php if ( 0 === $progress ) : ?>progress-not-started<?php endif;?>">
									<span class="progress-bar-inner" style="width: <?php echo esc_attr( $progress ); ?>%">					
										<span class="progress-bar-breakdown"><?php echo esc_attr( $breakdown ); ?></span>
									</span>				
								</div><!-- /.progress-bar -->        
							<?php endif; ?>
						</td>

						<td class="billing">
							<?php $billing = get_post_meta( $project->ID, WORKFORCE_PROJECT_PREFIX . 'billing_type', true ); ?>     

							<?php if ( ! empty( $billing ) ) : ?>
								<?php $status = Workforce\Type\ProjectType::get_status_display_name( $billing ); ?>
								<span class="label label-<?php echo esc_attr( $status ); ?>">
									<?php echo esc_html( $status ); ?>
								</span><!-- /.label -->
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>

			</tbody>
		</table>
	</div><!-- /.table-wrapper -->		
<?php endif; ?>