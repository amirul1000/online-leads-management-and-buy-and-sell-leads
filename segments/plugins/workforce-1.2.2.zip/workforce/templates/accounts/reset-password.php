<form class="reset-form" action="<?php echo wp_lostpassword_url(); ?>" method="post">
	<div class="form-group">
		<label for="reset-form-username" ><?php echo esc_html__( 'Username or E-mail:', 'workforce' ); ?></label>
		<input type="text" name="user_login" id="reset-form-username" class="form-control" size="20">
	</div><!-- /.form-group -->

	<?php do_action( 'recaptcha_print', array() ); ?>

	<div class="form-group form-group-button">
		<button type="submit" class="button" name="reset_form"><?php echo esc_html__( 'Get New Password', 'workforce' ); ?></button>
	</div><!-- /.form-group -->
</form>
