<form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" class="login-form">
	<?php do_action( 'workforce_account_login_before' ); ?>

	<div class="form-group form-group-username">
		<label for="login-form-username"><?php echo esc_html__( 'Username', 'workforce' ); ?></label>
		<input id="login-form-username" type="text" name="login" class="form-control" required="required" placeholder="<?php echo esc_attr__( 'Your username', 'workforce' ); ?>">
	</div><!-- /.form-group -->

	<div class="form-group form-group-password">
		<label for="login-form-password"><?php echo esc_html__( 'Password', 'workforce' ); ?></label>
		<input id="login-form-password" type="password" name="password" class="form-control" required="required" placeholder="<?php echo esc_attr__( 'Type password', 'workforce' ); ?>">
	</div><!-- /.form-group -->

	<?php do_action( 'wordpress_social_login' ); ?>

	<div class="form-group form-group-button">
		<button type="submit" name="login_form" class="button"><?php echo esc_html__( 'Sign in', 'workforce' ); ?></button>
	</div><!-- /.form-group -->

	<?php $page_id = get_theme_mod( 'workforce_pages_reset_password', null ); ?>

	<?php if ( ! empty( $page_id ) ) : ?>
		<div class="login-form-reset-link">
			<a href="<?php echo get_the_permalink( $page_id ); ?>">
				<?php echo esc_html__( 'Did you forget your password?', 'workforce' ); ?>
			</a>
		</div><!-- /.login-form-reset-link -->
	<?php endif; ?>

	<?php do_action( 'workforce_account_login_after' ); ?>
</form>
