<form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" class="register-form">
	<div class="form-group">
		<label for="register-form-name"><?php echo esc_html__( 'Username', 'workforce' ); ?></label>
		<input id="register-form-name" type="text" name="username" class="form-control" required="required">
	</div><!-- /.form-group -->

	<div class="form-group">
		<label for="register-form-email"><?php echo esc_html__( 'E-mail', 'workforce' ); ?></label>
		<input id="register-form-email" type="email" name="email" class="form-control" required="required">
	</div><!-- /.form-group -->

	<div class="form-group">
		<label for="register-form-password"><?php echo esc_html__( 'Password', 'workforce' ); ?></label>
		<input id="register-form-password" type="password" name="password" class="form-control" required="required">
	</div><!-- /.form-group -->

	<div class="form-group">
		<label for="register-form-retype"><?php echo esc_html__( 'Retype Password', 'workforce' ); ?></label>
		<input id="register-form-retype" type="password" name="password_retype" class="form-control" required="required">
	</div><!-- /.form-group -->

	<?php $terms = get_theme_mod( 'workforce_pages_tos', false ); ?>

	<?php if ( ! empty( $terms ) ) : ?>
		<div class="form-group terms-conditions-input">
			<div class="checkbox">
				<label for="register-form-conditions">
					<input id="register-form-conditions" type="checkbox" name="agree_terms">
					<?php echo wp_kses( sprintf( __( 'I agree with <a href="%s">terms & conditions</a>', 'workforce' ), get_permalink( $terms ) ), wp_kses_allowed_html( 'post' ) ); ?>
				</label>
			</div><!-- /.checkbox -->
		</div><!-- /.form-group -->
	<?php endif; ?>

	<?php do_action( 'wordpress_social_login' ); ?>

	<div class="form-group form-group-button">
		<button type="submit" class="button" name="register_form"><?php echo esc_html__( 'Sign Up', 'workforce' ); ?></button>
	</div><!-- /.form-group -->
</form>
