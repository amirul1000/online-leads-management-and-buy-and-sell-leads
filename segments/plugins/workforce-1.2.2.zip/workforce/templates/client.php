<?php get_header(); ?>

<?php echo Workforce\Helper\TemplateHelper::load( 'client/invoices' ); ?>

<?php echo Workforce\Helper\TemplateHelper::load( 'client/projects' ); ?>

<?php echo Workforce\Helper\TemplateHelper::load( 'client/tasks' ); ?>

<?php get_footer(); ?>