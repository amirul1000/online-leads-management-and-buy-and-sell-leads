<style>
    body {
        font-family: 'Arial';
        font-size: 13px;
    }

    h1 {
        border-bottom: 1px solid #ececec;
        font-size: 20px;
        font-weight: normal;
        margin: 0 0 20px 0;
        padding: 0 0 20px 0;
    }

    dl {
        margin: 0;
        padding: 0;
    }

    dt {
        float: left;
        line-height: 26px;
        width: 100px;
    }

    dd {
        line-height: 26px;
    }

    table {
        border-bottom: 1px solid #ececec;
        border-collapse: collapse;
        float: left;
        margin: 0 0 30px 0;
        width: 100%;
    }

    th {
        font-size: 12px;
        padding: 0 8px 12px 8px;
        text-align: left;
    }

    td {
        border-top: 1px solid #ececec;
        padding: 12px 8px;
    }

    #general, #details {
        border: 1px solid #ececec;
        margin: 0 0 30px 0;
        padding: 15px;
        width: 44%;
    }

    #general {
        float: left;
    }

    #details {
        float: right;
    }

    #supplier, #customer {
        background-color: #ececec;
        margin: 0 0 30px 0;
        padding: 15px;
        width: 44%;
    }

    #supplier h2, #customer h2 {
        font-size: 14px;
        font-weight: bold;
        margin: 0 0 15px 0;
        padding: 0;
    }

    #supplier {
        clear: left;
        float: left;
    }

    #customer {
        clear: right;
        float: right;
    }

    #total {
        text-align: right;
    }

    #total-inner {
        font-size: 12px;
        font-weight: bold;
        padding: 8px 12px;
    }
</style>

<div class="invoice">
    <h1>
        <?php echo esc_html__( 'Invoice', 'workforce' ); ?>
		<?php echo apply_filters( 'workforce_invoice_title', $id ); ?>
	</h1>

	<section id="general">
		<dl>
			<dt><?php echo esc_html__( 'Issue date', 'workforce' ) . ':' ?></dt> <dd><?php echo esc_html( date( 'Y-m-d', $issue_date ) ); ?></dd>
			<dt><?php echo esc_html__( 'Payment term', 'workforce' ) . ':' ?></dt> <dd><?php echo _n( sprintf( '%d day', $payment_term ), sprintf( '%d days', $payment_term ), $payment_term, 'workforce' ); ?></dd>
		</dl>
	</section>

	<?php if ( ! empty( $details ) ) : ?>
		<section id="details">
			<dl>
				<dt><?php echo __( 'Instructions', 'workforce' ) . ':' ?></dt> <dd><?php echo nl2br( apply_filters( 'workforce_invoices_payment_details', $details ) ); ?></dd>
			</dl>
		</section>
	<?php endif; ?>

	<section id="supplier">
		<h2><?php echo esc_html__( 'Supplier', 'workforce' ) ?></h2>
		<dl>
			<dt><?php echo esc_html__( 'Name', 'workforce' ) . ':' ?></dt> <dd><?php echo esc_html( $supplier_name ); ?></dd>
			<dt><?php echo esc_html__( 'Reg. No.', 'workforce' ) . ':' ?></dt> <dd><?php echo esc_html( $supplier_registration_number ); ?></dd>
			<dt><?php echo esc_html__( 'VAT No.', 'workforce' ) . ':' ?></dt> <dd><?php echo esc_html( $supplier_vat_number ); ?></dd>
			<dt><?php echo esc_html__( 'Details', 'workforce' ) . ':' ?></dt> <dd><?php echo nl2br( apply_filters( 'workforce_invoices_supplier_details', $supplier_details ) ); ?></dd>
		</dl>
	</section>

	<section id="customer">
		<h2><?php echo esc_html__( 'Customer', 'workforce' ) ?></h2>
		<dl>
			<dt><?php echo esc_html__( 'Name', 'workforce' ) . ':' ?></dt> <dd><?php echo esc_html( $customer_name ); ?></dd>
			<dt><?php echo esc_html__( 'Reg. No.', 'workforce' ) . ':' ?></dt> <dd><?php echo esc_html( $customer_registration_number ); ?></dd>
			<dt><?php echo esc_html__( 'VAT No.', 'workforce' ) . ':' ?></dt> <dd><?php echo esc_html( $customer_vat_number ); ?></dd>
			<dt><?php echo esc_html__( 'Details', 'workforce' ) . ':' ?></dt> <dd><?php echo nl2br( apply_filters( 'workforce_invoices_customer_details', $customer_details ) ); ?></dd>
		</dl>
	</section>

	<section id="items">
		<?php if ( count( $items ) > 0 ) : ?>
			<table class="invoice-items-table">
				<thead>
					<tr>
						<th><?php echo esc_html__( 'Item', 'workforce' ); ?></th>
						<th><?php echo esc_html__( 'Quantity', 'workforce' ); ?></th>
						<th><?php echo esc_html__( 'Unit price', 'workforce' ); ?></th>
						<th><?php echo esc_html__( 'Tax rate', 'workforce' ); ?></th>
						<th><?php echo esc_html__( 'Subtotal', 'workforce' ); ?></th>
						<th><?php echo esc_html__( 'Currency', 'workforce' ); ?></th>
					</tr>
				</thead>

				<tbody>
					<?php foreach ( $items as $item ) : ?>
						<?php
						$title = $item[ WORKFORCE_INVOICE_PREFIX . 'item_title' ];
						$quantity = $item[ WORKFORCE_INVOICE_PREFIX . 'item_quantity' ];
						$unit_price = $item[ WORKFORCE_INVOICE_PREFIX . 'item_unit_price' ];
						$tax_rate = $item[ WORKFORCE_INVOICE_PREFIX . 'item_tax_rate' ];
						$subtotal = \Workforce\Type\InvoiceType::get_invoice_item_subtotal( $item );
						?>

						<tr>
							<td><?php echo esc_html( $title ); ?></td>
							<td><?php echo esc_html( $quantity ); ?></td>
							<td><?php echo esc_html( $unit_price ); ?></td>
							<td><?php echo esc_html( $tax_rate ); ?>%</td>
							<td><?php echo esc_html( $subtotal ); ?></td>
							<td><?php echo esc_html( $currency_code ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php else : ?>
			<div class="alert alert-warning"><?php echo esc_html__( 'No invoice items found.', 'workforce' ); ?></div>
		<?php endif; ?>
	</section>

	<section id="total">
		<span id="total-inner">
			<label><?php echo esc_html__( 'Total', 'workforce' ) . ':' ?></label>
			<span><?php printf( '%s %s', $total, $currency_code ); ?><span>
		</span>
	</section>
</div>
