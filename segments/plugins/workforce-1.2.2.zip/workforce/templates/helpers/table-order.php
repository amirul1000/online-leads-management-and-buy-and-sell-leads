<a href="?<?php echo \Workforce\Helper\FilterHelper::get_uri_arguments( [ 'order' => $field, 'sort' => 'ASC' ], true ); ?>"
	class="workforce-table-header-item-order asc <?php echo Workforce\Helper\FilterHelper::is_active_order( [ 'order' => $field, 'sort' => 'ASC' ], 'active', 'inactive' ); ?>"
	title="<?php echo esc_attr__( 'Ascending', 'workforce' ); ?>">
	<?php echo esc_html__( 'ASC', 'workforce' ); ?>
</a>

<a href="?<?php echo \Workforce\Helper\FilterHelper::get_uri_arguments( [ 'order' => $field, 'sort' => 'DESC' ], true ); ?>"
	class="workforce-table-header-item-order desc <?php echo Workforce\Helper\FilterHelper::is_active_order( [ 'order' => $field, 'sort' => 'DESC' ], 'active', 'inactive' ); ?>"
	title="<?php echo esc_attr__( 'Descending', 'workforce' ); ?>">
	<?php echo esc_html__( 'DESC', 'workforce' ); ?>
</a>
