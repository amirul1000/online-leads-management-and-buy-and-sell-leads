<?php use Workforce\Helper\CrudHelper; ?>

<?php global $wp_query; ?>

<?php $post_type_object = get_post_type_object( $wp_query->query['post_type'] ); ?>

<div class="empty">
	<h2><?php echo esc_html__( 'No Results Found', 'workforce' ); ?></h2>

	<p><?php echo esc_html__( 'That\'s okay. You can add new content by using button below.', 'workforce' ); ?></p>

	<a href="<?php echo CrudHelper::get_action_uri( $wp_query->query['post_type'], CrudHelper::ACTION_CREATE ); ?>" class="btn btn-secondary">
		<?php echo esc_html__( 'Create New', 'workforce' ); ?> <?php echo esc_html( $post_type_object->labels->singular_name ); ?>
	</a>
</div><!-- /.empty -->
