<?php use Workforce\Helper\CrudHelper; ?>

<?php $post_types = apply_filters( 'workforce_crud_post_types', [] ); ?>

<?php if ( is_post_type_archive( $post_types ) ) : ?>
	<?php global $wp_query; ?>

	<?php $post_type = get_queried_object(); ?>
	<?php $post_type_obj = get_post_type_object( $post_type->name ); ?>

	<div class="page-header-actions">
		<a href="<?php echo CrudHelper::get_action_uri( $post_type->name, CrudHelper::ACTION_CREATE ); ?>" class="btn btn-primary">
			<?php echo esc_html__( 'Create', 'workforce' ) . ' ' . $post_type_obj->labels->singular_name; ?>
		</a>
	</div><!-- /.page-header-actions -->

	<?php if ( ! empty( $wp_query->found_posts ) ) : ?>
		<div class="page-header-results">
			<?php echo esc_html__( 'Total items', 'workforce' ); ?>: <?php echo esc_html( $wp_query->found_posts ); ?>
		</div><!-- /.page-header-results -->
	<?php endif; ?>
<?php elseif ( ! empty( get_query_var( 'workforce-post-type' ) ) && ! empty( get_query_var( 'workforce-action' ) ) ) : ?>
	<?php $post_type_obj = get_post_type_object( get_query_var( 'workforce-post-type' ) ); ?>

	<div class="page-header-actions">
		<a href="<?php echo CrudHelper::get_action_uri( get_query_var( 'workforce-post-type' ), CrudHelper::ACTION_CREATE ); ?>" class="btn btn-primary">
			<?php echo esc_html__( 'Create', 'workforce' ) . ' ' . $post_type_obj->labels->singular_name; ?>
		</a>
	</div><!-- /.page-header-actions -->
<?php endif; ?>
