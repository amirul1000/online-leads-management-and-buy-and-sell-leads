<div class="login-required">
	<p>
		<?php echo esc_html__( 'Log in before accessing this content.', 'workforce' ); ?>
	</p>
</div><!-- /.login-required -->
