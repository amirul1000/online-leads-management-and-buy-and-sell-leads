<?php $tags = wp_get_post_terms( get_the_ID(), 'post_tag' );?>

<?php if ( ! empty( $tags ) ) : ?>
	<?php foreach ( $tags as $tag ) : ?>
		<?php $color = Workforce\Helper\TagHelper::get_color( $tag->slug ); ?>
		<span class="tag tag-<?php echo esc_attr( $tag->slug ); ?> <?php if ( ! empty( $color ) ) : ?>has-color<?php endif; ?>" style="background-color: <?php echo esc_attr( $color ); ?>">
			<?php echo esc_html( $tag->name ); ?>
		</span>
	<?php endforeach; ?>
<?php endif; ?>
