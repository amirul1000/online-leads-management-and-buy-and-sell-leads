<a
	class="avatar <?php if ( ! empty( $class ) ) : ?><?php echo esc_attr( $class ); ?> <?php endif ;?><?php if ( ! empty( $image ) ) : ?>has-image<?php endif; ?>"
	<?php if ( ! empty( $color ) ) : ?>style="background-color: <?php echo esc_attr( $color ); ?>"<?php endif; ?>>

	<?php if ( empty( $image ) ) : ?>
		<?php echo esc_html( $monogram ); ?>
	<?php else : ?>
		<img src="<?php echo esc_attr( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>">
	<?php endif; ?>
</a><!-- /.avatar -->
