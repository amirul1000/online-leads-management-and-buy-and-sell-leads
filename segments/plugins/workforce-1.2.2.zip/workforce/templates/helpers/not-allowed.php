<p class="not-allowed">
	<?php echo esc_html__( 'You are not allowed to access this content.', 'workforce' ); ?>
</p><!-- /.not-allowed -->
