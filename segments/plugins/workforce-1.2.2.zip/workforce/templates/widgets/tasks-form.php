<!-- TITLE -->
<p>
    <label for="<?php echo esc_attr( $widget->get_field_id( 'title' ) ); ?>">
		<?php echo esc_html__( 'Title', 'workforce' ); ?>
	</label>

	<input  class="widefat"
			id="<?php echo esc_attr( $widget->get_field_id( 'title' ) ); ?>"
			name="<?php echo esc_attr( $widget->get_field_name( 'title' ) ); ?>"
			type="text"
			value="<?php echo ! empty( $instance['title'] ) ? $instance['title'] : ''; ?>">
</p>

<!-- COUNT -->
<p>
	<label for="<?php echo esc_attr( $widget->get_field_id( 'count' ) ); ?>">
		<?php echo esc_html__( 'Count', 'workforce' ); ?>
	</label>

	<input  class="widefat"
			id="<?php echo esc_attr( $widget->get_field_id( 'count' ) ); ?>"
			name="<?php echo esc_attr( $widget->get_field_name( 'count' ) ); ?>"
			type="text"
			value="<?php echo ! empty( $instance['count'] ) ? $instance['count'] : 5; ?>">
</p>

<!-- SHOW CREATE BUTTON -->
<p>
	<input  type="checkbox"
			class="checkbox"
		<?php echo ! empty( $instance['show_create_button'] ) ? 'checked="checked"' : ''; ?>
			id="<?php echo esc_attr( $widget->get_field_id( 'show_create_button' ) ); ?>"
			name="<?php echo esc_attr( $widget->get_field_name( 'show_create_button' ) ); ?>">

	<label for="<?php echo esc_attr( $widget->get_field_id( 'show_create_button' ) ); ?>">
		<?php echo esc_html__( 'Show create button', 'workforce' ); ?>
	</label>
</p>

<!-- SHOW ALL BUTTON -->
<p>
	<input  type="checkbox"
			class="checkbox"
		<?php echo ! empty( $instance['show_all_button'] ) ? 'checked="checked"' : ''; ?>
			id="<?php echo esc_attr( $widget->get_field_id( 'show_all_button' ) ); ?>"
			name="<?php echo esc_attr( $widget->get_field_name( 'show_all_button' ) ); ?>">

	<label for="<?php echo esc_attr( $widget->get_field_id( 'show_all_button' ) ); ?>">
		<?php echo esc_html__( 'Show all button', 'workforce' ); ?>
	</label>
</p>
