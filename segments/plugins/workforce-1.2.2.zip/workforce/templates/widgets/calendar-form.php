<p>
    <label for="<?php echo esc_attr( $widget->get_field_id( 'title' ) ); ?>">
		<?php echo esc_html__( 'Title', 'workforce' ); ?>
	</label>

	<input  class="widefat"
			id="<?php echo esc_attr( $widget->get_field_id( 'title' ) ); ?>"
			name="<?php echo esc_attr( $widget->get_field_name( 'title' ) ); ?>"
			type="text"
			value="<?php echo ! empty( $instance['title'] ) ? $instance['title'] : ''; ?>">
</p>
