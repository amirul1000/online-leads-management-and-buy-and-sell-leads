<?php echo wp_kses( $args['before_widget'], wp_kses_allowed_html( 'post' ) ); ?>

<?php if ( ! empty( $instance['title'] ) ) : ?>
	<?php echo wp_kses( $args['before_title'], wp_kses_allowed_html( 'post' ) ); ?>
	<?php echo wp_kses( $instance['title'], wp_kses_allowed_html( 'post' ) ); ?>
	<?php echo wp_kses( $args['after_title'], wp_kses_allowed_html( 'post' ) ); ?>
<?php endif; ?>

<?php $atts = \Workforce\Helper\TemplateHelper::build_shortcode_atts( $instance ); ?>
<?php echo do_shortcode( sprintf( '[workforce_calendar %s]', $atts ) ); ?>

<?php echo wp_kses( $args['after_widget'], wp_kses_allowed_html( 'post' ) );
