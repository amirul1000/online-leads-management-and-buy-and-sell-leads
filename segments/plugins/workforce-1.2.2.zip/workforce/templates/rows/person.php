<?php use \Workforce\Helper\CrudHelper; ?>

<tr>
	<td class="title <?php echo \Workforce\Helper\FilterHelper::is_active_order( 'title' ); ?>">
		<?php echo Workforce\Helper\TemplateHelper::get_avatar( get_the_ID(), WORKFORCE_PERSON_PREFIX . 'image' ); ?>

		<h2>
			<a>
				<?php the_title(); ?>

				<?php $company_id = get_post_meta( get_the_ID(), WORKFORCE_PERSON_PREFIX . 'company_id', true ); ?>
				<?php $position = get_post_meta( get_the_ID(), WORKFORCE_PERSON_PREFIX . 'position', true ); ?>

				<?php if ( ! empty( $position ) ) : ?>
					<span>
						<?php echo esc_html( $position ); ?>

						<?php if ( ! empty( $company_id ) ) : ?>
							<?php echo esc_html__( 'at', 'workforce' ); ?>
							<?php $company = get_post( $company_id );?>
							<?php echo get_the_title( $company_id ); ?>
						<?php endif; ?>
					</span>
				<?php endif; ?>
			</a>
		</h2>
	</td>

	<td class="email">
		<?php $emails = get_post_meta( get_the_ID(), WORKFORCE_PERSON_PREFIX . 'email', true ); ?>

		<?php if ( ! empty( $emails ) && is_array( $emails ) && ! empty( $emails[0] ) ) : ?>
			<a href="mailto:<?php echo esc_attr( $emails[0] ); ?>">
				<?php echo esc_html( $emails[0] ); ?>
			</a>
		<?php endif; ?>
	</td>

	<td class="count">
		<?php $touchpoints = Workforce\Type\TouchpointType::get_by_person( get_the_ID(), -1 ); ?>
		<?php echo count( $touchpoints ); ?>
	</td>

	<td class="date">
		<?php if ( ! empty( $touchpoints && count ( $touchpoints ) > 0 ) ) : ?>
			<?php $touchpoint = array_shift( $touchpoints ); ?>
			<?php echo Workforce\Type\TouchpointType::get_date( $touchpoint->ID ); ?>
		<?php else : ?>
			-
		<?php endif; ?>
	</td>

	<td class="actions">
		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_UPDATE, get_the_ID() ); ?>" 
		   class="update">
			<?php echo esc_html__( 'Update', 'workforce' ); ?>
		</a>

		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_DELETE, get_the_ID() ); ?>" 
		   class="delete">
			<?php echo esc_html__( 'Delete', 'workforce' ); ?>
		</a>
	</td><!-- /.workforce-table-cell -->
</tr>
