<tr>
    <td class="title <?php echo Workforce\Helper\FilterHelper::is_active_order( 'title' ); ?>">
    	<?php $company_id = get_post_meta( get_the_ID(), WORKFORCE_PROJECT_PREFIX . 'company_id', true ); ?>
    	<?php if ( ! empty( $company_id ) ) : ?>
			<?php echo Workforce\Helper\TemplateHelper::get_avatar( $company_id, WORKFORCE_COMPANY_PREFIX . 'image', 'bordered' ); ?>
		<?php endif; ?>

    	<h2>
    		<?php the_title(); ?>	

			<?php if ( ! empty( $company_id ) ) : ?>
				<span>
					<a href="<?php echo get_the_permalink( $company_id ); ?>"><?php echo get_the_title( $company_id ); ?></a>
				</span>
			<?php endif; ?>            
        </h2>
	</td>

	<td class="progress">
		<?php $progress = Workforce\Type\ProjectType::get_progress( get_the_ID() ); ?>

		<?php if ( null === $progress ) : ?>
			<?php echo esc_html__( 'No assigned tasks', 'workforce' ); ?>
		<?php else : ?>
			<?php $breakdown = Workforce\Type\ProjectType::get_progress_breakdown( get_the_ID() ); ?>

			<div class="progress-bar <?php if ( 0 === $progress ) : ?>progress-not-started<?php endif;?>">
				<span class="progress-bar-inner" style="width: <?php echo esc_attr( $progress ); ?>%">					
					<span class="progress-bar-breakdown"><?php echo esc_attr( $breakdown ); ?></span>
				</span>				
			</div><!-- /.progress-bar -->        
		<?php endif; ?>
	</td>

	<td class="billing">
		<?php $billing = get_post_meta( get_the_ID(), WORKFORCE_PROJECT_PREFIX . 'billing_type', true ); ?>     

		<?php if ( ! empty( $billing ) ) : ?>
			<?php $status = Workforce\Type\ProjectType::get_status_display_name( $billing ); ?>
			<span class="label label-<?php echo esc_attr( $status ); ?>">
				<?php echo esc_html( $status ); ?>
			</span><!-- /.label -->
		<?php endif; ?>
	</td>

	<td class="actions">
		<a href="?create-invoice-from-project=<?php the_ID(); ?>"
		   class="create-invoice">
			<?php echo esc_html__( 'Download Invoice', 'workforce' ); ?>
		</a>

		<a href="<?php echo Workforce\Helper\CrudHelper::get_action_uri( get_post_type(), Workforce\Helper\CrudHelper::ACTION_UPDATE, get_the_ID() ); ?>"
		   class="update">
			<?php echo esc_html__( 'Update', 'workforce' ); ?>
		</a>

		<a href="<?php echo Workforce\Helper\CrudHelper::get_action_uri( get_post_type(), Workforce\Helper\CrudHelper::ACTION_DELETE, get_the_ID() ); ?>"
		   class="delete">
			<?php echo esc_html__( 'Delete', 'workforce' ); ?>
		</a>
	</td>
</tr>
