<?php use \Workforce\Helper\CrudHelper; ?>

<tr>
	<td class="title <?php echo \Workforce\Helper\FilterHelper::is_active_order( 'title' ); ?>">
		<h2>
			<?php the_title(); ?>
		</h2>
	</td>

	<td class="bool">
		<?php $capture_form_id = get_post_meta( get_the_ID(), WORKFORCE_LEAD_PREFIX . 'capture_form_id', true ); ?>

		<?php if ( ! empty( $capture_form_id ) ) : ?>
			<span class="bool true"><?php echo esc_html__( 'Yes', 'workforce' ); ?></span>
		<?php else : ?>
			<span class="bool false"><?php echo esc_html__( 'No', 'workforce' ); ?></span>
		<?php endif; ?>
	</td>	

	<td class="date">
		<?php echo get_the_date(); ?>	
	</td>

	<td class="type">
		<?php $tags = wp_get_post_terms( get_the_ID(), 'lead_type' );?>

		<?php if ( ! empty( $tags ) ) : ?>
			<?php foreach ( $tags as $tag ) : ?>
				<span class="label label-<?php echo esc_attr( $tag->slug ); ?>">
				<?php echo esc_html( $tag->name ); ?>
			</span>
			<?php endforeach; ?>
		<?php endif; ?>	
	</td>


	<td class="actions">
		<?php if ( ! Workforce\Type\LeadType::is_converted( get_the_ID() ) ) : ?>
			<a href="?convert-lead=<?php the_ID(); ?>" class="convert">
				<?php echo esc_html__( 'Convert', 'workforce' ); ?>
			</a>
        <?php else : ?>
            <a class="convert disabled">
                <?php echo esc_html__( 'Convert', 'workforce' ); ?>
            </a>
		<?php endif; ?>

		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_UPDATE, get_the_ID() ); ?>" 
		   class="update">
			<?php echo esc_html__( 'Update', 'workforce' ); ?>
		</a>

		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_DELETE, get_the_ID() ); ?>" 
		   class="delete">
			<?php echo esc_html__( 'Delete', 'workforce' ); ?>
		</a>
	</td>
</tr>
