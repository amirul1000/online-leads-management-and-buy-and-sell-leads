<?php use Workforce\Helper\CrudHelper; ?>
<tr>
	<td class="title <?php echo \Workforce\Helper\FilterHelper::is_active_order( 'title' ); ?>">
		<?php the_title(); ?>
	</td>

	<td class="price">
		<?php $price = get_post_meta( get_the_ID(), WORKFORCE_EXPENSE_PREFIX . 'price', true ); ?>
		<?php $currency = get_post_meta( get_the_ID(), WORKFORCE_EXPENSE_PREFIX . 'currency_code', true ); ?>

		<?php if ( empty( $price ) ) : ?>
			<?php echo esc_html__( 'Undefined price', 'workforce' ); ?>		
		<?php elseif ( empty( $currency ) ) : ?>
			<?php echo esc_html__( 'Undefined currency', 'workforce' ); ?>
		<?php else : ?>
			<?php echo Workforce\Helper\PriceHelper::format( $price, $currency ); ?>		
		<?php endif; ?>				
	</td>

	<td class="date">
		<?php $date = get_post_meta( get_the_ID(), WORKFORCE_EXPENSE_PREFIX . 'date', true ); ?>
		<?php if ( ! empty( $date ) ) : ?>
			<?php echo date( get_option( 'date_format' ), $date ); ?>
		<?php endif; ?>
	</td>

	<td class="type">
		<?php $tags = wp_get_post_terms( get_the_ID(), 'expense_type' );?>

		<?php if ( ! empty( $tags ) ) : ?>
			<?php foreach ( $tags as $tag ) : ?>
				<span class="label label-<?php echo esc_attr( $tag->slug ); ?>">
				<?php echo esc_html( $tag->name ); ?>
			</span>
			<?php endforeach; ?>
		<?php endif; ?>	
	</td>

	<td class="actions">
		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_UPDATE, get_the_ID() ); ?>"
		   class="update">
			<?php echo esc_html__( 'Update', 'workforce' ); ?>
		</a>

		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_DELETE, get_the_ID() ); ?>"
		   class="delete">
			<?php echo esc_html__( 'Delete', 'workforce' ); ?>
		</a>
	</td>
</tr>
