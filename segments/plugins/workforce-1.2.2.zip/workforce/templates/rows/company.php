<?php use \Workforce\Helper\CrudHelper; ?>

<tr>
	<td class="title <?php echo \Workforce\Helper\FilterHelper::is_active_order( 'title' ); ?>">
		<?php echo Workforce\Helper\TemplateHelper::get_avatar( get_the_ID(), WORKFORCE_COMPANY_PREFIX . 'image', 'bordered' ); ?>

		<h2>
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			<?php $persons = Workforce\Type\PersonType::get_by_company( get_the_ID(), -1 ); ?>

			<span>
				<?php if ( 0 === count( $persons ) ) : ?> 
					<?php echo esc_html__( 'No employees', 'workforce' ); ?>
				<?php elseif ( 1 === count( $persons ) ) : ?>
					<?php echo esc_html( '1 employee', 'workforce' ); ?>
				<?php else : ?>
					<?php echo count( $persons ); ?> <?php echo esc_html__( 'employees', 'workforce' ); ?>
				<?php endif; ?>				
			</span>
		</h2>
	</td>

	<td class="email">
		<?php $emails = get_post_meta( get_the_ID(), WORKFORCE_COMPANY_PREFIX . 'email', true ); ?>

		<?php if ( ! empty( $emails ) && is_array( $emails ) && ! empty( $emails[0] ) ) : ?>
			<a href="mailto:<?php echo esc_attr( $emails[0] ); ?>">
				<?php echo esc_html( $emails[0] ); ?>
			</a>
		<?php endif; ?>
	</td>

	<td class="count">
		<?php $projects = Workforce\Type\ProjectType::get_by_company( get_the_ID() , -1 ); ?>
		<?php echo count( $projects ); ?>
	</td>

	<td class="price">
		<?php $revenues = Workforce\Type\CompanyType::get_revenue( get_the_ID(), [ Workforce\Type\InvoiceType::INVOICE_STATUS_UNPAID, Workforce\Type\InvoiceType::INVOICE_STATUS_DRAFT ] ); ?>
		
		<?php if ( null === $revenues ) : ?>
			<?php echo esc_html__( 'All paid', 'workforce' ); ?>
		<?php elseif ( is_array( $revenues ) ) : ?>
			<?php foreach ( $revenues as $revenue ) : ?>
				<?php echo Workforce\Helper\PriceHelper::format( $revenue['total'], $revenue['currency_code'] ); ?>
			<?php endforeach; ?>
		<?php endif ;?>
	</td>

	<td class="price">
		<?php $revenues = Workforce\Type\CompanyType::get_revenue( get_the_ID(), [ Workforce\Type\InvoiceType::INVOICE_STATUS_PAID ] ); ?>

		<?php if ( null === $revenues ) : ?>
			<?php echo esc_html__( 'No invoices', 'workforce' ); ?>
		<?php elseif ( is_array( $revenues ) ) : ?>
			<?php foreach ( $revenues as $revenue ) : ?>
				<?php echo Workforce\Helper\PriceHelper::format( $revenue['total'], $revenue['currency_code'] ); ?>
			<?php endforeach; ?>
		<?php endif ;?>
	</td>

	<td class="actions">
		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_UPDATE, get_the_ID() ); ?>" 
		   class="update">
			<?php echo esc_html__( 'Update', 'workforce' ); ?>
		</a>

		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_DELETE, get_the_ID() ); ?>" 
		   class="delete">
			<?php echo esc_html__( 'Delete', 'workforce' ); ?>
		</a>
	</td>
</tr>
