<?php use Workforce\Helper\CrudHelper; ?>

<tr>
	<td class="title <?php echo Workforce\Helper\FilterHelper::is_active_order( 'title' ); ?>">
		<?php $company_id = get_post_meta( get_the_ID(), WORKFORCE_INVOICE_PREFIX . 'company_id', true ); ?>

    	<?php if ( ! empty( $company_id ) ) : ?>
			<?php echo Workforce\Helper\TemplateHelper::get_avatar( $company_id, WORKFORCE_COMPANY_PREFIX . 'image', 'bordered' ); ?>
		<?php endif; ?>
				
		<h2>
			<?php echo apply_filters( 'workforce_invoice_title', get_the_ID() ); ?>		

			<?php if ( ! empty( $company_id ) ) : ?>
				<span>
					<a href="<?php echo get_the_permalink( $company_id ) ?>">
						<?php echo get_the_title( $company_id ); ?>
					</a>
				</span>
			<?php endif; ?>
		</h2>		
	</td>
	 
	<td class="date">
		<?php $date = get_post_meta( get_the_ID(), WORKFORCE_INVOICE_PREFIX . 'date', true ); ?>
		
		<?php if ( ! empty( $date ) ) : ?>
			<?php echo date( get_option( 'date_format' ), $date ); ?>
		<?php endif; ?>
	</td> 

	<td class="price">
		<?php $price = Workforce\Type\InvoiceType::get_invoice_total( get_the_ID() ); ?>
		<?php $currency_code = get_post_meta( get_the_ID(), WORKFORCE_INVOICE_PREFIX . 'currency_code', true ); ?>
		<?php echo Workforce\Helper\PriceHelper::format( $price, $currency_code ); ?>		
	</td>

	<td class="status">
		<?php $status = get_post_meta( get_the_ID(), WORKFORCE_INVOICE_PREFIX . 'status', true ); ?>

		<?php if ( ! empty( $status ) ) : ?>
			<span class="label">
				<?php echo Workforce\Type\InvoiceType::get_status_display_name( $status ); ?>
			</span><!-- /.label -->
		<?php endif; ?>
	</td>

	<td class="actions">
        <a href="?send-invoice=<?php the_ID(); ?>"
           class="send">
            <?php echo esc_html__( 'Send', 'workforce' ); ?>
        </a>

		<a href="?download-invoice=<?php the_ID(); ?>"
		   class="download">
			<?php echo esc_html__( 'Download', 'workforce' ); ?>
		</a>

		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_UPDATE, get_the_ID() ); ?>"
		   class="update">
			<?php echo esc_html__( 'Update', 'workforce' ); ?>
		</a>

		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_DELETE, get_the_ID() ); ?>"
		   class="delete">
			<?php echo esc_html__( 'Delete', 'workforce' ); ?>
		</a>
	</td><!-- /.workforce-table-cell -->
</tr>
