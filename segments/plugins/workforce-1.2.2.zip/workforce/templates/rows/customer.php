<?php use \Workforce\Helper\CrudHelper; ?>

<tr>
	<td class="title <?php echo \Workforce\Helper\FilterHelper::is_active_order( 'title' ); ?>">
		<h2>
			<?php the_title(); ?>
		</h2>
	</td>
	
	<td class="actions">
		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_UPDATE, get_the_ID() ); ?>" 
		   class="update">
			<?php echo esc_html__( 'Update', 'workforce' ); ?>
		</a>

		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_DELETE, get_the_ID() ); ?>" 
		   class="delete">
			<?php echo esc_html__( 'Delete', 'workforce' ); ?>
		</a>
	</td>
</tr>
