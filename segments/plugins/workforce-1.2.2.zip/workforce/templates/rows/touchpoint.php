<?php use \Workforce\Helper\CrudHelper; ?>

<tr>
	<td class="title <?php echo \Workforce\Helper\FilterHelper::is_active_order( 'title' ); ?>">
        <?php $user_id = get_post_meta( get_the_ID(), WORKFORCE_TOUCHPOINT_PREFIX . 'user_id', true ); ?>
        <?php echo Workforce\Helper\TemplateHelper::get_avatar( $user_id, WORKFORCE_USER_PREFIX . 'general_image', false, true ); ?>

		<h2>
			<?php the_title(); ?>

			<?php $tags = wp_get_post_terms( get_the_ID(), 'touchpoint_type' );?>

            <span>
                <?php echo Workforce\Type\UserType::get_name( $user_id ); ?>

                <?php if ( ! empty( $tags ) ) : ?>
                    -

                    <?php foreach ( $tags as $tag ) : ?>
                        <?php echo esc_html( $tag->name ); ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </span>
		</h2>
	</td>

	<td class="contact">
		<?php $person_id = get_post_meta( get_the_ID(), WORKFORCE_TOUCHPOINT_PREFIX . 'person_id', true ); ?>
		<?php $company_id = get_post_meta( get_the_ID(), WORKFORCE_TOUCHPOINT_PREFIX . 'company_id', true ); ?>

		<?php if ( ! empty( $person_id ) ) : ?>
			<?php echo Workforce\Helper\TemplateHelper::get_avatar( $person_id, WORKFORCE_PERSON_PREFIX . 'image' ); ?>

			<h2>
				<?php $person = get_post( $person_id ); ?>
				<?php echo esc_html( $person->post_title ); ?>

				<span><?php echo Workforce\Type\PersonType::get_position( $person_id )?></span>
			</h2>
		<?php elseif ( ! empty( $company_id ) ) : ?>
			<?php echo Workforce\Helper\TemplateHelper::get_avatar( $company_id, WORKFORCE_COMPANY_PREFIX . 'image', 'bordered' ); ?>

			<h2>
				<?php $company = get_post( $company_id ); ?>

				<a href="<?php echo get_the_permalink( $company_id ); ?>">
					<?php echo esc_html( $company->post_title ); ?>                        
				</a>
			</h2>
		<?php else : ?>
			<?php echo Workforce\Helper\TemplateHelper::get_avatar( 'CURRENT', null, 'bordered' ); ?>

			<h2>
				<?php echo esc_html__( 'Internal Meeting', 'workforce' ); ?>
				<span><?php echo get_theme_mod( 'workforce_invoices_billing_name', 'UNDEFINED' ); ?></span>
			</h2>
		<?php endif; ?>
	</td>

	<td class="date <?php echo \Workforce\Helper\FilterHelper::is_active_order( WORKFORCE_TOUCHPOINT_PREFIX . 'date_start' ); ?>">
		<?php echo \Workforce\Type\TouchpointType::get_date( get_the_ID() ); ?>
	</td>

	<td class="actions">
		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_UPDATE, get_the_ID() ); ?>"
		   class="update">
			<?php echo esc_html__( 'Update', 'workforce' ); ?>
		</a>

		<a href="<?php echo CrudHelper::get_action_uri( get_post_type(), CrudHelper::ACTION_DELETE, get_the_ID() ); ?>"
		   class="delete">
			<?php echo esc_html__( 'Delete', 'workforce' ); ?>
		</a>
	</td>
</tr>
