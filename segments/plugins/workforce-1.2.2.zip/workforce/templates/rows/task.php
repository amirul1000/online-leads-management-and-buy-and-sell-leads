<tr>
    <td class="title <?php echo Workforce\Helper\FilterHelper::is_active_order( 'title' ); ?>">
		<?php $user_id = get_post_meta( get_the_ID(), WORKFORCE_TASK_PREFIX . 'user_id', true ); ?>        


		<?php if ( ! empty( $user_id ) ) : ?>
			<?php echo Workforce\Helper\TemplateHelper::get_avatar( $user_id, WORKFORCE_USER_PREFIX . 'general_image', false, true ); ?>
		<?php endif; ?>

		<h2>
			<?php the_title(); ?>            

			<?php if ( ! empty( $user_id ) ) : ?>
				<span><?php echo Workforce\Type\UserType::get_name( $user_id ); ?></span>
			<?php endif; ?>			
		</h2>
	</td>

	<td class="project">
		<?php $project_id = get_post_meta( get_the_ID(), WORKFORCE_TASK_PREFIX . 'project_id', true ); ?>        

		<?php if ( ! empty( $project_id ) ) : ?>
			<a href="<?php echo Workforce\Helper\CrudHelper::get_action_uri( 'project', Workforce\Helper\CrudHelper::ACTION_UPDATE, $project_id ); ?>">
				<?php echo get_the_title( $project_id ); ?>
			</a>
		<?php endif; ?>
	</td>

	<td class="status">
		<?php $status = get_post_meta( get_the_ID(), WORKFORCE_TASK_PREFIX . 'status', true ); ?>

		<?php if ( ! empty( $status ) ) : ?>
			<span class="label">
				<?php echo Workforce\Type\TaskType::get_status_display_name( $status ); ?>
			</span><!-- /.label -->
		<?php endif; ?>
	</td>

	<td class="actions">
		<a href="<?php echo Workforce\Helper\CrudHelper::get_action_uri( get_post_type(), Workforce\Helper\CrudHelper::ACTION_UPDATE, get_the_ID() ); ?>"
		   class="update">
			<?php echo esc_html__( 'Update', 'workforce' ); ?>
		</a>

		<a href="<?php echo Workforce\Helper\CrudHelper::get_action_uri( get_post_type(), Workforce\Helper\CrudHelper::ACTION_DELETE, get_the_ID() ); ?>"
		   class="delete">
			<?php echo esc_html__( 'Delete', 'workforce' ); ?>
		</a>
	</td>
</tr>
