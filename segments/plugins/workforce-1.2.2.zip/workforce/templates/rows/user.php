<tr>
    <td class="title">
        <?php echo Workforce\Helper\TemplateHelper::get_avatar( $user->ID, WORKFORCE_USER_PREFIX . 'general_image', false, true ); ?>

		<h2><?php echo \Workforce\Type\UserType::get_name( $user->ID ); ?></h2>
	</td>


	<td class="tasks">
		<?php echo \Workforce\Type\TaskType::get_tasks_count( $user->ID ); ?>
	</td>

	<td class="email">
		<?php $email = get_user_meta( $user->ID, WORKFORCE_USER_PREFIX . 'general_email', true ); ?>

		<?php if ( ! empty( $email ) ) : ?>
			<a href="mailto:<?php echo esc_attr( $email ); ?>">
				<?php echo esc_html( $email ); ?>
			</a>
		<?php endif; ?>
	</td>

	<td class="phone">
		<?php $phone = get_user_meta( $user->ID, WORKFORCE_USER_PREFIX . 'general_phone', true ); ?>
		<?php if ( ! empty( $phone ) ) : ?>
			<?php echo esc_html( $phone ); ?>
		<?php endif; ?>
	</td>

	<td class="actions">
		<a href="<?php echo get_author_posts_url( $user->ID ); ?>"
		   class="view">
			<?php echo esc_html__( 'View', 'workforce' ); ?>
		</a>
	</td>
</tr>
