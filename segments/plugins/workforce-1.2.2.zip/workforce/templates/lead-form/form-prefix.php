<form method="POST" action="<?php echo home_url( '/' ); ?>">
	<input type="hidden" name="lead-form" value="<?php echo esc_attr( $id ); ?>">
