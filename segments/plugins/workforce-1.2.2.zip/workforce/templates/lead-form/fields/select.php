<?php use Workforce\Helper\TemplateHelper; ?>

	<div class="form-group">
		<?php include TemplateHelper::locate( 'lead-form/label' ); ?>

		<?php if ( ! empty( $values ) ) : ?>
<select name="<?php echo esc_attr( $id ) ?>" id="<?php echo esc_attr( $id ) ?>" <?php if ( ! empty( $required ) ) : ?>required<?php endif; ?>>		
		<?php foreach( explode( PHP_EOL, $values ) as $line ) : ?><?php list( $key, $value) = explode( ',', $line ); ?>		<option name="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( trim( $value ) ); ?></option>
		<?php endforeach?></select><?php else : ?><p><?php echo esc_html__( 'No values found.', 'workforce' ); ?></p><?php endif; ?>

	</div>

