<?php use Workforce\Helper\TemplateHelper; ?>

	<div class="form-group">
		<?php include TemplateHelper::locate( 'lead-form/label' ); ?>

		<textarea name="<?php echo esc_attr( $id ) ?>" id="<?php echo esc_attr( $id ) ?>" <?php if ( ! empty( $required ) ) : ?>required<?php endif; ?>></textarea>
	</div>
	