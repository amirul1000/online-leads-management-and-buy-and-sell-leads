<div id="filter-<?php echo esc_attr( $key ); ?>-wrapper" class="form-group select">
	<?php if ( empty( $id ) ) : ?>
		<?php $id = $key; ?>
	<?php endif; ?>

	<?php if ( empty( $input_name ) ) : ?>
		<?php $input_name = $key; ?>
	<?php endif; ?>

	<?php if ( ! empty( $label ) ) : ?>
		<label for="filter-<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
	<?php endif; ?>

	<select type="text"
			class="form-control"
			name="<?php echo esc_attr( $key ); ?>"
			id="filter-<?php echo esc_attr( $id ); ?>"
			<?php if ( ! empty( $multiple ) ) : ?>multiple="multiple"<?php endif; ?>
			<?php if ( ! empty( $placeholder ) ) : ?>placeholder="<?php echo esc_attr( $placeholder ); ?><?php endif; ?>">
		<?php if ( $allow_null ) : ?>
			<option value="" class="placeholder"><?php if ( ! empty( $placeholder ) ) : ?><?php echo esc_attr( $placeholder ); ?><?php endif; ?></option>
		<?php endif; ?>

		<?php if ( ! empty( $taxonomy ) ) : ?>
			<?php $options = []; ?>
			<?php $terms = get_terms( [ 'taxonomy' => $taxonomy, 'hide_empty' => false ] ); ?>

			<?php foreach ( $terms as $term ) : ?>
				<?php $options[ $term->slug ] = $term->name; ?>
			<?php endforeach; ?>
		<?php endif; ?>

		<?php if ( $options ) : ?>
			<?php foreach ( $options as $id => $name ) : ?>
				<option value="<?php echo esc_attr( $id ); ?>"
						<?php if ( $value == $id ) : ?>selected="selected"<?php endif; ?>>
					<?php echo esc_html( $name ); ?>
				</option>
			<?php endforeach ?>
		<?php endif; ?>
	</select>
</div><!-- /.form-group -->
