<div id="filter-<?php echo esc_attr( $key ); ?>-wrapper" class="form-group text">
	<?php if ( empty( $id ) ) : ?>
		<?php $id = $key; ?>
	<?php endif; ?>

	<?php if ( empty( $input_name ) ) : ?>
		<?php $input_name = $key; ?>
	<?php endif; ?>

	<?php if ( ! empty( $label ) ) : ?>
		<label for="filter-<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
	<?php endif; ?>

	<input type="text"
		   class="form-control <?php echo ! empty( $class ) ? esc_attr( $class ) : ''; ?>"
		   id="filter-<?php echo esc_attr( $id ); ?>"
		   name="<?php echo esc_attr( $input_name ); ?>"
			<?php if ( ! empty( $value ) ) : ?>value="<?php echo esc_attr( $value ); ?>"<?php endif; ?>
			<?php if ( ! empty( $placeholder ) ) : ?>placeholder="<?php echo esc_attr( $placeholder ); ?>"<?php endif; ?>>
</div><!-- /.form-group -->
