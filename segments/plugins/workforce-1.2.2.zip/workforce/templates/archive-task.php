<?php get_header(); ?>

<div class="page-header">
	<?php do_action( 'workforce_page_header_before' ); ?>

	<h1><?php echo esc_html__( 'Tasks', 'workforce' ); ?></h1>

	<?php do_action( 'workforce_page_header_after' ); ?>
</div><!-- .page-header -->

<div id="primary" class="content-area">
	<?php do_action( 'workforce_content_loop_before' );?>

	<main id="main" class="site-main" role="main">
		<?php if ( have_posts() ) : ?>
			<div class="table-wrapper">
				<table class="table">
					<thead>
						<th class="title">
							<span class="name"><?php echo esc_html__( 'Title', 'workforce' ); ?></span>

							<?php echo Workforce\Helper\TemplateHelper::load( 'helpers/table-order', [
								'field' => 'title',
							] ); ?>                        
						</th>
						

						<th class="project"><?php echo esc_html__( 'Project', 'workforce' ); ?></th>

						<th class="status"><?php echo esc_html__( 'Status', 'workforce' ); ?></th>

						<th class="actions"></th>
					</thead>

					<tbody>
						<?php while ( have_posts() ) : the_post(); ?>
							<?php echo \Workforce\Helper\TemplateHelper::load( 'rows/' . get_post_type() ); ?>
						<?php endwhile; ?>
					</tbody>
				</table><!-- /.workforce-table-wrapper -->
			</div><!-- /.table-wrapper -->
			
			<?php echo \Workforce\Helper\TemplateHelper::load( 'helpers/pagination' ); ?>
		<?php else : ?>
			<?php echo \Workforce\Helper\TemplateHelper::load( 'helpers/empty' ); ?>
		<?php endif; ?>
	</main><!-- .site-main -->

	<?php do_action( 'workforce_content_loop_after' );?>
</div><!-- .content-area -->

<?php get_footer(); ?>
