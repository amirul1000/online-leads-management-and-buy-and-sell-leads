<?php
use Workforce\Helper\CrudHelper;
use Workforce\Type\UserType;
?>

<?php get_header(); ?>

<?php $obj = get_queried_object(); ?>
<div class="page-header">
	<?php do_action( 'workforce_page_header_before' ); ?>

	<h1><?php echo esc_html__( 'Profile', 'workforce' ); ?> <span><?php echo UserType::get_name( $obj->ID ); ?></span></h1>

	<?php do_action( 'workforce_page_header_after' ); ?>
</div><!-- .page-header -->

<div id="primary" class="content-area">
	<?php do_action( 'workforce_content_loop_before' );?>

	<main id="main" class="site-main" role="main">
		<div class="main-inner">
			<?php $tasks = \Workforce\Type\TaskType::get_by_user( $obj->ID, -1 ); ?>

			<?php if ( is_array( $tasks ) && count( $tasks ) > 0 ) : ?>
				<h3><?php echo esc_html__( 'Assigned Task', 'workforce' ); ?></h3>

				<ul class="list">
					<?php foreach ( $tasks as $task ) : ?>
						<li>
							<a href="<?php echo CrudHelper::get_action_uri( 'task', CrudHelper::ACTION_UPDATE, $task->ID ); ?>">
								<?php echo esc_html( $task->post_title ); ?>
							</a>

							<?php $status = get_post_meta( $task->ID, WORKFORCE_TASK_PREFIX . 'status', true );?>
							<?php if ( ! empty( $status ) ) : ?>
								<span class="status">
									<?php echo \Workforce\Type\TaskType::get_status_display_name( $status ); ?>
								</span>
							<?php endif; ?>

							<?php $due = get_post_meta( $task->ID, WORKFORCE_TASK_PREFIX . 'due', true ); ?>
							<?php if ( ! empty( $due ) ) : ?>
								<span class="date">
									<?php echo date( get_option( 'date_format' ), $due ); ?>
								</span>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>

			<?php $touchpoints = \Workforce\Type\TouchpointType::get_by_user( $obj->ID, -1 ); ?>

			<?php if ( is_array( $touchpoints ) && count( $touchpoints ) > 0 ) : ?>
				<h3><?php echo esc_html__( 'Assigned Touchpoints', 'workforce' ); ?></h3>

				<ul class="list">
					<?php foreach ( $touchpoints as $touchpoint ) : ?>
						<li>
							<a href="<?php echo CrudHelper::get_action_uri( 'touchpoint', CrudHelper::ACTION_UPDATE, $touchpoint->ID ); ?>">
								<?php echo esc_html( $touchpoint->post_title ); ?>
							</a>

							<?php $types = wp_get_post_terms( $touchpoint->ID, 'touchpoint_type' ); ?>
							<?php if ( ! empty( $types ) ) : ?>
								<?php $type = array_shift( $types ); ?>
								<span class="type">
									<?php echo esc_html( $type->name ); ?>
								</span>
							<?php endif; ?>

							<?php $date = \Workforce\Type\TouchpointType::get_date( $touchpoint->ID ); ?>
							<?php if ( ! empty( $date ) ) : ?>
								<span class="date">
									<?php echo $date; ?>
								</span>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div><!-- /.main-inner -->

		<?php get_template_part( 'templates/content', 'pagination' ); ?>
	</main><!-- .site-main -->

	<?php do_action( 'workforce_content_loop_after' );?>
</div><!-- .content-area -->

<?php get_footer(); ?>
