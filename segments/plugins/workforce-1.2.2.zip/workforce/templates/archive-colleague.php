<?php get_header(); ?>

<div class="page-header">
	<?php do_action( 'workforce_page_header_before' ); ?>

	<h1><?php echo esc_html__( 'Colleagues', 'workforce' ); ?></h1>

	<?php do_action( 'workforce_page_header_after' ); ?>
</div><!-- .page-header -->

<div id="primary" class="content-area">
	<?php do_action( 'workforce_content_loop_before' );?>

	<main id="main" class="site-main" role="main">
		<?php $users = $query = new WP_User_Query( [
			'role'		=> ['employee', ],
			'number'    => get_option( 'posts_per_page' ),
			'paged'     => ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1,
		] );?>


		<?php if ( ! empty( $users->results ) ) : ?>
			<div class="table-wrapper">
				<table class="table">
					<thead>
						<th class="title"><?php echo esc_html__( 'Name', 'workforce' ); ?></th>

						<th class="tasks"><?php echo esc_html__( 'Tasks', 'workforce' ); ?></th>

						<th class="email"><?php echo esc_html__( 'E-mail', 'workforce' ); ?></th>

						<th class="phone"><?php echo esc_html__( 'Phone', 'workforce' ); ?></th>

						<th class="actions"></th>
					</thead>

					<tbody>
						<?php foreach ( $users->results as $user ) : ?>
							<?php echo \Workforce\Helper\TemplateHelper::load( 'rows/user', [
								'user' => $user,
							] ); ?>
						<?php endforeach; ?>
					</tbody>
				</table><!-- /.workforce-table-wrapper -->
			</div><!-- /.table-wrapper -->
			
			<nav class="navigation pagination" role="navigation">
				<div class="nav-links">
					<?php
					$total_user = $users->total_users;
					$total_pages = ceil( $total_user / get_option( 'posts_per_page' ) );
					$query_string = $_SERVER['QUERY_STRING'];
					$base = get_post_type_archive_link( 'colleague' ) . remove_query_arg( 'page', $query_string ) . '%_%';

					echo paginate_links( array(
						'base'      => $base,
						'format'    => '?page=%#%',
						'current'   => get_query_var( 'page' ),
						'total'     => $total_pages,
						'prev_text' => esc_html__( 'Previous page', 'workforce' ),
						'next_text' => esc_html__( 'Next page', 'workforce' ),

					) );
					?>
				</div>
			</nav>
		<?php else : ?>
			<?php echo \Workforce\Helper\TemplateHelper::load( 'helpers/empty' ); ?>
		<?php endif; ?>
	</main><!-- .site-main -->

	<?php do_action( 'workforce_content_loop_after' );?>
</div><!-- .content-area -->

<?php get_footer(); ?>
