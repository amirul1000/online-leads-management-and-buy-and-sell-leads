<?php
/**
 * Plugin Name: Workforce
 * Version: 1.2.2
 * Description: Advanced WordPress CRM and project management plugin for business processes. Implements features companies, people, touchpoints, estimates, projects, tasks, colleagues, estimates, invoices and so on.
 * Author: Code Vision
 * Author URI: http://wearecodevision.com
 * Text Domain: workforce
 * Domain Path: /languages/
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package Workforce
 */

require_once 'vendor/autoload.php';

use Doctrine\Common\Annotations\AnnotationRegistry;
use Workforce\Bootstrap;

define( 'WORKFORCE_ACTIVE', true );

AnnotationRegistry::registerLoader('class_exists');

$app = new Bootstrap();
$app->bootstrap( __DIR__ );
