jQuery(document).ready(function($) {
    'use strict';

    if ($("#workforce-stats-money-chart").length) {
		var data = {
		  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
		  series: $("#workforce-stats-money-chart").data('series')
		};

		var options = {
		  seriesBarDistance: 10
		};

		var responsiveOptions = [
		  ['screen and (max-width: 640px)', {
		    seriesBarDistance: 5,
		    axisX: {
		      labelInterpolationFnc: function (value) {
		        return value[0];
		      }
		    }
		  }]
		];

		new Chartist.Bar('#workforce-stats-money-chart', data, options, responsiveOptions);
    }
});