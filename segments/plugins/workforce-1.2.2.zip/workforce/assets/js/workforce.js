jQuery(document).ready(function($) {
    'use strict';

    /**
     * Calendar
     */
    $('#calendar').fullCalendar({
        firstDay: 1,
        eventSources: [
            {
                url: $('#calendar').data('url'),
                beforeSend: function (xhr) {
                    xhr.setRequestHeader( 'X-WP-Nonce', workforceApiSettings.nonce );
                }
            }
        ]
    });

    /**
     * Datepicker
     */
    $('.has-datepicker').datepicker({
        "dateFormat": "mm/dd/yy"
    });

    /**
     * CMB2 select company information
     */
    $('select[data-workforce-ajax-company-url]').each(function() {
        var target = $(this);
        var select = $('#' + $(this).data('workforce-ajax-id'));


        select.on('change', function() {
            $.ajax({
                url: target.data('workforce-ajax-company-url'),
                method: 'GET',
                beforeSend: function (xhr) {
                    xhr.setRequestHeader( 'X-WP-Nonce', workforceApiSettings.nonce );
                },
                data: {
                    id: $('#' + target.data('workforce-ajax-id')).val()
                },
                success: function(data) {
                    $('#' + target.data('workforce-ajax-customer-name')).val(data['name']);
                    $('#' + target.data('workforce-ajax-customer-vat-number')).val(data['vat_number']);
                    $('#' + target.data('workforce-ajax-customer-registration-number')).val(data['registration_number']);
                }
            })
        });
    });

    /**
     * CMB2 select preloaders
     */
    $('select[data-workforce-ajax-url]').each(function() {
        var target = $(this);
        var select = $('#' + $(this).data('workforce-ajax-id'));

        preload_select(target);

        select.on('change', function() {
            preload_select(target);
        });
    });

    function preload_select(el) {
        $.ajax({
            url: el.data('workforce-ajax-url'),
            method: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader( 'X-WP-Nonce', workforceApiSettings.nonce );
            },
            data: {
                id: $('#' + el.data('workforce-ajax-id')).val(),
                type: el.data('workforce-ajax-type')
            },
            success: function(data) {
                var val =el.find('option:selected').val();
                el.find('option').remove();
                el.append($('<option/>').attr({'value': ''}).text('None'));
                
                $.each(data, function(index) {
                    var option = $('<option/>');
                    var params = {'value': data[index].ID};

                    if (data[index].ID == val) {
                        params['selected'] = 'selected';
                    }

                    option.attr(params).text(data[index].post_title);
                    el.append(option);
                });
            }
        })
    }
});