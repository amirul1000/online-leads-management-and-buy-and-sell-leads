<?php
/**
 * Plugin Name: Segments Core
 * Version: 1.0.0
 * Description: Custom functionality & post types for Segments WordPress theme
 * Author: Code Vision
 * Author URI: http://wearecodevision.com
 * Text Domain: segments-core
 * Domain Path: /languages/
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package Segments_Core
 */

class Segments_Core {
	public function __construct() {
        load_plugin_textdomain( 'segments-core', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );

		add_action( 'init', [ 'Segments_Core', 'testimonials' ] );
		add_action( 'init', [ 'Segments_Core', 'partners' ] );
		add_action( 'init', [ 'Segments_Core', 'services' ] );
        add_action( 'init', [ 'Segments_Core', 'questions' ] );
        add_action( 'init', [ 'Segments_Core', 'members' ] );
	}

    public static function members() {
        $labels = [
            'name'                  => esc_html__( 'Members', 'segments-core' ),
            'singular_name'         => esc_html__( 'Member', 'segments-core' ),
            'add_new'               => esc_html__( 'Add New Member', 'segments-core' ),
            'add_new_item'          => esc_html__( 'Add New Member', 'segments-core' ),
            'edit_item'             => esc_html__( 'Edit Member', 'segments-core' ),
            'new_item'              => esc_html__( 'New Member', 'segments-core' ),
            'all_items'             => esc_html__( 'Members', 'segments-core' ),
            'view_item'             => esc_html__( 'View Member', 'segments-core' ),
            'search_items'          => esc_html__( 'Search Member', 'segments-core' ),
            'not_found'             => esc_html__( 'No Member found', 'segments-core' ),
            'not_found_in_trash'    => esc_html__( 'No Members Found in Trash', 'segments-core' ),
            'parent_item_colon'     => '',
            'menu_name'             => esc_html__( 'Members', 'segments-core' ),
        ];

        register_post_type( 'member', [
            'labels'              => $labels,
            'supports'            => [ 'title', 'editor', 'thumbnail', 'author' ],
            'public'              => true,
            'has_archive'         => true,
            'exclude_from_search' => true,
            'show_ui'             => true,
            'rewrite'             => [ 'slug' => esc_attr__( 'members', 'segments-core' ) ],
        ] );        
    }

    public static function questions() {
        $labels = [
            'name'                  => esc_html__( 'Questions', 'segments-core' ),
            'singular_name'         => esc_html__( 'Question', 'segments-core' ),
            'add_new'               => esc_html__( 'Add New Question', 'segments-core' ),
            'add_new_item'          => esc_html__( 'Add New Question', 'segments-core' ),
            'edit_item'             => esc_html__( 'Edit Question', 'segments-core' ),
            'new_item'              => esc_html__( 'New Question', 'segments-core' ),
            'all_items'             => esc_html__( 'Questions', 'segments-core' ),
            'view_item'             => esc_html__( 'View Question', 'segments-core' ),
            'search_items'          => esc_html__( 'Search Question', 'segments-core' ),
            'not_found'             => esc_html__( 'No Question found', 'segments-core' ),
            'not_found_in_trash'    => esc_html__( 'No Questions Found in Trash', 'segments-core' ),
            'parent_item_colon'     => '',
            'menu_name'             => esc_html__( 'Questions', 'segments-core' ),
        ];

        register_post_type( 'question', [
            'labels'              => $labels,
            'supports'            => [ 'title', 'editor','author' ],
            'public'              => true,
            'has_archive'         => true,
            'exclude_from_search' => true,
            'show_ui'             => true,
            'rewrite'             => [ 'slug' => esc_attr__( 'questions', 'segments-core' ) ],
        ] );        
    }

	public static function testimonials() {
        $labels = [
            'name'                  => esc_html__( 'Testimonials', 'segments-core' ),
            'singular_name'         => esc_html__( 'Testimonial', 'segments-core' ),
            'add_new'               => esc_html__( 'Add New Testimonial', 'segments-core' ),
            'add_new_item'          => esc_html__( 'Add New Testimonial', 'segments-core' ),
            'edit_item'             => esc_html__( 'Edit Testimonial', 'segments-core' ),
            'new_item'              => esc_html__( 'New Testimonial', 'segments-core' ),
            'all_items'             => esc_html__( 'Testimonials', 'segments-core' ),
            'view_item'             => esc_html__( 'View Testimonial', 'segments-core' ),
            'search_items'          => esc_html__( 'Search Testimonial', 'segments-core' ),
            'not_found'             => esc_html__( 'No Testimonial found', 'segments-core' ),
            'not_found_in_trash'    => esc_html__( 'No Testimonials Found in Trash', 'segments-core' ),
            'parent_item_colon'     => '',
            'menu_name'             => esc_html__( 'Testimonials', 'segments-core' ),
        ];

        register_post_type( 'testimonial', [
            'labels'              => $labels,
            'supports'            => [ 'title', 'editor', 'thumbnail', 'author' ],
            'public'              => true,
            'has_archive'         => true,
            'exclude_from_search' => true,
            'show_ui'             => true,
            'rewrite'       	  => [ 'slug' => esc_attr__( 'testimonials', 'segments-core' ) ],
        ] );		
	}

	public static function partners() {
        $labels = [
            'name'                  => esc_html__( 'Partners', 'segments-core' ),
            'singular_name'         => esc_html__( 'Partner', 'segments-core' ),
            'add_new'               => esc_html__( 'Add New Partner', 'segments-core' ),
            'add_new_item'          => esc_html__( 'Add New Partner', 'segments-core' ),
            'edit_item'             => esc_html__( 'Edit Partner', 'segments-core' ),
            'new_item'              => esc_html__( 'New Partner', 'segments-core' ),
            'all_items'             => esc_html__( 'Partners', 'segments-core' ),
            'view_item'             => esc_html__( 'View Partner', 'segments-core' ),
            'search_items'          => esc_html__( 'Search Partner', 'segments-core' ),
            'not_found'             => esc_html__( 'No Partner found', 'segments-core' ),
            'not_found_in_trash'    => esc_html__( 'No Partners Found in Trash', 'segments-core' ),
            'parent_item_colon'     => '',
            'menu_name'             => esc_html__( 'Partners', 'segments-core' ),
        ];

        register_post_type( 'partner', [
            'labels'              => $labels,
            'supports'            => [ 'title', 'thumbnail', 'author' ],
            'public'              => true,
            'has_archive'         => true,
            'exclude_from_search' => true,
            'show_ui'             => true,
            'rewrite'       	  => [ 'slug' => esc_attr__( 'partners', 'segments-core' ) ],
        ] );		
	}	

	public static function services() {
        $labels = [
            'name'                  => esc_html__( 'Services', 'segments-core' ),
            'singular_name'         => esc_html__( 'Service', 'segments-core' ),
            'add_new'               => esc_html__( 'Add New Service', 'segments-core' ),
            'add_new_item'          => esc_html__( 'Add New Service', 'segments-core' ),
            'edit_item'             => esc_html__( 'Edit Service', 'segments-core' ),
            'new_item'              => esc_html__( 'New Service', 'segments-core' ),
            'all_items'             => esc_html__( 'Services', 'segments-core' ),
            'view_item'             => esc_html__( 'View Service', 'segments-core' ),
            'search_items'          => esc_html__( 'Search Service', 'segments-core' ),
            'not_found'             => esc_html__( 'No Service found', 'segments-core' ),
            'not_found_in_trash'    => esc_html__( 'No Services Found in Trash', 'segments-core' ),
            'parent_item_colon'     => '',
            'menu_name'             => esc_html__( 'Services', 'segments-core' ),
        ];

        register_post_type( 'service', [
            'labels'              => $labels,
            'supports'            => [ 'title', 'thumbnail', 'editor', 'author' ],
            'public'              => true,
            'has_archive'         => true,
            'exclude_from_search' => true,
            'show_ui'             => true,
            'rewrite'       	  => [ 'slug' => esc_attr__( 'services', 'segments-core' ) ],
        ] );		
	}	
}

new Segments_Core();